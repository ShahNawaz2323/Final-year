﻿class ReportViewer {
    constructor(container) {
        this.container = container;

        this.el = $(container);

        this.leftBox = document.createElement("div");
        this.leftBox.setAttribute('class', 'col-12 col-md-6');

        this.rightBox = document.createElement("div");
        this.rightBox.setAttribute('class', 'col-12 col-md-6');

        $(this.el).append(this.leftBox).append(this.rightBox);
    }
}