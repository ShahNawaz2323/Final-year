﻿/*! WebEx Market
* 2019 BetPro
*/
const marketStore = new Vuex.Store({
    state: {
        eventId: '',
        marketId: '',
        userId: 0,
        marketType: ''
    },
    mutations: {

    },
    // store.getters.lineMarkets
    getters: {
        // lineMarkets: state => {
            // return state.markets.filter(market => market.IsLine);
        // }
    }
});

var backColor = '227,248,255';
var layColor = '255,205,204';
var plusFlash = '248,245,33';
var minusFlash = '248,245,33';

var OldPrice = 0;

var menuTrail = [];
var LastNavItems = [];


function SaveNavTrail(id, type) {
    if (id === "0" || type === "0") {
        menuTrail = [];
    }
    else {
        // Is item in MenuTrail?
        var index = menuTrail.findIndex(function (item) { return item.id === id; });
        if (index >= 0) {
            menuTrail = menuTrail.slice(0, index + 1);
        } else {
            var navItem = LastNavItems.find(function (x) { return x.id === id.toString(); });
            if (navItem !== null && navItem !== undefined) {
                menuTrail.push(navItem);
            }
        }
    }
}

$(document).ready(function () {
    var router2 = new Navigo(null, true, "#!");
    router2
        .on({
            ':id/:type': function (params) {
                SaveNavTrail(params.id, params.type);
                GetSports(params.id, params.type);
            },
            ':id': function (params) {
                GetMarket(params.id);
            }
        })
        .resolve();

    $("#place-error").hide();

    $("#PrInc").click(function () {
        if ($("#bet-price").val() === "") {
            return;
        }
        var NewPrice = parseFloat($("#bet-price").val());
        OneStepIncrement(NewPrice);
    });

    $("#PrDec").click(function () {
        if ($("#bet-price").val() === "") {
            return;
        }
        var NewPrice = parseFloat($("#bet-price").val());
        OneStepDecrement(NewPrice);
    });

    $("#bet-size").change(function () {
        var size = $("#bet-size").val();
        size = numeral(size).format('0,0[.]00');
    });

    $("#BetModal").on('keyup', "#bet-size,#bet-price", function (e) {
        var NewPrice = parseFloat($("#bet-price").val());
        PriceValidator.OldPrice = OldPrice;
        PriceValidator.NewPrice = NewPrice;

        CalcPL();

        if (e.keyCode === 13) {
            $("#Place-Order").click();
        }
        else if (e.keyCode === 38) {
            OneStepIncrement(NewPrice);
        }
        else if (e.keyCode === 40) {
            OneStepDecrement(NewPrice);
        }
        CalcPL();
    });

    $("#BetModal").on('change', '#bet-price', function (e) {
        var NewPrice = parseFloat($("#bet-price").val());

        Validated = PriceValidator.ValidatePrice(NewPrice);
        if (Validated !== NewPrice) {
            UpdatePrice(Validated);
        }
    });

    $('#BetModal').on('shown.bs.modal', function (e) {
        $("#place-error").hide();
        $("#bet-price").focus();
    });

    $("#Place-Order").click(function () {
        if ($(this).hasClass('running')) return;

        Order.price = $("#bet-price").val();
        Order.size = $("#bet-size").val();
        Order.persist = true;
        if (platform !== undefined) {
            Order.identity = btoa(platform.description);
        }
        if (Order.price === undefined || Order.price === "") return;

        $(this).addClass('running');

        Orders = [Order];
        PlaceOrder(Orders);
        return false;
    });

    $("#Close-Order").click(function () {
        $("#Place-Order").removeAttr("disabled");
        OrderVue.Active = false;
        $("#place-error").hide();
        return false;
    });

    $('.btn-stake').click(function () {
        var amount = $(this).data('amount');
        if (amount !== undefined) {
            $("#bet-size").val(amount);
            CalcPL();
        } else {
            var plus = $(this).data('plus');
            if (plus !== undefined) {
                $("#bet-size").val(plus + parseFloat($("#bet-size").val()));
                CalcPL();
            }
        }
    });

    $("#bet-cancel-all").click(function () {
        var qs = svc_prefix + 'orders/CancelAll?MarketId=' + MarketId;

        $.ajax({
            type: "DELETE",
            url: qs,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (result) {
                GetFunds();
            },
            error: function (exception) {
                ErrorHandler(exception.responseJSON);
            }
        });
    });

    // A simple background color flash effect that uses jQuery Color plugin
    jQuery.fn.flash = function (bgcolor, color, duration) {
        var current = this.css('backgroundColor');
        this.css('backgroundColor', 'rgb(' + color + ')')
            .animate({ backgroundColor: 'rgb(' + bgcolor + ')' }, duration);
    };

    GetSports(0, 0);
});

function OneStepIncrement(NewPrice) {
    if (NewPrice === '' || NewPrice === undefined) {
        return undefined;
    }
    else if (MarketVue.IsLineMarket(Order.marketId)) {
        NewPrice = Math.round(NewPrice);
    } else {
        validInc = PriceValidator.GetValidIncrement(NewPrice);
        NewPrice = NewPrice + validInc;
    }
    UpdatePrice(NewPrice);
}

function OneStepDecrement(NewPrice) {
    if (NewPrice === '' || NewPrice === undefined) {
        return undefined;
    }
    else if (MarketVue.IsLineMarket(Order.marketId)) {
        NewPrice = Math.round(NewPrice);
    } else {
        validDec = PriceValidator.GetValidDecrement(NewPrice);
        NewPrice = NewPrice - validDec;
    }
    UpdatePrice(NewPrice);
}

function UpdatePrice(Price) {
    if (PriceValidator.IsLine || Price >= 20) {
        Price = Math.round(Price);
    } else {
        Price = Price.toFixed(2);
    }

    $("#bet-price").val(Price);
    OldPrice = Price;
    CalcPL();
}

var MarketId;
var EventId;
var Order = { isLine: false };
var CurrentMarket;
var BookIntervalId;
var OrderIntervalId;
var LastNavId = 0;

function GetSports(id, type) {
    LastNavId = id;
    var qs = svc_prefix + 'Navigation?id=' + id + '&type=' + type;
    $.getJSON(qs, function (result) {
        var FinalNav = menuTrail.concat(result);
        FinalNav.unshift({ id: 0, name: "Refresh", type: 0 });
        RenderSports(FinalNav);
        return false;
    });
}

function RenderSports(Items) {
    LastClicked = menuTrail[menuTrail.length - 1];
    LastNavItems = Items;
    Items = Items.slice(0, 50);
    $("#LeftNavigation").html('');
    var html;
    if (document.location.href.includes("Customer")) {
        html = '<li class="nav-item"><a class="nav-link-small {class2} {class3}" href="#!{HREF}"> {TEXT}</a></li>';
    }
    else {
        html = '<li class="nav-item"><a class="nav-link-small {class2} {class3}" href="#!{HREF}"> {TEXT}</a></li>';
    }

    Items.forEach(function (Item) {
        if (LastNavId === "7" && Item.type === 2) return;
        var class2 = Item.id === 0 ? 'icon-refresh' : '';
        var handler = Item.type === 5 ? Item.id : Item.id + '/' + Item.type;
        var navHtml = html.replace('{HREF}', handler).replace('{TEXT}', Item.name).replace('{class2}', class2);
        if (LastClicked !== undefined) {
            var class3 = Item.id === LastClicked.id ? 'active' : '';
            navHtml = navHtml.replace('{class3}', class3);
        }
        $("#LeftNavigation").append(navHtml);
    });
}

function GetMarket(marketId) {
    marketStore.state.marketId = marketId;
    if (MarketVue === undefined) {
        var marketPage = getUserDirectory();
        if (marketPage !== 'Markets') {
            marketPage += '/Market';
        }
        document.location.href = '/' + marketPage + '/#!' + marketId;
        return;
    }
    ResetWinner();
    MarketVue.catalogues = [];
    MarketVue.subMarketIds = [];
    MarketId = marketId;
    var qs = svc_prefix + 'Markets/Catalog2/?id=' + marketId;
    $.getJSON(qs, function (result) {
        marketStore.state.eventId = result.eventId;
        marketStore.state.marketType = result.marketType;
        RenderMarket(result);
        return false;
    });
}

function RenderMarket(Market) {

    if (Market.eventType == "Race")
    {
        var date = moment(Market.marketStartTimeUtc).format('h:mm a')+ " "+ Market.raceName;
        Market.eventName = date;
    }
    CurrentMarket = Market;
    Market.runners = Market.runners.map(function (runner) {
        runner.price1 = '';
        runner.size1 = '';
        runner.price2 = '';
        runner.size2 = '';
        runner.price3 = '';
        runner.size3 = '';
        runner.lay1 = '';
        runner.ls1 = '';
        runner.lay2 = '';
        runner.ls2 = '';
        runner.lay3 = '';
        runner.ls3 = '';
        runner.ifWin = '';
        runner.ifLose = '';
        return runner;
    });

    Market.runners[Market.runners.length - 1].IsLast = true;



    document.title = Market.eventName+ " - " + Market.marketName;

    MarketVue.startTime = Market.marketStartTimeUtc;
    MarketVue.market = Market;
    MarketVue.IsLoaded = true;
    GetMarketData();
    OrderVue.ListOrders();
    if (BookIntervalId === undefined) {
        console.log("Interval set");
        BookIntervalId = setInterval(GetMarketData, 1000);
        OrderIntervalId = setInterval(OrderVue.ListOrders, 3000);
    }

    //if (Market.hasOwnProperty("bettingType")) {
    //    PriceValidator.IsLine = Market.bettingType === 'LINE';
    //} else {
    //    PriceValidator.IsLine = Market.description.bettingType === 'LINE';
    //}
}

function GetMarketData() {
    var id = MarketId;
    $.ajax({
        type: "GET",
        url: '/api/Markets/Data?id=' + id ,
        success: function (result) {
            RenderMarketData(result);
        },
        error: function (exception) {
            ErrorHandler(exception.responseJSON);
        }
    });
}

var MarketPL = [];
var LoadingSubMarkets = false;

function RenderMarketData(MarketData) {
    if (MarketData === null || MarketData.marketBooks.length === 0) return;

    var Book = MarketData.marketBooks[0];

    MarketVue.market.news = MarketData.news;
    MarketVue.market.totalMatched = Book.totalMatched;
    MarketVue.startTime = CurrentMarket.marketStartTimeUtc;
    MarketVue.status = Book.marketStatus;
    MarketVue.scores = MarketData.scores;

    MarketVue.betDelay = Book.betDelay;
    MarketVue.winners = Book.winners;
    MarketVue.sinceStart = moment(CurrentMarket.marketStartTimeUtc).fromNow();
    MarketVue.score = MarketData.scoreboard;
    MarketVue.scoreLines = MarketData.fancy;

    /*if (Book.marketStatus === "CLOSED") {
        clearInterval(BookIntervalId);
        clearInterval(OrderIntervalId);
    }*/
    MarketVue.market.runners.forEach(function (runner) {
        var soldier = Book.runners.find(function (item) {
            return item.id === runner.selectionId.toString();
        });

        if (window.MarketPL !== null) {
            var PL = window.MarketPL.find(function (plItem) {
                return plItem.selectionId === runner.selectionId
                    && plItem.marketId === Book.id;
            });
        }

        if (soldier !== undefined) {
            if (soldier.status === 'WINNER') {
                MarkWinner(soldier.id);
            }
            runner.price1 = UpdatePriceCell(runner.price1, soldier.price1, 'b1', soldier.id, backColor);
            runner.size1 = UpdatePriceCell(runner.size1, soldier.size1, 'bs1', soldier.id, backColor);

            runner.lay1 = UpdatePriceCell(runner.lay1, soldier.lay1, 'l1', soldier.id, layColor);
            runner.ls1 = UpdatePriceCell(runner.ls1, soldier.ls1, 'ls1', soldier.id, layColor);

            runner.price2 = soldier.price2;
            runner.size2 = soldier.size2;
            runner.price3 = soldier.price3;
            runner.size3 = soldier.size3;
            runner.lay2 = soldier.lay2;
            runner.lay3 = soldier.lay3;
            runner.ls2 = soldier.ls2;
            runner.ls3 = soldier.ls3;

            //  runner.status = soldier.status;

            if (PL !== undefined) {
                runner.ifWin = PL.ifWin;
                runner.ifLose = PL.ifLose;
            }
        }
    });

    // Sub Markets
    if (MarketData.marketBooks.length > 0) {

        var ActiveSubMarketIds = _.map(MarketData.marketBooks, function (book) { return book.id; });
        ActiveSubMarketIds = _.without(ActiveSubMarketIds, MarketId);
        if (ActiveSubMarketIds.length === 0) {
            MarketVue.catalogues = [];
            return;
        }

        ActiveSubMarketIds = _.sortBy(ActiveSubMarketIds, function (id) { return id; });
        var NewMarketIdsHash = ActiveSubMarketIds.join(',');

        if (NewMarketIdsHash === MarketVue.CurrentMarketIdsHash) {
            _.each(MarketData.marketBooks, MarketVue.RenderSubMarketData);
            return;
        }

        if (LoadingSubMarkets) {
            return;
        }

        LoadingSubMarkets = true;

        MarketVue.catalogues = [];
        MarketVue.FetchCatalogs(ActiveSubMarketIds);
    } else {
        // MarketVue.subMarketIds = [];
        MarketVue.catalogues = [];
    }
}

function PlaceOrder(Orders) {
    var qs = svc_prefix + 'Orders';

    $.ajax({
        type: "POST",
        url: qs,
        data: JSON.stringify(Orders),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (result) {
            // $("#Place-Order").removeAttr("disabled");
            $("#Place-Order").removeClass('running');
            OrderVue.Active = false;
            $("#place-error").hide();
            GetFunds();
        },
        error: function (data) {
            // $("#Place-Order").removeAttr("disabled");
            $("#Place-Order").removeClass('running');
            $("#place-error").show();
            $("#place-error").text(data.responseJSON.error);
        }
    });
}

// highligh winner of current market
function MarkWinner(id) {
    $("#runner-" + id).addClass('winner');
}

// Before rendering new market, reset previous market winners
function ResetWinner() {
    $(".winner").removeClass('winner');
}

function CalcPL() {
    var price = parseFloat($("#bet-price").val());
    var size = parseFloat($("#bet-size").val());

    if (MarketVue.IsLineMarket(Order.marketId)) {
        profit = size;
        liable = size;
    }
    else {
        if (Order.side === "B") {
            profit = (price - 1) * size;
            liable = size;
        } else {
            profit = size;
            liable = (price - 1) * size;
        }
    }

    $("#bet-profit").text(numeral(profit).format('0,0[.]00'));
    $("#bet-liable").text(numeral(liable).format('0,0[.]00'));
}

function ActSettle() {
    var qs = svc_prefix + 'Orders/settle';

    var MarketIds = [MarketId];

    $.ajax({
        type: "POST",
        url: qs,
        data: JSON.stringify(MarketIds),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (result) {
        },
        error: function () {

        }
    });
}

var MarketVue, OrderVue;


/*! WebEx.components.js */
Vue.component('market-locker', {
    props: [],
    data: function () {
        return {
            IsLoading: true,
            marketId: '',
            eventId: '',
            marketTitle: '',
            lockType: '',
            Users: [],
            AllLockActive: false
        }
    },
    template: `
        <div class="dropdown mr-2">
            <a class="btn btn-primary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Bet Lock</a>

            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(0px, 35px, 0px);">
                <a class="dropdown-item" v-on:click.prevent="showMarketLocker('Match Odds')" href="#">Match Odds</a>
                <a class="dropdown-item" v-on:click.prevent="showMarketLocker('Other Markets', true)" href="#">Other Markets</a>
            </div>

            <div class="modal fade" id="modalLocker" tabindex="-1" role="dialog" aria-labelledby="betSlipMobile" aria-hidden="true">
                <div class="modal-dialog modal-md" role="document">
                    <div class="modal-content">
                        <div class="modal-body" v-if="IsLoading">
                            <img src="/img/preloader.gif">
                        </div>
                        <div class="modal-body" v-else>
                            <h5>{{ marketTitle }} - Bet Locker</h5>
                            <div v-if="lockType === 'self'">
                                <div class="alert alert-danger" role="alert">
                                  Market locked by your dealer!
                                </div>
                            </div>
                            <div v-else>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="radio" id="uAll" v-model="lockType" value="all">
                                  <label class="form-check-label" for="uAll">All Users</label>
                                </div>
                                <div class="form-check form-check-inline" v-show="AllLockActive">
                                  <input class="form-check-input" type="radio" id="unlock" v-model="lockType" value="unlock">
                                  <label class="form-check-label" for="unlock">Unlock All</label>
                                </div>
                                <div class="form-check form-check-inline">
                                  <input class="form-check-input" type="radio" id="uSel" v-model="lockType" value="sel">
                                  <label class="form-check-label" for="uSel">Selected Users</label>
                                </div>
                                <button class="btn btn-primary" type="button" v-on:click="UpdateLocks()">Save</button>
                                <button class="btn btn-danger" type="button" v-on:click="hideLocker()">Cancel</button>
                                <div v-show="lockType === 'sel'">
                                    <div class="form-check" v-for="User in Users">
                                      <input class="form-check-input" type="checkbox" v-model="User.isActive" value="1">
                                      <label class="form-check-label">
                                        {{ User.username }}
                                      </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `,
    computed: {
        newLocks: function () {

            var self = this;

            var locks = [];

            if (this.lockType === 'all') {
                lockAll = {
                    marketId: self.marketId.toString(),
                    eventId: self.eventId.toString(),
                    userId: marketStore.state.userId,
                    managerId: marketStore.state.userId
                };
                locks.push(lockAll);
            } else if (this.lockType === 'sel') {
                var selUsers = _.filter(this.Users, function (User) {
                    return User.isActive;
                });

                locks = _.map(selUsers, function (User) {
                    return {
                        marketId: self.marketId.toString(),
                        eventId: self.eventId.toString(),
                        userId: User.id,
                        managerId: marketStore.state.userId
                    };
                });
            }
            return locks;
        }
    },
    methods: {
        showLocker: function () {
            $("#modalLocker").modal('show');
        },
        hideLocker: function () {
            $("#modalLocker").modal('hide');
        },
        showMarketLocker: function (title, IsEvent = false) {

            this.IsLoading = true;

            if (IsEvent) {
                this.eventId = marketStore.state.eventId;
                this.marketId = '';
            } else {
                this.eventId = '';
                this.marketId = marketStore.state.marketId;
            }

            this.marketTitle = title;

            this.showLocker();

            window.client.getUsers(this.handleUsers);
        },

        handleUsers: function (data) {

            this.Users = data;

            window.client.getMarketLocks(this.marketId, this.eventId, this.handleLocks);
        },
        handleLocks: function (data) {
            var self = this;

            this.IsLoading = false;

            var IsLockedForMe = _.find(data, function (lock) {
                return marketStore.state.userId === lock.userId && marketStore.state.userId !== lock.managerId;
            });

            if (IsLockedForMe) {
                this.lockType = "self";
                return;
            }

            var IsLockedForAll = _.find(data, function (lock) {
                return marketStore.state.userId === lock.userId && marketStore.state.userId === lock.managerId;
            });

            if (IsLockedForAll) {
                this.lockType = "all";
                this.AllLockActive = true;
                return;
            }

            this.lockType = "sel";

            _.each(self.Users, function (User) {
                var userLock = _.find(data, function (lock) {
                    return User.id === lock.userId;
                });

                if (userLock !== undefined) {
                    User.isActive = true;
                } else {
                    User.isActive = false;
                }
            });
        },
        UpdateLocks: function () {
            if (this.lockType === 'unlock' || this.newLocks.length === 0) {
                window.client.deleteMarketLocks(this.marketId.toString(), this.eventId.toString(), this.UpdateLockCompleted);
            } else {
                window.client.updateMarketLocks(this.newLocks, this.UpdateLockCompleted);
            }
        },
        UpdateLockCompleted: function (data) {
            $("#modalLocker").modal('hide');
            // this.hideLocker();
        }
    }
});

Vue.component('market-orders', {
    props: ['orders'],
    template: `
        <div>
            <div :id="order.orderId" 
                class="row" 
                v-for="order in orders" 
                v-bind:class="{ 'order-b': order.IsBack, 'order-l': order.IsLay }"
            >
                <div class="col-4">{{ order.rn }}</div>
                <div class="col-2 no-pad">{{ order.up }}</div>
                <div class="col-2 no-pad">{{ order.us | format }}</div>
                <div class="col-2 no-pad">{{ order.bn }}</div>
                <div class="col-2 no-pad">{{ order.mn }}</div>
            </div>
        </div>
    `
});

class WebApiClient {
    constructor() { }

    getUsers(callback) {
        $.ajax({
            url: '/api/Users?IsDirectChild=true',
            success: callback,
            dataType: 'json'
        });
    }

    getMarketLocks(marketId, eventId, callback) {
        $.ajax({
            url: '/api/marketlocker?marketId=' + marketId + '&eventId=' + eventId,
            success: callback,
            dataType: 'json'
        });
    }

    updateMarketLocks(locks, callback) {
        $.ajax({
            type: "POST",
            url: '/api/marketlocker',
            data: JSON.stringify(locks),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: callback,
            error: function (exception) { }
        });
    }

    deleteMarketLocks(marketId, eventId, callback) {
        $.ajax({
            type: "DELETE",
            url: '/api/marketlocker/0?marketId=' + marketId + '&eventId=' + eventId,
            dataType: "json",
            success: callback
        });
    }
}

var client = new WebApiClient();

if ($("#Pnl-Orders").length > 0) {
    OrderVue = new Vue({
        el: "#Pnl-Orders",
        data: {
            Matched: [],
            UnMatched: [],
            Active: false,
            isLine: false
        },
        computed: {
            marketId: function () {
                return marketStore.state.marketId;
            }
        },
        methods: {
            ListOrders: function () {

                if (marketStore.state.eventId === null || marketStore.state.eventId === '')
                    return;

                var self = this;

                var resource = 'orders/event?MaxResults=50&EventId=' + marketStore.state.eventId;
                resource += "&MarketId=" + marketStore.state.marketId;

                if (marketStore.state.marketType.toLowerCase() === 'casino') {
                    resource = 'orders/casino?id=' + marketStore.state.eventId;
                }

                var url = svc_prefix + resource;

                $.getJSON(url, function (result) {
                    // self.RenderOrders(self, result);
                    self.RenderOrdersPosition(result);
                    return false;
                })
                .fail(function (exception) {
                    ErrorHandler(exception.responseJSON);
                });
            },
            RenderOrdersPosition: function (result) {
                this.RenderOrders(this, result['vOrders']);
                window.MarketPL = result['pls'];
            },
            RenderOrders: function (self, Orders) {

                // matched 
                var MatchedNew = Orders.filter(function (order) {
                    return order.ms > 0;
                });

                var IsRenderMatched = MatchedNew.length !== self.Matched.length;
                if (self.Matched.length > 0 && MatchedNew.length > 0) {
                    IsRenderMatched = IsRenderMatched || self.Matched[0].id !== MatchedNew[0].id;
                }

                if (IsRenderMatched) {
                    // empty and refill
                    self.Matched = [];
                    MatchedNew.forEach(function (Order) {
                        Order.IsBack = Order.bs === "B";
                        Order.IsLay = Order.bs === "L";

                        self.Matched.push(Order);
                    });
                }

                // UnMatched
                var UnMatchNew = Orders.filter(function (order) {
                    return (order.us - order.ms) > 0;
                });

                self.UnMatched = [];
                UnMatchNew.forEach(function (Order) {
                    Order.IsBack = Order.bs === "B";
                    Order.IsLay = Order.bs === "L";

                    self.UnMatched.push(Order);
                });
            },
            Cancel: function (Order) {
                var self = this;
                var qs = svc_prefix + 'orders/' + Order.id;

                $.ajax({
                    type: "DELETE",
                    url: qs,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (result) {
                        GetFunds();
                    },
                    error: function (exception) {
                        ErrorHandler(exception.responseJSON);
                    }
                });
            },
            ShowAllOrders: function () {

                var fullPath = "/Common/Orders?MarketId=" + marketStore.state.marketId + "&EventId=" + marketStore.state.eventId;

                newwindow = window.open(fullPath, "OrdersList", 'height=500,width=600,titlebar=0,menubar=0');
                if (window.focus) { newwindow.focus(); }
                return false;
            },
            ShowFullPosition: function (MarketId) {
                fullPath = "/" + getUserDirectory() + "/FullPosition?MarketId=" + MarketId;

                newwindow = window.open(fullPath, "MarketFullPos", 'height=500,width=1200,titlebar=0,menubar=0');
                if (window.focus) { newwindow.focus(); }
                return false;
            }
        }
    });
}



if ($("#MarketData").length > 0) {
    MarketVue = new Vue({
        el: "#MarketData",
        data: {
            market: {
                event: {}
            },
            runnerUnavailable: ['suspended', 'ball running', 'removed'],
            runners: [],
            startTime: '',
            status: '',
            scores: null,
            betDelay: 0,
            winners: 0,
            sinceStart: '',
            pos: [],
            IsLoaded: false,
            score: { team1: null, commentry: null },
            subMarketIds: [],
            catalogues: [],
            scoreLines: [],
            isLine: false,
            IsVoice: false,

            bookmakerMarketName: "Bookmaker",
        },
        created: function ()
        {
            document.getElementById("loadedmarkettoshow").classList.remove("d-none");
        },
        watch: {
            subMarketIds: function () {
                // add new sub markets
                if (this.subMarketIds.length > 0) {
                    _.each(this.subMarketIds, this.LoadCatalogue);
                }
                // remove sub markets
                catIds = [];
                if (this.catalogues.length > this.subMarketIds.length) {
                    catIds = _.map(this.catalogues, function (catalog) {
                        return catalog.marketId;
                    });
                    var removeableIds = _.without(catIds, this.subMarketIds);
                    console.log(removeableIds);
                    this.catalogues = _.filter(this.catalogues, function (catalog) {
                        var index = _.indexOf(removeableIds, catalog.marketId);
                        console.log(index);
                        return index === -1;
                    });
                }
            },
            score: function (newVal, oldVal) {
                if (newVal !== null && newVal.commentry !== null) {
                    if (oldVal.commentry !== newVal.commentry) {
                        this.PlayCommentry(newVal.commentry);
                    }
                }
            }
        },
        computed: {
            prettyDate: function () {
                if (this.startTime === '') return '';
                return moment(this.startTime).format('D MMM, YYYY h:mm a');
            },
            fromNow: function () {
                if (this.startTime === '') return '';
                return moment(this.startTime).fromNow();
            },
            CurrentMarketIdsHash: function () {
                var ids = _.map(this.catalogues, function (catalog) { return catalog.marketId; });
                ids = _.sortBy(ids, function (id) { return id; });
                return ids.join(',');
            },
            HasBookmakerMarket: function () {
                var m = _.find(this.catalogues, function (catalogue) {
                    return catalogue.marketName == this.bookmakerMarketName;
                });
                
                return m !== undefined;
            },
            HasFigureMarket: function () {
                var m = _.find(this.catalogues, function (item) {
                    return item.marketType === "FIGURE";
                });
                return m !== undefined;
            },
            HasOddFigureMarkets: function () {
                return _.filter(this.catalogues, function (item) {
                    return item.marketType === "ODD_FIGURE";
                });
            },
            HasTossMarkets: function () {
                return _.filter(this.catalogues, function (item) {
                    return item.marketType === "TOSS";
                });
            },
            IsSoccer: function () {
                return this.market.eventTypeId == 1;
            },
            IsTennis: function () {
                return this.market.eventTypeId == 2;
            }
        },
        methods: {
            place: function (runner, side, runnerMarketId, ControlIndex) {
                this.IsLineMarket(runnerMarketId);
                OrderVue.Active = true;

                var price = 0;
                switch (ControlIndex) {
                    case 1:
                        price = side === "B" ? runner.price1 : runner.lay1;
                        break;

                    case 2:
                        price = side === "B" ? runner.price2 : runner.lay2;
                        break;

                    case 3:
                        price = side === "B" ? runner.price3 : runner.lay3;
                        break;
                }


                $("#bet-price").val(price);
                $("#bet-size").val(this.GetDefaultStake());
                Order.selectionId = runner.selectionId;
                Order.marketId = runnerMarketId;
                Order.side = side;
                $("#bet-runner").text(runner.runnerName);
                CalcPL();

                if (side === "L") {
                    $("#Place-Order,#PrInc,#PrDec").removeClass('btn-info');
                    $("#Place-Order,#PrInc,#PrDec").addClass('btn-danger');
                    $("#bet-slip-head").removeClass('bg-primary');
                    $("#bet-slip-head").addClass('bg-danger');
                } else {
                    $("#Place-Order,#PrInc,#PrDec").addClass('btn-info');
                    $("#Place-Order,#PrInc,#PrDec").removeClass('btn-danger');
                    $("#bet-slip-head").removeClass('bg-danger');
                    $("#bet-slip-head").addClass('bg-primary');
                }
            },

            IsRunnerDisabled: function (status) {
                if (status === undefined
                    || status === ''
                    || status === null) {
                    return false;
                }
                return this.runnerUnavailable.includes(status.toLowerCase());
            },

            GetDefaultStake: function () {
                var btnStake = $('.btn-stake')[0];
                if (btnStake) {
                    return $(btnStake).data('amount');
                }
                return 1000;
            },
            ResetPosition: function () {
                market.market.runners.forEach(function (runner) { runner.handicap = 0; });
            },
            FormatPosition: function () {
                market.market.runners.forEach(function (runner) { numeral(runner.handicap).format('0,0[.]00'); });
            },
            FetchCatalogs: function (marketIds) {
                var params = marketIds.join(',');
                var qs = svc_prefix + 'markets/catalogs/?ids=' + params;
                $.getJSON(qs, this.RenderSubMarkets);
            },
            RenderSubMarkets: function (Catalogs) {
                var self = this;

                LoadingSubMarkets = false;

                if (Catalogs != "undefined" && Catalogs !== null && Catalogs.length > 0) {
                    _.each(Catalogs, function (catalog) {
                        catalog['status2'] = null;
                        self.catalogues.push(catalog);
                    });
                    self.SortSubMarkets();
                }
            },
            SortSubMarkets: function () {
                var highPriority = _.filter(this.catalogues, function (sm) {
                    return sm.sortPriority == 1;
                });
                var lowPriority = _.filter(this.catalogues, function (sm) {
                    return sm.sortPriority != 1;
                });

                highPriority = _.sortBy(highPriority, 'marketName');
                lowPriority = _.sortBy(lowPriority, 'marketName');

                this.catalogues = _.union(highPriority, lowPriority);
            },
            LoadCatalogue: function (MarketId) {
                cat = _.find(this.catalogues, function (catalogue) {
                    return catalogue.marketId === MarketId;
                });
                if (cat === undefined) {
                    this.GetSubMarket(MarketId);
                }
            },
            GetSubMarket: function (MarketId) {
                console.log("GetSub: " + MarketId);
                var qs = svc_prefix + 'Markets/Catalog2/?id=' + MarketId;
                $.getJSON(qs, this.RenderSubMarket);
            },
            RenderSubMarket: function (Catalog) {
                if (Catalog !== undefined || Catalog !== null) {
                    this.catalogues.push(Catalog);
                }
            },
            RemoveCatalogues: function (RemovedMarketIds) {
                if (RemovedMarketIds.length === 0) return;
                this.catalogues = _.filter(this.catalogues, function (catalog) {
                    if (catalog === undefined || catalog === null) return false;
                    var elem = _.find(RemovedMarketIds, function (MID) {
                        return MID !== catalog.marketId;
                    });
                    return elem !== undefined;
                });
            },
            RenderSubMarketData: function (Book) {
                market = _.find(this.catalogues, function (catalog) {
                    return catalog.marketId === Book.id;
                });
                if (market === undefined) return;

                this.UpdateRunnerData(Book, market, window.MarketPL);

                /*market.runners.forEach(function (runner) {
                    var soldier = Book.runners.find(function (item) {
                        return item.id === runner.selectionId.toString();
                    });

                    var PL = window.MarketPL.find(function (plItem) {
                        return plItem.selectionId === runner.selectionId
                            && plItem.marketId === Book.id;
                    });

                    if (soldier !== undefined) {
                        if (soldier.status === 'WINNER') {
                            // MarkWinner(soldier.id);
                            return;
                        }
                        runner.price1 = UpdatePriceCell(runner.price1, soldier.price1, 'b1', soldier.id, backColor);
                        runner.size1 = UpdatePriceCell(runner.size1, soldier.size1, 'bs1', soldier.id, backColor);

                        runner.lay1 = UpdatePriceCell(runner.lay1, soldier.lay1, 'l1', soldier.id, layColor);
                        runner.ls1 = UpdatePriceCell(runner.ls1, soldier.ls1, 'ls1', soldier.id, layColor);

                        runner.price2 = soldier.price2;
                        runner.size2 = soldier.size2;
                        runner.price3 = soldier.price3;
                        runner.size3 = soldier.size3;
                        runner.lay2 = soldier.lay2;
                        runner.lay3 = soldier.lay3;
                        runner.ls2 = soldier.ls2;
                        runner.ls3 = soldier.ls3;

                        runner.status = soldier.status;

                        if (PL !== undefined) {
                            runner.ifWin = PL.ifWin;
                            runner.ifLose = PL.ifLose;
                        }
                    }
                });*/
            },
            UpdateRunnerData: function (Book, Catalog, Pls) {
                if (Catalog === null || Catalog.runners === null) {
                    return;
                }

                var runnersCount = Catalog.runners.length;

                if (runnersCount === 0) {
                    return;
                }

                var self = this;

                for (let i = 0; i < runnersCount; i++) {

                    var soldier = Book.runners.find(function (item) {
                        return item.id === Catalog.runners[i].selectionId.toString();
                    });

                    if (Pls !== null) {
                        var PL = Pls.find(function (plItem) {
                            return plItem.selectionId === Catalog.runners[i].selectionId
                                && plItem.marketId === Book.id;
                        });
                    }

                    if (soldier !== undefined) {
                        if (soldier.status === 'WINNER') {
                            self.MarkWinner(soldier.id);
                        }

                        // self.UpdateRunnersPriceSize(Catalog.runners[i], soldier);
                        // UpdatePriceCell(runner.price1, soldier.price1, 'b1', soldier.id, backColor);

                        Catalog.runners[i].price1 = UpdatePriceCell(Catalog.runners[i].price1, soldier.price1, 'b1', soldier.id, backColor);
                        Catalog.runners[i].size1 = UpdatePriceCell(Catalog.runners[i].size1, soldier.size1, 'bs1', soldier.id, backColor);

                        Catalog.runners[i].lay1 = UpdatePriceCell(Catalog.runners[i].lay1, soldier.lay1, 'l1', soldier.id, layColor);
                        Catalog.runners[i].ls1 = UpdatePriceCell(Catalog.runners[i].ls1, soldier.ls1, 'ls1', soldier.id, layColor);

                        Catalog.runners[i].price2 = soldier.price2;
                        Catalog.runners[i].size2 = soldier.size2;
                        Catalog.runners[i].price3 = soldier.price3;
                        Catalog.runners[i].size3 = soldier.size3;
                        Catalog.runners[i].lay2 = soldier.lay2;
                        Catalog.runners[i].lay3 = soldier.lay3;
                        Catalog.runners[i].ls2 = soldier.ls2;
                        Catalog.runners[i].ls3 = soldier.ls3;

                        Catalog.runners[i].status = soldier.status;

                        if (PL !== undefined) {
                            if (PL.ifWin != Catalog.runners[i].ifWin) {
                                var runner = Catalog.runners[i];
                                runner.ifWin = PL.ifWin;
                                runner.ifLose = PL.ifLose;

                                this.$set(Catalog.runners, i, runner);
                            }
                        } else {
                            Catalog.runners[i].ifWin = '';
                            Catalog.runners[i].ifLose = '';
                        }
                    }
                }
            },
            GetFullLinePosition: function (marketId) {
                var qs = svc_prefix + 'Orders/LinePosition?MarketId=' + marketId;
                $.getJSON(qs, this.RenderLinePosition);
            },
            RenderLinePosition: function (result) {
                this.scoreLines = result;
            },
            fullBook: function (marketId) {
                // ShowFancyPosition();
                var url = "/Common/Position?id=" + marketId;
                newwindow = window.open(url, "Fancy Position " + marketId, 'height=500,width=400,titlebar=0,menubar=0');
                if (window.focus) { newwindow.focus(); }
            },
            IsLineMarket: function (marketId) {
                if (this.market.marketId === marketId) {
                    if (this.market.hasOwnProperty("bettingType")) {
                        Order.IsLine = this.market.bettingType === 'LINE';
                    } else {
                        Order.isLine = this.market.description.bettingType === "LINE";
                    }
                } else {
                    var market = _.find(this.catalogues, function (catalogue) {
                        return catalogue.marketId === marketId;
                    });

                    if (market === undefined) {
                        Order.isLine = false;
                    } else {
                        if (market.hasOwnProperty("bettingType")) {
                            Order.isLine = market.bettingType === "LINE";
                        } else {
                            Order.isLine = market.description.bettingType === "LINE";
                        }
                    }
                }
                OrderVue.isLine = Order.isLine;
                return Order.isLine;
            },
            IsBookmakerMarket: function (marketId) {
                var market = _.find(this.catalogues, function (catalogue) {
                    return catalogue.marketId === marketId;
                });
                if (market === undefined) {
                    return false;
                } else if (market.marketName == this.bookmakerMarketName) {
                    return true;
                }
                return false;
            },
            PlayCommentry: function (commentryText) {
                if (this.IsVoice) {
                    CommentryPlayer.Play(commentryText);
                }
            },
            ShowFullPosition: function (MarketId) {
                fullPath = "/" + getUserDirectory() + "/FullPosition?MarketId=" + MarketId;

                newwindow = window.open(fullPath, "MarketFullPos", 'height=500,width=500,titlebar=0,menubar=0');
                if (window.focus) { newwindow.focus(); }
                return false;
            }
        }

    });
}

function getUserDirectory() {
    var userDir = 'Markets';
    var PathName = document.location.pathname.split('/');
    if (PathName[1].length > 0) {
        userDir = PathName[1];
    }
    return userDir;
}

function PlayVid(ch) {
    var url = 'https://livemediasystem.com/bf/c.php?ch=c' + ch + '&user=uuu.001';
    document.getElementById('vidFrame').src = url;
}

function UpdatePriceCell(oldVal, newVal, index, selectionId, bgcolor) {
    if (oldVal === newVal) return newVal;
    bg = oldVal > newVal ? plusFlash : minusFlash;
    var el = "#" + index + "-" + selectionId;
    $(el).flash(bgcolor, bg, 300);
    return newVal;
}

function ShowFancyPosition() {
    $(".dialog-fancy").dialog({
        autoOpen: true,
        height: 400,
        width: 250,
        modal: false
    });
}