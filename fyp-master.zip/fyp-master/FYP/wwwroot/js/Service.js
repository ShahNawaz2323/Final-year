﻿/*! E3 General 
 * 2019 BetPro
 */
var svc_prefix = "/api/";

var cid = "";

function dConsole(msg) {
    if (typeof dMode !== "undefined" && dMode) {
        console.log(msg);
    }
}

$(function () {
    /*jQuery('#ReportFrom,#ReportTo').datetimepicker({
        format: 'Y/m/d H:i'
    });*/

    GetFunds();
    $(".Report-EventTypeId-new-single").click(function (e) {
        e.preventDefault();
        var ClientId = $(this).data("id");
        
        $("#ClientId").val(ClientId);

        $("#ReportFilterForm").find('button').click();
        return true;
    });
    
    $(".Report-EventTypeId-new-frontPL").click(function (e) {
        e.preventDefault();
        var ClientId = $(this).data("id");

        updateDates();

        $("#EventTypeId").val(ClientId);
        $("#ReportFilterForm").submit();

        return true;
    });
    
    $(".Commision-eventtypeid-For3rd").click(function (e) {
        e.preventDefault();
        var ClientId = $(this).data("id");
        $("#EventTypeId").val(ClientId);

        $("#ReportFilterForm").find('button').click();
        return true;
    });

    //Daily Reports functions
    $(".Report-Client-new").click(function (e) {
        e.preventDefault();
        var ClientId = $(this).data("id");
       
        var From = $(this).data("from");
        var To = $(this).data("to");
        var Url = $(this).data("url");

        document.getElementById("marketreportsdivdr").style.display = 'none';
        document.getElementById("loadinggif").style.display = 'block';

        cid = ClientId;
        loadDR(ClientId, From, To, Url);
        return true;
    });
    function loadDR(id, From, To, url) {
        $.ajax({
            type: 'Get',
            url: url + "&Uid=" + id + "&from=" + From + "&to=" + To,

            success: function (result) {
                document.getElementById("loadinggif").style.display = 'none';
                document.getElementById("sportreportdivdr").innerHTML = result;
                $(".Report-EventTypeId-new").click(function (e) {
                    e.preventDefault();
                    document.getElementById("loadinggif").style.display = 'block';
                    var EventTypeId = $(this).data("id");
                    var Url = $(this).data("url");

                    load2dr(cid, EventTypeId, From, To, Url);

                    return false;
                });

                if (result.value === null ||
                    result.value === undefined ||
                    result.value.length === 0) {
                    document.getElementById("loadinggif").style.display = 'none';
                    return true;

                }

            },

            error: function (exception) {
                document.getElementById("loadinggif").style.display = 'none';
            }
        });

    }
    function load2dr(id, etid, From, To, url) {
        $.ajax({
            type: 'Get',
            url: url + "&Uid=" + id + " &etid=" + etid + "&from=" + From + "&to=" + To,
            success: function (result) {
                document.getElementById("loadinggif").style.display = 'none';
                document.getElementById("marketreportsdivdr").style.display = 'block';
                document.getElementById("marketreportsdivdr").innerHTML = result;

                convertAllToClientTime();
            },
            error: function (exception) {
                document.getElementById("loadinggif").style.display = 'none';
            }
        });
    }

    //Book Detail Functions
    $(".Report-Client").click(function (e) {
        e.preventDefault();
        var ClientId = $(this).data("id");
        var From = localDateToUtc($("#From").val());
        var To = localDateToUtc($("#To").val());
        var Url = $(this).data("url");
        
        document.getElementById("marketreportsdiv").style.display = 'none';
        document.getElementById("loadinggif").style.display = 'block';

        load(ClientId, From, To, Url);
        return true;
    });
    
    if ($(".tbl-datatable").length > 0) {
        $(".tbl-datatable").DataTable({
            "order": [[0, "asc"]]
        });
    }
    
    if ($(".dt-desc").length > 0) {
        $(".dt-desc").DataTable({
            "order": [[0, "desc"]]
        });
    }

    if (document.location.href.indexOf("Index?type=1") >= 0) {
        $("#final-sheet").removeClass('btn-outline-primary');
        $("#final-sheet").addClass('btn-primary');
    } else if (document.location.href.indexOf('Reports/Detail2') >= 0) {
        $("#book-detail-2").removeClass('btn-outline-primary');
        $("#book-detail-2").addClass('btn-primary');
    }else if (document.location.href.indexOf('Reports/Daily') >= 0) {
        $("#daily").removeClass('btn-outline-primary');
        $("#daily").addClass('btn-primary');
    } else if (document.location.href.indexOf('Reports/Commission') >= 0) {
        $("#commission").removeClass('btn-outline-primary');
        $("#commission").addClass('btn-primary');
    } else if (document.location.href.indexOf('Reports/Comm2') >= 0) {
        $("#commission2").removeClass('btn-outline-primary');
        $("#commission2").addClass('btn-primary');
    } else if (document.location.href.indexOf('Reports') >= 0) {
        $("#book-detail").removeClass('btn-outline-primary');
        $("#book-detail").addClass('btn-primary');
    } else if (document.location.href.indexOf('Accounts/Chart') >= 0) {
        $("#ledger").removeClass('btn-outline-primary');
        $("#ledger").addClass('btn-primary');
    } else if (document.location.href.indexOf('Accounts/Shares') >= 0) {
        $("#shares").removeClass('btn-outline-primary');
        $("#shares").addClass('btn-primary');
    } 



    if ($("#news-ticker-foot").length > 0) {
        $("#news-ticker-foot").webTicker({
            height: '25px'
        });
    }    

    setInterval(UpdateUserData, 10000);
    GetNews();

    $("#searchUsername").keypress(function () {

    });
});

function load(id, From, To, url) {
    cid = id;
    $.ajax({
        type: 'Get',
        url: url + "&Uid=" + id + "&from=" + From + "&to=" + To,

        success: function (result) {
            document.getElementById("loadinggif").style.display = 'none';
            document.getElementById("sportreportdiv").innerHTML = result;
            
            bindEventTypeLinks();

            if (result.value == null ||
                result.value == undefined ||
                result.value.length == 0) {
                document.getElementById("loadinggif").style.display = 'none';
                return true;
            }
        },

        error: function (exception) {
            document.getElementById("loadinggif").style.display = 'none';
        }
    });

}

var d2etid = "";
function bindEventTypeLinks() {
    $(".Report-EventTypeId").click(function (e) {
        e.preventDefault();
        document.getElementById("loadinggif").style.display = 'block';
        if ($(this).parents('.report-left').length > 0) {
            $(".report-Right").hide();
        }
        var EventTypeId = $(this).data("id");
        d2etid = EventTypeId;
        var Url = $(this).data("url");

        var From = localDateToUtc($("#From").val());
        var To = localDateToUtc($("#To").val());

        load2(cid, EventTypeId, From, To, Url);

        return false;
    });
}
function load2(id, etid, From, To, url) {
    $.ajax({
        type: 'Get',
        url: url + "&Uid=" + id + " &etid=" + etid + "&from=" + From + "&to=" + To,
        success: function (result) {
            $(".report-Right").show();
            document.getElementById("loadinggif").style.display = 'none';
            document.getElementById("marketreportsdiv").style.display = 'block';
            document.getElementById("marketreportsdiv").innerHTML = result;

            convertAllToClientTime();

            $(".Report-Client-DR2").click(function (e) {
                e.preventDefault();
                document.getElementById("loadinggif").style.display = 'block';
                var clientid = $(this).data("id");
                load3(clientid, d2etid, From, To);

                return false;
            });


        },
        error: function (exception) {
            document.getElementById("loadinggif").style.display = 'none';
        }
    });
}

function load3(id,etid, From, To) {
    $.ajax({
        type: 'Get',
        url: "/Reports/Index?handler=MarketsReports" + "&Uid=" + id + " &etid=" + etid + "&from=" + From + "&to=" + To,
        success: function (result) {
            document.getElementById("loadinggif").style.display = 'none';
            document.getElementById("marketreportsdivdt2").style.display = 'block';
            document.getElementById("marketreportsdivdt2").innerHTML = result;

            convertAllToClientTime();
        },
        error: function (exception) {
            document.getElementById("loadinggif").style.display = 'none';
        }
    });
}
    
if ($("#searchUsers").length > 0) {    
    searchVM = new Vue({
        el: "#searchUsers",
        data: {
            query: '',
            users: [],

            isLoading: false
        },
        created: function() {
        },
        methods: {
            search: function () {
                if (this.query === '') return;
                this.isLoading = true;
                var self = this;
                $.get(svc_prefix + 'users/search?query=' + this.query, function (result) {
                    self.isLoading = false;
                    if (result !== null) {
                        self.users = result;
                    }
                });
            }
        }
    });
    var countries = [];
    //function call on each key press
    function singlekeypres() {
        var val = document.getElementById('myInput').value;
        var lngh = val.length;
        if (lngh >= 2) {
            $.ajax({
                type: 'Get',
                url: svc_prefix + 'Users/',
                success: function (result) {
                    self.users = result;
                    var lenghth = self.users.length - 1;
                    countries.push(self.users[lenghth].username);
                },
                error: function (exception) {
                }
            });
            var uniqueNames = [];
            $.each(countries, function (i, el) {
                if ($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
            });
            autocomplete(document.getElementById("myInput"), uniqueNames);
        }
        



    }

}

function autocomplete(inp, arr) {
    /*the autocomplete function takes two arguments,
    the text field element and an array of possible autocompleted values:*/
    var currentFocus;
    /*execute a function when someone writes in the text field:*/
    inp.addEventListener("input", function (e) {
        var a, b, i, val = this.value;
        /*close any already open lists of autocompleted values*/
        closeAllLists();
        if (!val) { return false; }
        currentFocus = -1;
        /*create a DIV element that will contain the items (values):*/
        a = document.createElement("DIV");
        a.setAttribute("id", this.id + "autocomplete-list");
        a.setAttribute("class", "autocomplete-items");
        /*append the DIV element as a child of the autocomplete container:*/
        this.parentNode.appendChild(a);
        /*for each item in the array...*/
        for (i = 0; i < arr.length; i++) {
            /*check if the item starts with the same letters as the text field value:*/
            if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                /*create a DIV element for each matching element:*/
                b = document.createElement("DIV");
                /*make the matching letters bold:*/
                b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                b.innerHTML += arr[i].substr(val.length);
                /*insert a input field that will hold the current array item's value:*/
                b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                /*execute a function when someone clicks on the item value (DIV element):*/
                b.addEventListener("click", function (e) {
                    /*insert the value for the autocomplete text field:*/
                    inp.value = this.getElementsByTagName("input")[0].value;
                    /*close the list of autocompleted values,
                    (or any other open lists of autocompleted values:*/
                    closeAllLists();
                });
                a.appendChild(b);
            }
        }
    });
    /*execute a function presses a key on the keyboard:*/
    inp.addEventListener("keydown", function (e) {
        var x = document.getElementById(this.id + "autocomplete-list");
        if (x) x = x.getElementsByTagName("div");
        if (e.keyCode == 40) {
            /*If the arrow DOWN key is pressed,
            increase the currentFocus variable:*/
            currentFocus++;
            /*and and make the current item more visible:*/
            addActive(x);
        } else if (e.keyCode == 38) { //up
            /*If the arrow UP key is pressed,
            decrease the currentFocus variable:*/
            currentFocus--;
            /*and and make the current item more visible:*/
            addActive(x);
        } else if (e.keyCode == 13) {
            /*If the ENTER key is pressed, prevent the form from being submitted,*/
            e.preventDefault();
            if (currentFocus > -1) {
                /*and simulate a click on the "active" item:*/
                if (x) x[currentFocus].click();
            }
        }
    });
    function addActive(x) {
        /*a function to classify an item as "active":*/
        if (!x) return false;
        /*start by removing the "active" class on all items:*/
        removeActive(x);
        if (currentFocus >= x.length) currentFocus = 0;
        if (currentFocus < 0) currentFocus = (x.length - 1);
        /*add class "autocomplete-active":*/
        x[currentFocus].classList.add("autocomplete-active");
    }
    function removeActive(x) {
        /*a function to remove the "active" class from all autocomplete items:*/
        for (var i = 0; i < x.length; i++) {
            x[i].classList.remove("autocomplete-active");
        }
    }
    function closeAllLists(elmnt) {
        /*close all autocomplete lists in the document,
        except the one passed as an argument:*/
        var x = document.getElementsByClassName("autocomplete-items");
        for (var i = 0; i < x.length; i++) {
            if (elmnt != x[i] && elmnt != inp) {
                x[i].parentNode.removeChild(x[i]);
            }
        }
    }
    /*execute a function when someone clicks in the document:*/
    document.addEventListener("click", function (e) {
        closeAllLists(e.target);
    });
}

function UpdateUserData() {
    GetNews();
    GetFunds();
}
function GetNews() {
    var mid = "";
    if (typeof (marketId) !== "undefined") {
        mid = marketId;
    }
    var qs = svc_prefix + 'users/news?marketId=' + mid;
    $.get(qs, function (result) {
        UpdateTicker(result.text);
        BetSizes = result.betSizes;
        return false;
    });
}

var BetSizes = null;

function UpdateTicker(news) {
    if ($("#news-ticker-foot").length > 0) {
        $("#news-ticker-foot").webTicker('update',
            '<li data-update="item1"><b>' + news + '</b></li>',
            'swap',
            true,
            false
        );
    }

    if (news === "" || news === undefined || news === null) {
        $("#news-ticker-foot").hide();

        if ($("#sticky-footer").length > 0) {
            $("#sticky-footer").hide();
        }
    } else {
        $("#news-ticker-foot").show();

        if ($("#sticky-footer").length > 0) {
            $("#sticky-footer").show();
        }
    }
}

SetupHeaders();

function SetupHeaders() {
    // var User = window.JSON.parse(localStorage.getItem("PK"));
    var token = localStorage.getItem("PK");
    if (token === null) return;
    $.ajaxSetup({
        headers: { 'Authorization': 'Bearer ' + token }
    });
}

/// Sport Highlights
var HighlightVM;
function RenderHighlights() {
    HighlightVM = new Vue({
        el: "#highlights",
        data: {
            Markets: []
        },
        methods: {
            GetMarkets: function () {
                var self = this;
                var qs = svc_prefix + 'Markets/';
                $.getJSON(qs, function (result) {
                    self.RenderMarkets(self, result);
                    return false;
                })
                    .fail(function (exception) {
                        ErrorHandler(exception.responseJSON);
                    });
            },
            RenderMarkets: function (self, Markets) {
                Markets.forEach(function (Market) {
                    Market["link"] = '/Customer/Market#!' + Market.marketId;
                    Market["link2"] = '/Markets/#!' + Market.marketId;
                });
                self.Markets = Markets;
            }
        },
        created: function () {
            this.GetMarkets();
        }
    });
    // HighlightVM.GetMarkets();
}
/// End Sport Highlights

function ErrorHandler(exception) {
    if (exception === undefined) return;
    var errors = ["MISSING_AUTH_TOKEN", "INVALID_SESSION"];
    if (_.includes(errors, exception.error)) {
        document.location.href = "/Users/Login";
    }
}

function GetFunds() {
    var qs = svc_prefix + 'users/funds';
    $.getJSON(qs, function (result) {
        RenderFunds(result);
        return false;
    })
    .fail(function (exception) {
        ErrorHandler(exception.responseJSON);
    });
}

function RenderFunds(wallet) {
    var bal = numeral(wallet.available).format('0,0[.]00'); //format('0,0');
    var liable = numeral(wallet.liable).format('0,0[.]00');
    $("#funds").text(bal);
    $("#wallet-liable").text(liable);
    $('.designation').text('B: ' + bal + ' | L: ' + liable +' | ');
}

function IsMobile() {
    if (/Mobi|Android/i.test(navigator.userAgent)) {
        return true;
    }
    return false;
}

function IsPasswordStrong(pwd) {
    var Exp = /((^[0-9]+[a-z]+)|(^[a-z]+[0-9]+))+[0-9a-z]+$/i;
    return pwd.match(Exp) !== null;
}

// filter to format amounts
Vue.filter('format', function (value) {
    if (value === 0 || value === null || value === undefined) return '';
    return value === '' ? null : numeral(value).format('0,0');
});

Vue.filter('formatForiegn', function (value) {
    if (value === 0
        || value === ''
        || value === null
        || value === undefined) return '';
    return value < 1000 ? numeral(value).format('0') : numeral(value).format('0.0a').toLocaleUpperCase();
});



Vue.filter('formatForiegn2', function (value) {
    if (value === 0
        || value === ''
        || value === null
        || value === undefined) return '';
    return value < 1000 ? numeral(value).format('0') : numeral(value).format('0a').toLocaleUpperCase();
});



function GetDeviceIdentity() {
    var deviceIdentity = "";
    if (typeof (WURFL) === "undefined") {
        return deviceIdentity;
    } else {
        deviceIdentity = btoa(WURFL.complete_device_name);
    }
    return deviceIdentity;
}