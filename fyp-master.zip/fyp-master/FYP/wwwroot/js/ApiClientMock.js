﻿class WebApiClientMock {
    constructor() { }

    searchAll(username, callback) {
        const data = [
            { 'username': 'hammad', 'dealer': 'jz.dealer', 'super': 'jz.master' },
            { 'username': 'hammad123', 'dealer': 'jz.pkd', 'super': 'jz.master' },
            { 'username': 'hammadxyz', 'dealer': 'jz.DHM', 'super': 'jz.superD' }
        ];
        callback(data);
    }

    getMarketLocks(marketId, eventId, callback) {
        var data = [];
        if (marketId !== '') {
            data = [
                { id: 1, marketId: marketId, eventId: null, userId: 55, managerId: 54 },
                { id: 2, marketId: marketId, eventId: null, userId: 1021, managerId: 54 }
            ];

            var data2 = [
                { id: 1, marketId: marketId, eventId: null, userId: 54, managerId: 54 }
            ];

            var data3 = [
                { id: 1, marketId: marketId, eventId: null, userId: 54, managerId: 53 }
            ];
        }
        else {
            data = [
                { id: 1, marketId: null, eventId: marketId, userId: 54, managerId: 53 }
            ];
        }

        callback(data);
    }
}

var clientMock = new WebApiClientMock();