﻿/*! @preserve
 * sounds.js
 * version : 0.0.1
 * author : Ali
 * license : MIT
 */
function Sound(source, volume, loop) {
    this.source = source;
    this.volume = volume;
    this.loop = loop;
    var son;
    this.son = son;
    this.finish = false;
    this.stop = function () {
        document.body.removeChild(this.son);
    };
    this.start = function () {
        if (this.finish) return false;
        this.son = document.createElement("embed");
        this.son.setAttribute("src", this.source);
        this.son.setAttribute("hidden", "true");
        this.son.setAttribute("volume", this.volume);
        this.son.setAttribute("autostart", "true");
        this.son.setAttribute("loop", this.loop);
        document.body.appendChild(this.son);
    };
    this.remove = function () {
        if (this.son !== undefined) {
            document.body.removeChild(this.son);
            this.finish = true;
        }        
    };
    this.init = function (source, volume, loop) {
        this.source = source;
        this.finish = false;
        this.volume = volume;
        this.loop = loop;
    };
}

function Commentry() {
    this.filePath = "/audio/";
    this.fileExt = ".mp3";
    this.sound = new Sound("", 100, false);
    this.soundFile;
    this.src;
    this.init = function () {
        this.soundFile = document.createElement("audio");
        this.soundFile.preload = "auto";
        this.src = document.createElement("source");
    };
    this.Play2 = function (commentryText) {
        var filename = this.CommentryFiles[commentryText];
        console.log(filename);
        if (filename !== '' && filename !== undefined) {
            this.sound.remove();
            this.sound.init(this.filePath + filename + this.fileExt, 100, false);
            this.sound.start();
        }
    };
    this.Play = function (commentryText) {
        var filename = this.CommentryFiles[commentryText];
        if (filename !== '' && filename !== undefined) {
            this.PlaySoundFile(this.filePath + filename + this.fileExt);
        }
    };
    this.PlaySoundFile = function (filePath) {
        var soundFile = document.createElement("audio");
        soundFile.preload = "auto";

        var src = document.createElement("source");
        src.src = filePath;
        soundFile.appendChild(src);

        soundFile.load();
        soundFile.volume = 1;
        soundFile.play();
    };
    this.CommentryFiles = {
        "Ball Chaloo!!": "ballrunning",
        "No Run": "norun",
        "Single": "1run",
        "Double": "2run",
        "3 Runs": "3run",
        "Four": "4run",
        "Six": "New6Run",
        "Wide": "wide",
        "Out": "wicket",
        "No Ball": "noball",
        "Not Out": "notout",
        "Wide + Four": "4_Wide",
        "Review": "Review",
        "Match Delay": "MatchDelay",
        "Sorry": "Sorry",
        "Third Umpire": "3rdUmpire",
        "Rain": "BadWeather",
        "Spinner": "Spinner",
        "Faster": "faster",
        "No Ball + 1": "1_NB",
        "Wide + 1": "1_Wide",
        "No Ball + 4": "4_NB",
        "No Ball + 6": "6_NB",
        "Over": "over"
    };
}

var CommentryPlayer = new Commentry();

// This works on all browsers
function SoundPlayer() {
    var soundFile = document.createElement("audio");
    soundFile.preload = "auto";

    //Load the sound file (using a source element for expandability)
    var src = document.createElement("source");
    src.src = "/audio/faster.mp3";
    soundFile.appendChild(src);

    //Load the audio tag
    //It auto plays as a fallback
    soundFile.load();
    soundFile.volume = 1;
    soundFile.play();
}