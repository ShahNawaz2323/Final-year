﻿/*! WebEx Api Client
 * 2019 BetPro
 */
class WebExApiClient {
    constructor() { }

    Login(username, password, identity, callback, onerror) {

        var userModel = {
            username: username,
            password: password,
            identity: identity
        };

        $.ajax({
            type: "POST",
            url: '/api/Users/authenticate',
            data: JSON.stringify(userModel),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: callback,
            error: onerror
        });
    }
}

clientEx = new WebExApiClient();