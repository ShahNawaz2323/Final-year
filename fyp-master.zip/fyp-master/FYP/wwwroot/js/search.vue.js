﻿/*! User search component 
 * 2019 BetPro
 */
Vue.component('user-search', {
    props: [],
    template: `
        <div class="row">
            <a href="#" v-on:click.prevent="Show()">Advanced Search</a>
            <div class="modal fade" id="users-search-modal" tabindex="-1" role="dialog" aria-labelledby="betSlipMobile" aria-hidden="true">
                <div class="modal-dialog modal-md" role="document">
                    <div class="modal-content">
                        <div class="form-group row">
                            <label>Username: </label>
                            <input type="text" v-model="query">
                            <button class="btn btn-primary" type="button" v-on:click="Search()">Search</button>
                            <img src="/img/preloader.gif">
                        </div>

                        <table class="table">
                        <tr>
                            <th>#</th>
                            <th>Username</th>
                            <th>Dealer</th>
                            <th>Super</th>
                        </tr>
                            <tr v-for="(user, index) in users">
                                <td>{{ index+1 }}</td>
                                <td>{{ user.username }}</td>
                                <td>{{ user.dealer }}</td>
                                <td>{{ user.super }}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
    </div>
    `,
    data: function () {
        return {
            query: '',
            users: []
        }
    },
    methods: {
        Show: function () {
            $("#users-search-modal").modal('show');
        },
        Search: function () {
            if (this.query === '') return;

            clientMock.searchAll(this.query, this.Render);
        },
        Render: function (data) {
            if (data === undefined || data === null) return;

            this.users = data;
        }
    }
});

var client = new WebApiClientMock();