var svc_prefix = "/api/";

var noSleep = new NoSleep();

Vue.component('runner-aggregate', {
    props: ['name', 'back', 'lay', 'marketid'],
    template: `
        <div class="runner-runner">
            <h3 class="runner-name">
                <div class="runner-info">
                    <span class="clippable runner-display-name">
                        <h4 class="clippable-spacer">{{ name }}</h4>
                    </span>
                </div>
            </h3>
            <a class="price-price price-back">
                <span class="price-odd"></span>
                <span class="price-amount"></span>
            </a>
            <a class="price-price price-back">
                <span class="price-odd"></span>
                <span class="price-amount"></span>
            </a>
            <a class="price-price price-back mb-show" id="agg-back" v-on:click="$emit('betslip', 'B')">
                <span class="price-odd">{{ back }}</span>
            </a>
            <a class="price-price price-lay ml-4 mb-show" id="agg-lay" v-on:click="$emit('betslip', 'L')">
                <span class="price-odd">{{ lay }}</span>
            </a>
            <a class="price-price price-lay">
                <span class="price-odd"></span>
                <span class="price-amount"></span>
            </a>
            <a class="price-price price-lay mr-4">
                <span class="price-odd"></span>
                <span class="price-amount"></span>
            </a>
        </div>
    `
});

if ($("#MarketView").length > 0) {
    var MarketVM = new Vue({
        el: "#MarketView",
        data: {
            IsLoaded: false,

            runnerUnavailable: ['suspended', 'ball running', 'removed'],

            Catalog: {
                marketName: 'Loading...',
                runners: []
            },

            LoadingSubMarkets: false,
            MarketPL: [],
            subMarketIds: [],
            subMarkets: [],

            aggregateRun: {
                marketId: '',
                runnerName: '',
                selectionId: 0,
                back: '',
                lay: ''
            },

            IsAggregateOrder: false,

            BookIntervalId: '',
            OrderIntervalId: '',

            score: { team1: null, commentry: null },
            scoreLines: [],
            IsVoice: false,

            SelectMarketName: '',
            SelectFancyPos: [],

            Order: {
                render: false,
                working: false,
                size: 0,
                side: 'B',
                selectionId: 0,
                isLine: false
            },

            OrderPrice: '1.01',

            OldPrice: '1.01',

            Matched: [],
            UnMatched: [],

            displayOn: false,

            backColor: '227,248,255',
            layColor: '255,205,204',
            plusFlash: '0,178,255',
            minusFlash: '255,122,127',

            IsPageVisible: true,

            fromNow: 'starting soon'
        },
        created: function () {
            if (marketId !== undefined && marketId !== '') {
                this.FetchCatalog(marketId);
                this.aggregateRun.runnerName = "";
                this.aggregateRun.marketId = marketId;
            }

            var visibilityChange;
            if (typeof document.hidden !== "undefined") { // Opera 12.10 and Firefox 18 and later support 
                hidden = "hidden";
                visibilityChange = "visibilitychange";
            } else if (typeof document.msHidden !== "undefined") {
                hidden = "msHidden";
                visibilityChange = "msvisibilitychange";
            } else if (typeof document.webkitHidden !== "undefined") {
                hidden = "webkitHidden";
                visibilityChange = "webkitvisibilitychange";
            }
            document.addEventListener(visibilityChange, this.handleVisibilityChange, false);
        },
        computed: {
            sport_icon: function () {
                var sport_img = '';
                switch (this.Catalog.eventTypeId) {
                    case 1:
                        sport_img = "/img/v2/soccer.svg";
                        break;
                    case 2:
                        sport_img = "/img/v2/tennis.svg";
                        break;
                    case 4:
                        sport_img = "/img/v2/cricket.svg";
                        break;
                    case 7:
                        sport_img = "/img/v2/horseracing.svg";
                        break;
                }
                return sport_img;
            },
            prettyDate: function () {
                if (this.Catalog.marketStartTime === '') return '';
                return moment(this.Catalog.marketStartTime).format('MMM D h:mm a');
            },
            /*fromNow: function () {
                if (this.Catalog.marketStartTime === '') return '';
                return moment(this.Catalog.marketStartTime).fromNow();
            },*/
            CurrentMarketIdsHash: function () {
                var ids = _.map(this.subMarkets, function (catalog) { return catalog.marketId; });
                ids = _.sortBy(ids, function (id) { return id; });
                return ids.join(',');
            },
            HasFancyChild: function () {
                var m = _.find(this.subMarkets, function (item) {
                    return item.bettingType === "LINE"
                        && item.marketType !== "LOCAL_FANCY";
                });
                return m !== undefined;
            },
            HasNonFancyChild: function () {
                var m = _.find(this.subMarkets, function (item) {
                    return item.bettingType !== "LINE";
                });
                return m !== undefined;
            },
            HasLocalFancy: function () {
                var m = _.find(this.subMarkets, function (item) {
                    return item.marketType === "LOCAL_FANCY";
                });
                return m !== undefined;
            },
            RunnersAggregate: function () {
                return _.filter(this.Catalog.runners, function (item) {
                    return item.selected;
                });
            },
            IsFixedOdds: function () {
                return this.Order.selectionId === 0 || this.Order.isLine;
            }
        },
        watch: {
            score: function (newVal, oldVal) {
                if (newVal !== null && newVal.commentry !== null) {
                    if (oldVal.commentry !== newVal.commentry) {
                        this.PlayCommentry(newVal.commentry);
                    }
                }
            },
            displayOn: function (value) {

            }
        },
        methods: {
            handleVisibilityChange: function () {
                if (document[hidden]) {
                    this.IsPageVisible = false;
                } else {
                    this.IsPageVisible = true;
                }
            },
            IsRunnerDisabled: function (status) {
                if (status === undefined
                    || status === ''
                    || status === null) {
                    return false;
                }
                return this.runnerUnavailable.includes(status.toLowerCase());
            },
            FetchCatalog: function (marketId) {
                var self = this;
                var qs = svc_prefix + 'markets/catalog2/?id=' + marketId;
                $.getJSON(qs, function (catalog) {
                    catalog["totalMatched"] = 0;
                    self.Catalog = catalog;

                    _.each(self.Catalog.runners, function (runner) {
                        runner["ticks"] = 0;
                        runner["selected"] = false;
                    });

                    self.IsLoaded = true;

                    setTimeout(function () { $('[data-toggle="tooltip"]').tooltip(); }, 500);

                    self.ListMarketData();
                    self.BookIntervalId = setInterval(self.ListMarketData, 1000);
                    self.OrderIntervalId = setInterval(self.ListOrders, 1500);
                });
            },
            ListMarketData: function () {
                if (!this.IsPageVisible) return;

                var qs = svc_prefix + 'Markets/Data';

                if (this.Catalog !== null && this.Catalog.hasOwnProperty("marketId")) {
                    var ReqData = {
                        "RequestId": "1",
                        "MarketIds": [this.Catalog.marketId],
                        "IncludeProfitLoss": true
                    };

                    var self = this;
                    $.ajax({
                        type: "POST",
                        url: qs,
                        data: JSON.stringify(ReqData),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function (result) {
                            self.RenderMarketData(result);
                        },
                        error: function (exception) {
                            ErrorHandler(exception.responseJSON);
                        }
                    });
                }
            },
            ClearTimers: function () {
                clearInterval(this.BookIntervalId);
                clearInterval(this.OrderIntervalId);
            },
            RenderMarketData: function (MarketData) {
                if (MarketData === null || MarketData.marketBooks.length === 0) return;

                this.fromNow = moment(this.Catalog.marketStartTime).fromNow();

                var Book = MarketData.marketBooks[0];

                this.Catalog.totalMatched = Book.totalMatched;
                this.Catalog.status = Book.marketStatus;
                this.Catalog.betDelay = Book.betDelay;
                this.score = MarketData.scoreboard;
                this.scoreLines = MarketData.fancy;
                this.MarketPL = MarketData.profitLoss;

                if (Book.marketStatus === "CLOSED") {
                    this.ClearTimers();
                }

                var self = this;
                this.Catalog.runners.forEach(function (runner) {
                    var soldier = Book.runners.find(function (item) {
                        return item.id === runner.selectionId.toString();
                    });

                    if (MarketData.profitLoss !== null) {
                        var PL = MarketData.profitLoss.find(function (plItem) {
                            return plItem.selectionID === runner.selectionId
                                && plItem.marketId === Book.id;
                        });
                    }

                    if (soldier !== undefined) {
                        if (soldier.status === 'WINNER') {
                            self.MarkWinner(soldier.id);
                        }

                        self.UpdateRunnersPriceSize(runner, soldier);

                        if (PL !== undefined) {
                            runner.ifWin = PL.ifWin;
                            runner.ifLose = PL.ifLose;
                        } else {
                            runner.ifWin = null;
                            runner.ifLose = null;
                        }
                    }
                });

                if (this.RunnersAggregate.length > 0) {
                    this.UpdateAggregateOdds(Book);
                }

                if (MarketData.marketBooks.length > 1) {
                    var ActiveSubMarkets = _.last(MarketData.marketBooks, MarketData.marketBooks.length - 1);
                    var ActiveSubMarketIds = _.map(ActiveSubMarkets, function (book) { return book.id; });

                    ActiveSubMarketIds = _.sortBy(ActiveSubMarketIds, function (id) { return id; });
                    var NewMarketIdsHash = ActiveSubMarketIds.join(',');

                    if (NewMarketIdsHash === self.CurrentMarketIdsHash) {
                        _.each(ActiveSubMarkets, this.RenderSubMarketData);
                        return;
                    }

                    if (self.LoadingSubMarkets) {
                        return;
                    }

                    self.LoadingSubMarkets = true;

                    this.subMarkets = [];
                    this.subMarketIds = [];
                    this.FetchCatalogs(ActiveSubMarketIds);
                } else {
                    this.subMarkets = [];
                    this.subMarketIds = [];
                }
            },
            UpdateAggregateOdds: function (Book) {
                var self = this;

                var backPrices = [];
                var layPrices = [];
                _.map(Book.runners, function (rn) {

                    var bookRunners = self.RunnersAggregate.filter(function (rg) {
                        return rg.selectionId.toString() === rn.id;
                    });

                    _.each(bookRunners, function (runner) {
                        backPrices.push(parseFloat(runner.price1) - 1);
                        layPrices.push(parseFloat(runner.lay1) - 1);
                    });
                });

                var aggLay = '';
                if (!layPrices.includes(NaN)) {
                    aggLay = this.AggregateOdds(layPrices);
                }

                var aggBack = '';
                if (!backPrices.includes(NaN)) {
                    aggBack = this.AggregateOdds(backPrices);
                }

                if (aggBack !== this.aggregateRun.back) {
                    this.aggregateRun.back = aggBack;
                    $("#agg-back").flash("#8dd2f0", this.plusFlash, 300);
                }

                if (aggLay !== this.aggregateRun.lay) {
                    this.aggregateRun.lay = aggLay;
                    $("#agg-lay").flash("#feafb2", this.minusFlash, 300);
                }
            },
            AggregateOdds: function (prices) {
                var val = prices[0];
                if (prices.length === 1) {
                    val = prices[0];

                } else {

                    for (i = 1; i < prices.length; i++) {
                        if (prices[i] === '' || prices[i] < 0) continue;

                        val = (val * prices[i] - 1) / (val + prices[i] + 2);
                    }
                }

                if (val <= 0) {
                    return 0;
                }
                else {
                    return Math.round(val * 100) / 100;
                }
            },
            UpdateRunnersPriceSize: function (runner, soldier) {
                runner.price1 = this.IndicatePriceChange(runner, runner.price1, soldier.price1, "indB1", "#8dd2f0");
                runner.size1 = this.IndicateSizeChange(runner, runner.size1, soldier.size1, "indB1", "#8dd2f0");

                runner.lay1 = this.IndicatePriceChange(runner, runner.lay1, soldier.lay1, "indL1", "#feafb2");
                runner.ls1 = this.IndicateSizeChange(runner, runner.ls1, soldier.ls1, "indL1", "#feafb2");

                runner.price2 = soldier.price2;
                runner.size2 = soldier.size2;
                runner.price3 = soldier.price3;
                runner.size3 = soldier.size3;
                runner.lay2 = soldier.lay2;
                runner.lay3 = soldier.lay3;
                runner.ls2 = soldier.ls2;
                runner.ls3 = soldier.ls3;

                runner.status = soldier.status;

                return runner;
            },
            IndicatePriceChange: function (runner, oldVal, newVal, attribute, bgcolor) {
                ++runner.ticks;

                if (oldVal === newVal) {
                    if (runner.ticks >= 7) {
                        runner.ticks = 0;
                        runner[attribute] = "";
                    }
                    return newVal;
                }

                runner.ticks = 0;

                if (oldVal > newVal) {
                    runner[attribute] = "d";
                    runner.IsDown = true;
                }
                if (newVal > oldVal) {
                    runner[attribute] = "u";
                    runner.IsUp = true;
                }

                bg = this.plusFlash;

                var oddType = attribute.replace('ind', '');
                var el = "#" + oddType + "-" + runner.selectionId;

                bg = oddType.includes("B") ? this.plusFlash : this.minusFlash;

                $(el).flash(bgcolor, bg, 300);
                return newVal;
            },
            IndicateSizeChange: function (runner, oldVal, newVal, attribute, bgcolor) {
                if (oldVal === newVal) {
                    return newVal;
                }

                bg = this.plusFlash;

                var oddType = attribute.replace('ind', '');
                var el = "#" + oddType + "-" + runner.selectionId;

                bg = oddType.includes("B") ? this.plusFlash : this.minusFlash;
                $(el).flash(bgcolor, bg, 300);
                return newVal;
            },
            MarkWinner: function (winnerId) {
                $("#runner-" + winnerId).addClass('winner');
            },
            UpdatePriceCell: function (oldVal, newVal, index, selectionId, bgcolor) {
                if (oldVal === newVal) return newVal;
                bg = oldVal > newVal ? this.plusFlash : this.minusFlash;
                var el = "#" + index + "-" + selectionId;
                if ($.flash !== undefined) {
                    $(el).flash(bgcolor, bg, 300);
                }
                return newVal;
            },
            FetchCatalogs: function (marketIds) {
                var params = marketIds.join(',');
                var qs = svc_prefix + 'markets/catalogs/?ids=' + params;
                $.getJSON(qs, this.RenderSubMarkets);
            },
            RenderSubMarkets: function (Catalogs) {
                var self = this;

                if (Catalogs !== null && Catalogs.length > 0) {

                    Catalogs = _.sortBy(Catalogs, 'marketName');

                    _.each(Catalogs, function (catalog) {
                        catalog['status2'] = null;
                        self.subMarkets.push(catalog);
                    });
                }
                this.LoadingSubMarkets = false;
            },
            RemoveCatalogues: function (RemovedMarketIds) {
                if (RemovedMarketIds.length === 0) return;

                var self = this;
                _.each(RemovedMarketIds, function (mid) {
                    _.filter(self.subMarkets, function (catalog) {
                        return mid !== catalog.marketId;
                    });
                });
            },
            RenderSubMarketData: function (Book) {
                if (this.LoadingSubMarkets) return;

                market = _.find(this.subMarkets, function (catalog) {
                    return catalog.marketId === Book.id;
                });
                if (market === undefined) return;

                market.status2 = Book.status2;

                var self = this;
                market.runners.forEach(function (runner) {
                    var soldier = Book.runners.find(function (item) {
                        return item.id === runner.selectionId.toString();
                    });

                    var PL = self.MarketPL.find(function (plItem) {
                        return plItem.selectionID === runner.selectionId
                            && plItem.marketId === Book.id;
                    });

                    if (soldier !== undefined) {
                        self.UpdateRunnersPriceSize(runner, soldier);

                        if (PL !== undefined) {
                            runner.ifWin = PL.ifWin;
                            runner.ifLose = PL.ifLose;
                        } else {
                            runner.ifWin = null;
                            runner.ifLose = null;
                        }
                    }
                });
            },
            ShowBetSlip: function (runner, side, runnerMarketId, ControlIndex) {
                this.Order.render = false;
                this.Order.size = '';
                this.IsAggregateOrder = false;

                if (this.Order.size === 0) {
                    this.Order.size = this.GetDefaultStake();
                }

                this.Order.isLine = this.IsLineMarket(runnerMarketId);

                var price = 0;
                var fancyPrice = null;
                switch (ControlIndex) {
                    case 1:
                        if (side.toLowerCase() === "b") {
                            price = runner.price1;
                            fancyPrice = runner.size1;
                        } else {
                            price = runner.lay1;
                            fancyPrice = runner.ls1;
                        }
                        break;

                    case 2:
                        if (side.toLowerCase() === "b") {
                            price = runner.price2;
                            fancyPrice = runner.size2;
                        } else {
                            price = runner.lay2;
                            fancyPrice = runner.ls2;
                        }
                        break;

                    case 3:
                        if (side.toLowerCase() === "b") {
                            price = runner.price3;
                            fancyPrice = runner.size3;
                        } else {
                            price = runner.lay3;
                            fancyPrice = runner.ls3;
                        }
                        break;
                }

                if (price === undefined || price === null) return;

                price = parseFloat(price);
                fancyPrice = parseFloat(fancyPrice);

                this.OrderPrice = price;
                this.Order["price"] = price;
                this.Order["fancyPrice"] = fancyPrice;
                this.Order["runnerName"] = runner.runnerName;
                this.Order.selectionId = runner.selectionId;
                this.Order["marketId"] = runnerMarketId;
                this.Order["side"] = side.toUpperCase();
                this.Order["persist"] = true;
                if (platform !== undefined) {
                    this.Order["identity"] = btoa(platform.description);
                }

                this.CalcPL();

                if (side === "L") {
                    $("#Place-Order,#PrInc,#PrDec").removeClass('btn-info');
                    $("#Place-Order,#PrInc,#PrDec").addClass('btn-danger');
                    $("#bet-slip-head").removeClass('bg-primary');
                    $("#bet-slip-head").addClass('bg-danger');
                } else {
                    $("#Place-Order,#PrInc,#PrDec").addClass('btn-info');
                    $("#Place-Order,#PrInc,#PrDec").removeClass('btn-danger');
                    $("#bet-slip-head").removeClass('bg-danger');
                    $("#bet-slip-head").addClass('bg-primary');
                }

                if (IsMobile()) {
                    this.ShowBetSlipMobile();
                } else {
                    this.Order.render = true;
                    setTimeout(function () {
                        $('#betSlip')[0].scrollIntoView();
                        $("#bet-size").focus();
                    }, 150);
                }

            },
            ShowBetSlipMobile: function () {
                $("#betSlipMobile").modal('show');
            },
            HideBetSlip: function () {
                $("#betSlipMobile").modal('hide');
            },
            IsLineMarket: function (marketId) {
                isLine = false;

                if (this.Catalog.marketId === marketId) {
                    isLine = this.Catalog.bettingType === "LINE";
                } else {
                    var market = _.find(this.subMarkets, function (catalogue) {
                        return catalogue.marketId === marketId;
                    });
                    if (market === undefined) {
                        isLine = false;
                    } else {
                        isLine = market.bettingType === "LINE";
                    }
                }
                return isLine;
            },
            GetDefaultStake: function () {
                var btnStake = $('.btn-stake')[0];
                if (btnStake) {
                    return $(btnStake).data('amount');
                }
                return 1000;
            },
            CloseBetSlip: function () {
                this.Order.render = false;
            },
            ClearBetSlip: function () {
                this.Order.size = '';
                document.getElementById("bet-size").focus();
            },
            CalcPL: function () {
                price = parseFloat(this.Order.price);
                size = parseFloat(this.Order.size);

                if (this.IsLineMarket(this.Order.marketId)) {
                    profit = size;
                    liable = size;
                } else {
                    if (this.Order.side === "B") {
                        profit = (price - 1) * size;
                        liable = size;
                    } else {
                        profit = size;
                        liable = (price - 1) * size;
                    }
                }

                this.Order["profit"] = numeral(profit).format('0,0[.]00');
                this.Order["liable"] = numeral(liable).format('0,0[.]00');
            },
            SetOrderSize: function (newSize) {
                this.Order.size = newSize;
                this.CalcPL();
            },
            IncreaseOrderSize: function (increment) {
                if (this.Order.size === '') this.Order.size = 0;
                this.Order.size += increment;
                this.CalcPL();
            },
            PlaceOrder: function () {
                if (this.Order.working) {
                    return;
                }
                this.Order["working"] = true;

                this.Order.error = "";

                var Orders = [];
                if (this.Order.selectionId === 0) {
                    Orders = this.AggregateOrdersList();
                } else {
                    val = parseFloat(this.OrderPrice);
                    this.UpdatePrice(val);

                    this.Order.size = parseFloat(this.Order.size);

                    Orders.push(this.Order);
                }

                var self = this;

                var qs = svc_prefix + 'Orders';
                $.ajax({
                    type: "POST",
                    url: qs,
                    data: JSON.stringify(Orders),
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (result) {
                        console.log("Placed: " + moment().format('mm:ss'));
                        self.Order["working"] = false;
                        self.Order["render"] = false;
                        self.HideBetSlip();
                        self.Order["error"] = "";
                        $("#place-error").hide();
                        self.Order["size"] = self.GetDefaultStake();
                        GetFunds();
                    },
                    error: function (data) {
                        self.Order["working"] = false;
                        self.Order["error"] = data.responseJSON.error;
                    }
                });
            },
            ListOrders: function () {
                if (!this.IsPageVisible) return;

                if (marketId === null) return;

                var self = this;

                var qs = svc_prefix + 'orders?MaxResults=0&MarketId=' + marketId;
                $.getJSON(qs, function (result) {
                    self.RenderOrders(self, result);
                    return false;
                })
                    .fail(function (exception) {
                        ErrorHandler(exception.responseJSON);
                    });
            },
            RenderOrders: function (self, Orders) {
                // matched 
                var MatchedNew = Orders.filter(function (order) {
                    return order.ms > 0;
                });

                var IsRenderMatched = MatchedNew.length !== self.Matched.length;
                if (IsRenderMatched) {
                    console.log("New Order: " + moment().format('mm:ss'));
                    // empty and refill
                    self.Matched = [];
                    MatchedNew.forEach(function (Order) {
                        Order.IsBack = Order.bs === "B";
                        Order.IsLay = Order.bs === "L";

                        self.Matched.push(Order);
                    });
                }

                // UnMatched
                var UnMatchNew = Orders.filter(function (order) {
                    return (order.us - order.ms) > 0;
                });

                UnMatchNew.forEach(function (Order) {
                    Order.IsBack = Order.bs === "B";
                    Order.IsLay = Order.bs === "L";

                    var index = self.UnMatched.findIndex(function (oldOrder) {
                        return oldOrder.id === Order.id;
                    });

                    if (index === -1) {
                        console.log("New Order: " + moment().format('mm:ss'));
                        self.UnMatched.unshift(Order);
                    } else {
                        self.UnMatched[index] = Order;
                    }
                });

                // Cancelled
                self.UnMatched.forEach(function (oldUM, i) {
                    var index = UnMatchNew.findIndex(function (Order) {
                        return oldUM.id === Order.id;
                    });

                    // remove it
                    if (index === -1) {
                        self.UnMatched.splice(i, 1);
                    }
                });
            },
            Cancel: function (Order) {
                var self = this;
                var qs = svc_prefix + 'orders/' + Order.id;

                $.ajax({
                    type: "DELETE",
                    url: qs,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function (result) {
                        GetFunds();
                    },
                    error: function (exception) {
                        ErrorHandler(exception.responseJSON);
                    }
                });
            },
            ShowFancyPosition: function (marketId) {
                this.FetchLinePosition(marketId);
                var subMarket = _.find(this.subMarkets, function (item) {
                    return item.marketId === marketId;
                });
                if (subMarket !== undefined) {
                    this.SelectMarketName = subMarket.marketName;
                }
            },
            FetchLinePosition: function (marketId) {
                var self = this;
                $.get(svc_prefix + 'orders/LinePosition/?marketId=' + marketId, function (result) {
                    self.SelectFancyPos = result;
                    $("#fancyPosition").modal('show');
                });
            },
            PriceUp: function () {
                if (this.IsFixedOdds) return;
                var oldPrice = parseFloat(this.OrderPrice);
                var NewPrice = this.OneStepIncrement(oldPrice);
                this.UpdatePrice(NewPrice);
            },
            PriceDown: function () {
                if (this.IsFixedOdds) return;
                var oldPrice = parseFloat(this.OrderPrice);
                var NewPrice = this.OneStepDecrement(oldPrice);
                this.UpdatePrice(NewPrice);
            },
            OneStepIncrement: function (NewPrice) {
                if (NewPrice === '' || NewPrice === undefined) {
                    return undefined;
                }
                else if (this.IsLineMarket(this.Order.marketId)) {
                    NewPrice = Math.round(NewPrice);
                } else {
                    validInc = PriceValidator.GetValidIncrement(NewPrice);
                    NewPrice = NewPrice + validInc;
                }
                return NewPrice;
            },
            OneStepDecrement: function (NewPrice) {
                if (NewPrice === '' || NewPrice === undefined) {
                    return undefined;
                }
                else if (this.IsLineMarket(this.Order.marketId)) {
                    NewPrice = Math.round(NewPrice);
                } else {
                    validDec = PriceValidator.GetValidDecrement(NewPrice);
                    NewPrice = NewPrice - validDec;
                }
                return NewPrice;
            },
            UpdatePrice: function (Price) {
                if (PriceValidator.IsLine || Price >= 20) {
                    Price = Math.round(Price);
                } else {
                    Price = parseFloat(PriceValidator.ValidatePrice(Price));
                    Price = Price.toFixed(2);
                }

                this.OrderPrice = Price;
                this.Order.price = parseFloat(Price);

                this.OldPrice = Price;
                this.CalcPL();
            },
            PlayCommentry: function (commentryText) {
                if (this.IsVoice) {
                    CommentryPlayer.Play(commentryText);
                }
            },
            ShowRules: function (marketId, marketName) {

                if (marketName === 'Fancy') {
                    if (this.subMarkets.length > 0) {
                        marketId = this.subMarkets[0].marketId;
                    }
                }

                var rules = '';
                if (this.Catalog.marketId === marketId) {
                    rules = this.Catalog.rules;
                } else {
                    var market = _.find(this.subMarkets, function (catalogue) {
                        return catalogue.marketId === marketId;
                    });
                    if (market !== undefined) {
                        rules = market.rules;
                    }
                }
                $("#rules-box").html(rules);
                $("#modalRules").modal('show');
            },
            toggleRunner: function (runner) {
                // Max selectable runners are 7
                if (this.RunnersAggregate.length >= 7
                    && !runner.selected) {
                    return;
                }

                runner.selected = !runner.selected;

                this.Catalog.runners.push([]);
                this.Catalog.runners.pop();

                aggRunnerName = [];
                _.each(this.RunnersAggregate, function (item) {
                    var runnerNameArr = item.runnerName.split('.');
                    if (runnerNameArr.length > 1) {
                        aggRunnerName.push(runnerNameArr[0]);
                    }
                });
                this.aggregateRun.runnerName = aggRunnerName.join(' + ');
            },
            ShowBetSlipForAggregate: function (side) {

                if (side.toLowerCase() === "b" && this.aggregateRun.back === '') {
                    return;
                }

                if (side.toLowerCase() === "l" && this.aggregateRun.lay === '') {
                    return;
                }

                this.aggregateRun.price1 = this.aggregateRun.back;
                this.aggregateRun.lay1 = this.aggregateRun.lay;

                this.ShowBetSlip(this.aggregateRun, side, this.aggregateRun.marketId, 1);
                this.IsAggregateOrder = true;
            },
            AggregateOrdersList: function () {
                TotalPercentage = 0;
                iTemPercentage = 0;

                side = this.Order.side;

                var self = this;

                TotalPercentage = _.reduce(this.RunnersAggregate, function (TotalPercentage, runner) {
                    var price = side.toLowerCase() === 'b' ? runner.price1 : runner.lay1;
                    return TotalPercentage + (100 / price);
                }, TotalPercentage);

                var Orders = _.map(this.RunnersAggregate, function (runner) {
                    var price = side.toLowerCase() === 'b' ? runner.price1 : runner.lay1;

                    iTemPercentage = 100 / price;

                    var order = {
                        price: price,
                        runnerName: runner.runnerName,
                        selectionId: runner.selectionId,
                        marketId: self.Order.marketId,
                        side: side.toUpperCase(),
                        persist: true,
                        size: Math.round(iTemPercentage / TotalPercentage * self.Order.size)
                    };
                    if (platform !== undefined) {
                        order["identity"] = btoa(platform.description);
                    }
                    return order;
                });
                return Orders;
            },
            MetadataHtml: function (runner) {
                return "Jockey: <b>" + runner.jockeyName + "</b>" +
                    "<br>Trainer: <b>" + runner.trainerName + "</b>" +
                    "<br>Age / Weigth: <b>" + runner.age + "/" + runner.weight + "</b>" +
                    "<br>Days since last run: <b>" + runner.lastRun + "</b>" +
                    "<br>Wearing: <b>" + runner.wearing + "</b>";
            },
            MetadataHtml2: function (runner) {
                return "<table class='table table-sm'>" +
                    "<tr><td>Jockey</td><th>" + runner.jockeyName + "</th></tr>" +
                    "<tr><td>Trainer</td><th>" + runner.trainerName + "</th></tr>" +
                    "<tr><td>Age / Weigth</td><th>" + runner.age + "/" + runner.weight + "</th></tr>" +
                    "</table>";
            }
        }
    });
}

function ErrorHandler(exception) {
    if (exception === undefined) return;
    var errors = ["MISSING_AUTH_TOKEN", "INVALID_SESSION"];
    if (errors.includes(exception.error)) {
        document.location.href = "/Users/Login";
    }
}

function incrementValue(e) {
    e.preventDefault();
    var fieldName = $(e.target).data('field');
    var parent = $(e.target).closest('div');
    var currentVal = parseInt(parent.find('input[name=' + fieldName + ']').val(), 10);

    if (!isNaN(currentVal)) {
        parent.find('input[name=' + fieldName + ']').val(currentVal + 1);
    } else {
        parent.find('input[name=' + fieldName + ']').val(0);
    }
}

function decrementValue(e) {
    e.preventDefault();
    var fieldName = $(e.target).data('field');
    var parent = $(e.target).closest('div');
    var currentVal = parseInt(parent.find('input[name=' + fieldName + ']').val(), 10);

    if (!isNaN(currentVal) && currentVal > 0) {
        parent.find('input[name=' + fieldName + ']').val(currentVal - 1);
    } else {
        parent.find('input[name=' + fieldName + ']').val(0);
    }
}

$('.input-group').on('click', '.button-plus', function (e) {
    incrementValue(e);
});

$('.input-group').on('click', '.button-minus', function (e) {
    decrementValue(e);
});

$('.burger-toggle').on('click', function () {
    $('body').toggleClass('menu-collapsed');
    $(this).toggleClass('active');
});

$(document).ready(function () {
    // A simple background color flash effect that uses jQuery Color plugin
    jQuery.fn.flash = function (bgcolor, color, duration) {
        var current = this.css('backgroundColor');
        this.css('backgroundColor', 'rgb(' + color + ')')
            .animate({ backgroundColor: 'rgb(' + bgcolor + ')' }, duration);
    };

    $(window).on('unload', function () {
        if (MarketVM !== undefined) {
            MarketVM.ClearTimers();
        }
    });

    $("#IsDisplayOn").click(function () {
        $(this).attr("disabled", true);
        noSleep.enable();
    });
});