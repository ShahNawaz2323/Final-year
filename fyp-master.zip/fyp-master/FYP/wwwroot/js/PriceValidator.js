﻿var PriceValidator = {
    OldPrice: 1.01,
    NewPrice: 1.02,
    IsLine:false,

    GetValidIncrement: function (AskPrice) {

        if (this.IsLine) {
            return Math.round(AskPrice);
        }

        this.OldPrice = AskPrice;
        if (this.OldPrice >= 1.01 && this.OldPrice < 2) {
            return 0.01;
        }
        else if (this.OldPrice >= 2 && this.OldPrice < 3) {
            return 0.02;
        }
        else if (this.OldPrice >= 3 && this.OldPrice < 4) {
            return 0.05;
        }
        else if (this.OldPrice >= 4 && this.OldPrice < 6) {
            return 0.1;
        }
        else if (this.OldPrice >= 6 && this.OldPrice < 10) {
            return 0.2;
        }
        else if (this.OldPrice >= 10 && this.OldPrice < 20) {
            return 0.5;
        }
        else if (this.OldPrice >= 20 && this.OldPrice < 30) {
            return 1;
        }
        else if (this.OldPrice >= 30 && this.OldPrice < 50) {
            return 2;
        }
        else if (this.OldPrice >= 50 && this.OldPrice < 100) {
            return 5;
        }
        else if (this.OldPrice >= 100 && this.OldPrice < 1000) {
            return 10;
        }
        else if (this.OldPrice === 1000) {
            return 0;
        }
        else if (this.OldPrice > 1000) {
            return 1000 - this.OldPrice;
        }
    },

    GetValidDecrement: function (AskPrice) {
        if (this.IsLine) {
            return Math.round(AskPrice);
        }

        this.OldPrice = AskPrice;
        if (this.OldPrice === 1.01) {
            return 0;
        }
        else if (this.OldPrice > 1.01 && this.OldPrice <= 2) {
            return 0.01;
        }
        else if (this.OldPrice > 2 && this.OldPrice <= 3) {
            return 0.02;
        }
        else if (this.OldPrice > 3 && this.OldPrice <= 4) {
            return 0.05; 
        }
        else if (this.OldPrice > 4 && this.OldPrice <= 6) {
            return 0.1;
        }
        else if (this.OldPrice > 6 && this.OldPrice <= 10) {
            return 0.2;
        }
        else if (this.OldPrice > 10 && this.OldPrice <= 20) {
            return 0.5;
        }
        else if (this.OldPrice > 20 && this.OldPrice <= 30) {
            return 1;
        }
        else if (this.OldPrice > 30 && this.OldPrice <= 50) {
            return 2;
        }
        else if (this.OldPrice > 50 && this.OldPrice <= 100) {
            return 5;
        }
        else if (this.OldPrice > 100 && this.OldPrice <= 1000) {
            return 10;
        }
    },

    ValidatePrice: function (SamplePrice) {
        if (this.IsLine) {
            return Math.round(SamplePrice);
        }

        // fix for 1.01000001 bug
        var testPrice = SamplePrice.toString();
        if (testPrice.length > 7) {
            SamplePrice = parseFloat(SamplePrice.toFixed(2));
        }

        this.NewPrice = parseFloat(SamplePrice);
        var divisionFactor = 2;
        var multiplierTmp = 1;
        var cf = 0;
        var remainder = 0;
        var IsCorrect = true;

        if (this.NewPrice < 1.01) {
            this.NewPrice = 1.01;
            IsCorrect = true;
        }

        else if (this.NewPrice > 2 && this.NewPrice < 3) {
            IsCorrect = false;
            divisionFactor = 2;
            multiplierTmp = 100;
        }

        else if (this.NewPrice > 3 && this.NewPrice < 4) {
            IsCorrect = false;
            divisionFactor = 5;
            multiplierTmp = 100;
        }

        else if (this.NewPrice > 4 && this.NewPrice < 6) {
            IsCorrect = false;
            divisionFactor = 10;
            multiplierTmp = 100;
        }

        else if (this.NewPrice > 6 && this.NewPrice < 10) {
            IsCorrect = false;
            divisionFactor = 20;
            multiplierTmp = 100;
        }

        else if (this.NewPrice > 10 && this.NewPrice < 20) {
            IsCorrect = false;
            divisionFactor = 50;
            multiplierTmp = 100;
        }

        else if (this.NewPrice > 20 && this.NewPrice < 30) {
            IsCorrect = false;
            divisionFactor = 1;
            multiplierTmp = 1;
        }

        else if (this.NewPrice > 30 && this.NewPrice < 50) {
            IsCorrect = false;
            divisionFactor = 2;
            multiplierTmp = 1;
        }

        else if (this.NewPrice > 50 && this.NewPrice < 100) {
            IsCorrect = false;
            divisionFactor = 5;
            multiplierTmp = 1;
        }
        
        else if (this.NewPrice > 100 && this.NewPrice < 1000) {
            IsCorrect = false;
            divisionFactor = 10;
            multiplierTmp = 1;
        }
        
        else if (this.NewPrice > 1000) {
            this.NewPrice = 1000;
            IsCorrect = true;
        }

        // correction
        var precision = 0;
        if (!IsCorrect) {
            remainder = this.NewPrice * multiplierTmp % divisionFactor;
            if (remainder > 0.0001) {
                cf = divisionFactor - remainder;
                if (multiplierTmp > 1) {
                    precision = 2;
                    cf = parseFloat((cf / multiplierTmp).toFixed(2));
                }
                // add correction factor to ask price
                this.NewPrice = (this.NewPrice + cf).toFixed(precision);
            }
        }
        return this.NewPrice;
    }
}