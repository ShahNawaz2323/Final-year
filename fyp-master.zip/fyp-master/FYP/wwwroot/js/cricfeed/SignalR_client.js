﻿var matchdata = new Array();
// Craete Interactive function...
function Interactive() {
    // create variable for signalR connection...

    var _notesHubProxy = null;
    var _hubConnection = $.hubConnection();

    this.InitializeInteractive = function (LoginId, Password) {

        //-------------------------------------------------------------Create HubConnection------------------------------------------------------
        _hubConnection = $.hubConnection("http://cricketrunlive.com:11001/signalr");

        // set header params
        _hubConnection.qs = { "Firm": LoginId, "PrivateKey": Password, "ApiKey": "CRIC@2019" }

        _notesHubProxy = _hubConnection.createHubProxy("ClientHub");

        _notesHubProxy.on("OnLogon", ResponseLogon);

        _notesHubProxy.on("OnLogout", ResponseLogOut);

        _notesHubProxy.on("OnMatchInfo", ResponseMatchInfo);

        _notesHubProxy.on("OnScore", ResponseODIScore);

        _notesHubProxy.on("OnTestScore", ResponseTestScore);

        _notesHubProxy.on("OnMarketRateInfo", ResponseMarketRateInfo);

        _notesHubProxy.on("OnMarketRate", ResponseMarketRate);

        _notesHubProxy.on("OnSession", ResponseSession);


        //----------------------------------------------------------------------------------------------------------------------------------------------
        //--------------------------------------------- Start Connection for Login Request--------------------------------------------------------------

        // Connection disconnected 
        _hubConnection.disconnected(function () {

        });

        _hubConnection.start().done(function () {
            console.log("Connection successfully.");
            $("#msglog").append("<span> Connection successfully.</span><br />");
        }).fail(function () {
            console.log("Connection Failed.")
            $("#msglog").append("<span> Connection Failed.</span><br />");
        });


        //// data received 
        //_hubConnection.received(function (data) {
        //    $("#msglog").append("<span>Data received >>  " + data + " </span><br />");
        //});

    };

    this.Reconnect = function (LoginId, Password) {
        _hubConnection.start().done(function () {
            isInteractiveSocket = true;
            //interactive.SendLoginRequest("LoginRequestFromClient", LoginId, Password);
        }).fail(function () {
            console.log("Re-Connection Failed.")
        });
    }


    //---------------------------------------------------------------Request to Server---------------------------------------------------------------------
    this.SendToManager = function (methods, message) {
        if (_notesHubProxy != null && _notesHubProxy != 'undefined') {
            _notesHubProxy.invoke(methods, message).done(function () {

            }).fail(function () {
            });
        }
    }


    //------------------------------------------------------Login Request to Server-------------------------------------------------------------------------
    this.SendLoginRequest = function (methods, LoginId, Password) {
        if (_notesHubProxy != null && _notesHubProxy != 'undefined') {
            _notesHubProxy.invoke(methods, LoginId, Password);
        }
    }

    this.LogoutClient = function () {
        _hubConnection.stop();
    }

};

//--------------------------------------------------- Initialize Interactive variable------------------------------------------------------------------------
var interactive = new Interactive();





//-------------------------------------------------------Login Request------------------------------------
function RequestLogin() {
    interactive.InitializeInteractive($("#loginid").val(), $("#password").val());
}

//-------------------------------------------------------Login Response------------------------------------
function ResponseLogon(user) {
    $("#msglog").append("<span> Response Login >> " + user.UserName + ", Lic Expiry : " + user.Expiry + "</span><br />");
}


//-------------------------------------------------------Logout Response------------------------------------
function ResponseLogOut(note) {
      $("#msglog").append("<span> Response Logout >> " + JSON.stringify(note) + "</span><br />");
}

//------------------------------------------------------- Response------------------------------------
function ResponseMatchInfo(note) {
    matchdata.push(note);
     // $("#msglog").append("<span> Response Match Info >> " + JSON.stringify(note) + "</span><br />");

    MatchResponseHandler(note);
}

//------------------------------------------------------- Response------------------------------------
function ResponseODIScore(note) {
    // $("#msglog").append("<span> Response ODI Score >> " + JSON.stringify(note) + "</span><br />");
}
//------------------------------------------------------- Response------------------------------------
function ResponseTestScore(note) {
    //   $("#msglog").append("<span> Response Test Score >> " + JSON.stringify(note) + "</span><br />");
}
//------------------------------------------------------- Response------------------------------------
function ResponseMarketRateInfo(note) {
    let objmatchdata = search(note.MatchId, matchdata);

    if (objmatchdata) {
        let rowid = objmatchdata.MatchId;
        if (document.getElementById(rowid) != null) {
            document.getElementById("CountDown_" + rowid).innerHTML = isnullundefine(note.CountDown);
            document.getElementById("Status_" + rowid).innerHTML = isnullundefine(note.Status);
            document.getElementById("Volume_" + rowid).innerHTML = isnullundefine(note.Volume);
            document.getElementById("BackF_" + rowid).innerHTML = isnullundefine(note.BackF);
            document.getElementById("LayF_" + rowid).innerHTML = isnullundefine(note.LayF);
            document.getElementById("BackS_" + rowid).innerHTML = isnullundefine(note.BackS);
            document.getElementById("LayS_" + rowid).innerHTML = isnullundefine(note.LayS);
        }
        else {
            var html = "<tr  id=" + rowid + ">" +
                 "<td id=\"Name_" + rowid + "\">" + isnullundefine(objmatchdata.Teams) + "<br>" + isnullundefine(objmatchdata.StartTime) + "</td>" +
                 "<td id=\"CountDown_" + rowid + "\">" + isnullundefine(note.CountDown) + "</td>" +
                 "<td id=\"Status_" + rowid + "\">" + isnullundefine(note.PlayStatus) + "</td>" +
                 "<td id=\"Volume_" + rowid + "\">" + isnullundefine(note.Volume) + "</td>" +
                 "<td id=\"BackF_" + rowid + "\">" + isnullundefine(note.BackF) + "</td>" +
                 "<td id=\"LayF_" + rowid + "\">" + isnullundefine(note.LayF) + "</td>" +
                 "<td id=\"BackS_" + rowid + "\">" + isnullundefine(note.BackS) + "</td>" +
                 "<td id=\"LayS_" + rowid + "\">" + isnullundefine(note.LayS) + "</td>" +
                 "</tr>";
            $("#tblMarketRate tbody").append(html);
        }
    }

    // $("#msglog").append("<span> Response Market Rate Info >> " + JSON.stringify(note) + "</span><br />");
}
//------------------------------------------------------- Response------------------------------------
function ResponseMarketRate(note) {
    //$("#msglog").append("<span> Response MarketRate >> " + JSON.stringify(note) + "</span><br />");
}
//------------------------------------------------------- Response------------------------------------
function ResponseSession(note) {
    // $("#msglog").append("<span> Response Session>> " + JSON.stringify(note) + "</span><br />");

    if (note.hasOwnProperty("MatchId")) {
        activeSessions[note.MatchId] = note;
    }

    var data = {
        MarketId: "9.36",
        SelectionId: 37303,
        Back: parseFloat(note.Yes),
        Lay: parseFloat(note.No),
        Action: note.Status
    };
    // $.post("/api/MarketFeed", data, function () { }, "json");

    $.ajax({
        type: "POST",
        url: "/api/MarketFeed",
        data: JSON.stringify(data),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (result) {
            // self.RenderMarketData(result);
        },
        error: function (exception) {
            // ErrorHandler(exception.responseJSON);
        }
    });
}

function search(nameKey, myArray) {
    for (var i = 0; i < myArray.length; i++) {
        if (myArray[i].MatchId === nameKey) {
            return myArray[i];
        }
    }
}

function isnullundefine(val) {
    if (val == undefined || val == null) {
        return "";
    }
    else {
        return val;
    }
}

function Logout() {
    interactive.LogoutClient();
}

let activeEvents = {};
let activeSessions = {};

function MatchResponseHandler(response) {
    if (response.hasOwnProperty("MatchId")) {
        activeEvents[response.MatchId] = response;
    }
}

function RenderEvents() {
    for (matchId in activeEvents) {
        $("#tblEvents").append("<tr><td>" + matchId + "</td><td>" + activeEvents[matchId].Teams + "</td></tr>");
    }
}