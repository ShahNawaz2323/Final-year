﻿var isIOS = iOS();

$(document).ready(function () {
    var cw = $('#container').width();

    $(".box").width(cw / 5);
    cw = $('body').width();
    if (cw < 1026) {
        $("body").addClass('menu-collapsed');
        $(".burger-toggle").addClass('active');
    }
    $(window).resize(function () {
        var cw = $('body').width();
        // $(".box").width(cw / 5);
        if (cw < 1026) {
            $("body").addClass('menu-collapsed');
            $(".burger-toggle").addClass('active');
        } else if (cw > 1026) {
            $("body").removeClass('menu-collapsed');
            $(".burger-toggle").removeClass('active');
        }

        FixVideoSize();
    });

    initWebRtc();
});

let streams = [];
streams.push({
    ch: "c1",
    container: "#VBox1",
    el: "#streamVideo1",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "c2",
    container: "#VBox2",
    el: "#streamVideo2",
    unreal: "#UnrealPlayer1",
    player: null    
});
streams.push({
    ch: "c3",
    container: "#VBox3",
    el: "#streamVideo3",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "r1",
    container: "#VBox4",
    el: "#streamVideo4",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "r2",
    container: "#VBox5",
    el: "#streamVideo5",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "r3",
    container: "#VBox6",
    el: "#streamVideo6",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "r4",
    container: "#VBox7",
    el: "#streamVideo7",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "s1",
    container: "#VBox8",
    el: "#streamVideo8",
    unreal: "#UnrealPlayer1",
    player: null
});

streams.push({
    ch: "s2",
    container: "#VBox9",
    el: "#streamVideo9",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "s3",
    container: "#VBox10",
    el: "#streamVideo10",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "s4",
    container: "#VBox11",
    el: "#streamVideo11",
    unreal: "#UnrealPlayer1",
    player: null
});

streams.push({
    ch: "t1",
    container: "#VBox12",
    el: "#streamVideo12",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "t2",
    container: "#VBox13",
    el: "#streamVideo13",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "g1",
    container: "#VBox14",
    el: "#streamVideo14",
    unreal: "#UnrealPlayer1",
    player: null
});
streams.push({
    ch: "g2",
    container: "#VBox15",
    el: "#streamVideo15",
    unreal: "#UnrealPlayer1",
    player: null
});

function initWebRtc() {
    for (i in streams) {
        if (streams[i].player != null) {
            streams[i].player = new UnrealWebRTCPlayer(
                streams[i].el.replace('#', ''),
                streams[i].ch + ".stream",
                "",
                "s2.livemediasystem.com",
                "443",
                true,
                true,
                "udp"
            );
        }
    }    
}

var channelname = "";
function HideChannel(channel)
{
    if (channel == 'closeplayer' && !isIOS ) {
        var element = document.getElementById("UnrealPlayer1_Video");
        element.parentNode.removeChild(element);
        streams.forEach(function (str) {
            if (str.player !== null) {
                str.player.Stop();
            }
            document.querySelector(str.container).style.display = 'none';
            document.querySelector(str.el).style.display = 'none';
            document.querySelector(str.unreal).style.display = 'none';
            document.querySelector(str.unreal).player = null;
        });
    } else {
        $(channelname).hide();
       // element.parentNode.removeChild(element);
        streams.forEach(function (str) {
            if (str.player !== null) {
                str.player.Stop();
            }
            document.querySelector(str.container).style.display = 'none';
            document.querySelector(str.el).style.display = 'none';
            document.querySelector(str.unreal).style.display = 'none';
        });

    }
}


function playChannel(channel) {
    
    streams.forEach(function (str) {
        if (str.player !== null) {
            str.player.Stop();
        }
        document.querySelector(str.container).style.display = 'none';
        document.querySelector(str.el).style.display = 'none';
        document.querySelector(str.unreal).style.display = 'none';
    });

    var strData = streams.find(function (str) {
        return str.ch === channel;
    });
    

    if (isIOS) {
        channelname = strData.el;
        document.querySelector(strData.container).style.display = 'block';
        document.querySelector(strData.el).style.display = 'block';
        setTimeout(function () {
            strData.player = new UnrealWebRTCPlayer(
                strData.el.replace('#', ''),
                strData.ch + ".stream",
                "",
                "s2.livemediasystem.com",
                "443",
                true,
                true,
                "udp"
            );
            strData.player.Play();
            FixVideoSize();
        }, 1000);
    } else {
        var myEle = document.getElementById("UnrealPlayer1_stop");
        if (myEle) {
            document.getElementById("UnrealPlayer1_stop").click();
        }
        document.querySelector("#VBox1").style.display = 'block';
        document.querySelector(strData.unreal).style.display = 'block';

        var channelId = strData.ch + ".stream";
        var bigbuttons = false;

        if ("MediaSource" in window && "WebSocket" in window)
            RunPlayer(
                "UnrealPlayer1",
                470,
                300,
                "s2.livemediasystem.com",
                443,
                true,
                channelId,
                "",
                true,
                true,
                1,
                "",
                bigbuttons
            );
        
        FixVideoSize();
        document.getElementById("UnrealPlayer1_playpause").click();
    };
    
}

function FixVideoSize() {
    try {
        var newWidth = $(".right-content").width();
        if (isIOS) {
            $("#streamVideo1,#streamVideo2,#streamVideo3,#streamVideo4,#streamVideo5,#streamVideo6,#streamVideo7,#streamVideo8,#streamVideo9,#streamVideo10,#streamVideo11,#streamVideo12").width(newWidth);
            $("#streamVideo1,#streamVideo2,#streamVideo3,#streamVideo4,#streamVideo5,#streamVideo6,#streamVideo7,#streamVideo8,#streamVideo9,#streamVideo10,#streamVideo11,#streamVideo12").attr('height', '300px');

        } else {
            changePlayerSize(newWidth);
        }
    } catch (e) {
        console.log(e);
    }
}


function changePlayerSize(newWidth) {
    try {
        var videoelement = document.getElementById("UnrealPlayer1_Video");
        if (videoelement == null) {
            return;
        }
        if (videoelement )
        videoelement.width = newWidth;

        var videoControls = document.getElementById("UnrealPlayer1_videoControls");
        var progress = document.getElementById("UnrealPlayer1_progress");

        videoControls.style.width = videoelement.width + "px";

        var bigbuttons = false;
        if (!bigbuttons)
            progress.style.width = videoelement.width - 280 + "px";
        else
            progress.style.width = videoelement.width - 410 + "px";
    }
    catch (e) {
        console.log(e);
    }
}

function OnMetadata() { }
function iOS() {
   
    var iDevices = [
        'iPad Simulator',
        'iPhone Simulator',
        'iPod Simulator',
        'iPad',
        'iPhone',
        'iPod'
    ];

    if (!!navigator.platform) {
        while (iDevices.length) {
            if (navigator.platform === iDevices.pop()) { return true; }
        }
    }
    return false;
}