﻿using FYP.classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.Repositories
{
    public class UserRepo : DapperWrap
    {
        public async Task<User> GetByIdAsync(int ID)
        {
            var user = await GetRecord<User>(@"SELECT * FROM Users WHERE ID=@ID", new { ID });
            return user;
        }
        public async Task<User> GetByCNICorEmailAsync(string cnic , string email)
        {
            var user = await GetRecord<User>(@"SELECT * FROM Users WHERE CNIC=@cnic OR Email=@email", new { cnic , email });
            return user;
        }
        public async Task<bool> AddAsync(User user)
        {
            bool rvalue = false;
            var existingUser = await GetByCNICorEmailAsync(user.CNIC.ToString() , user.Email);
            if (existingUser == null)
            {
                try
                {
                  var saved =  await AddRecord(@"Insert into Users (UserName,CNIC,Age,Password,Picfront,Picback,userType,Email,Fathername,Gender,Address,Mobile,Paid,Blocked,AdminVerified) VALUES (@UserName,@CNIC,@Age,@Password,@Picfront,@Picback,@userType,@Email,@Fathername,@Gender,@Address,@Mobile,@Paid,@Blocked,@AdminVerified)", new { user.UserName, user.CNIC, user.Age, user.Password, user.Picfront, user.Picback ,user.userType, user.Email, user.Fathername, user.Gender, user.Address,user.Mobile, user.Paid, user.Blocked, user.AdminVerified });
                    if (saved)
                    {
                        rvalue = true;
                    }
                    else
                    {
                        rvalue = false;
                    }

                }catch(Exception e)
                {
                    rvalue = false;
                }

            }
            return rvalue;
        }

        public async Task<bool> UpdateUserData(User user)
        {
            
                try
                {
                if (string.IsNullOrEmpty(user.profilepic))
                {
                    var saved = await UpdateRecord(@"UPDATE Users SET  Password=@Password,Address=@Address where ID=@ID", new { Password = user.Password, Address = user.Address, ID = user.ID });
                    if (saved)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    var saved = await UpdateRecord(@"UPDATE Users SET  Password=@Password,Address=@Address , profilepic=@profilepic where ID=@ID", new { Password = user.Password, Address = user.Address, ID = user.ID , profilepic = user.profilepic });
                    if (saved)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }


                    

                }
                catch (Exception e)
                {
                    return false;
                }
            
            return true;
        }


        public async Task<User> GetByNameAndPasswordAsync(User Data)
        {
            var user = await GetRecord<User>(@"SELECT * FROM Users WHERE UserName=@Username AND Password=@Password", new { Username = Data.UserName , Password=Data.Password });
            return user;

        }

        //show list of cities
        public async Task<IEnumerable<string>> GetCities()
        {
            var Cities = await GetRecords<string>(@"SELECT Name FROM Cities");
            return Cities;

        }

        //Get Adds by userid that are not completed
        public async Task<bool> UserAnyAddAvail(string UID)
        {
            var uidd = Convert.ToInt32(UID);
            var Data = await GetRecord<Postadd>(@"SELECT * FROM Adds where userid=@uidd AND Deleted='false'", new { uidd });
            if(Data != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //Post add to db 
        public async Task<bool> SaveAdd(Postadd postadd)
        {
            var Data = await AddRecord(@"Insert into Adds (userid,Title,location,Description,startingbid,bidtype,catagory,Imagestring,Bidstart,status,visible,username,PlaceDate,AutoStart,Deleted,Grace,AutoStop) VALUES (@userid,@Title,@location,@Description,@startingbid,@bidtype,@catagory,@Imagestring,@Bidstart,@status,@visible,@username,@PlaceDate,@AutoStart,@Deleted,@Grace,@AutoStop)", new {postadd.userid , postadd.Title , postadd.location,postadd.Description,postadd.startingbid,postadd.bidtype,postadd.catagory,postadd.Imagestring, postadd.Bidstart, postadd.status , postadd.visible, postadd.username ,postadd.PlaceDate, postadd.AutoStart ,postadd.Deleted , postadd.Grace , postadd.AutoStop});
            if(Data != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //Get all adds by catagory if null then all adds
        public async Task<IEnumerable<Postadd>> GetAdds(string addcat , string locat)
        {
            if (string.IsNullOrEmpty(addcat))
            {
                var Data = await GetRecords<Postadd>(@"Select * From Adds where visible='true' AND Deleted='false' AND location=@location", new { location = locat });
                return Data;
            }
            else
            {
                var Data = await GetRecords<Postadd>(@"Select * From Adds where catagory=@addcat AND visible='true' AND Deleted='false' AND location=@location", new { addcat , location = locat });
                return Data;
            }
            
            
        }

        public async Task<IEnumerable<Postadd>> GetDeletedAdds()
        {
                var Data = await GetRecords<Postadd>(@"Select * From Adds where Deleted='true'", new {});
                return Data;
        }

        //get all adds by add id
        public async Task<Postadd> AddById(int id)
        {
            var Data = await GetRecord<Postadd>(@"Select * From Adds where id=@id ", new { id});
            return Data;
        }

        //Get Adds by userid
        public async Task<IEnumerable<Postadd>> AllAddsById(string ID)
        {
            var Data = await GetRecords<Postadd>(@"Select * From Adds where userid=@ID AND Deleted='false'", new { ID });
            return Data;
        }

        public async Task<bool> SaveEdited(Postadd postadd)
        {
            var Data = await UpdateRecord(@"Update Adds SET  Title=@Title,Description=@Description,startingbid=@startingbid where userid=@userid AND id=@id", new { Title = postadd.Title, Description = postadd.Description, startingbid = postadd.startingbid, userid = postadd.userid, id = postadd.id });
            if (Data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<bool> StartStopBiding(string UID ,  int ADID , string value)
        {
            var Data = await UpdateRecord(@"Update Adds SET  Bidstart=@value where userid=@UID AND id=@ADID", new { value, UID, ADID});
            if (Data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<bool> UpdateAutoStop(string UID, int ADID, string Stop)
        {
            var Data = await UpdateRecord(@"Update Adds SET  AutoStop=@Stop where userid=@UID AND id=@ADID", new { Stop, UID, ADID });
            if (Data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<bool> UpdateGraceTime(string UID, int ADID, string Stop ,  int grace)
        {
            var Data = await UpdateRecord(@"Update Adds SET  AutoStop=@Stop , Grace=@grace where userid=@UID AND id=@ADID", new { Stop, grace, UID, ADID });
            if (Data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }



        public async Task<bool> FinishBidingstatus(string UID, int ADID, string value)
        {
            var Data = await UpdateRecord(@"Update Adds SET  status=@value , visible='false' where userid=@UID AND id=@ADID", new { value, UID, ADID });
            if (Data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<bool> DELETEADD(string UID, int ADID)
        {
            var Data = await UpdateRecord(@"UPDATE  Adds SET Deleted='true' where userid=@UID AND id=@ADID", new {UID, ADID });
            if (Data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //Get All bids from currentbiding table 

        public async Task<IEnumerable<Biding>> Getcurrentbids(int adid , bool limit)
        {
            if (limit)
            {
                var Data = await GetRecords<Biding>(@"SELECT * From CurrentBiding  where Addid=@adid AND Status='Show' Order By id DESC LIMIT 5", new { adid });
                return Data;
            }
            else
            {
                var Data = await GetRecords<Biding>(@"SELECT * From CurrentBiding  where Addid=@adid AND Status='Show' Order By id DESC", new { adid });
                return Data;
            }
            
        }

        public async Task<IEnumerable<MessForUser>> RepliesFromAdmin(string ID)
        {
            var Data = await GetRecords<MessForUser>(@"SELECT * From MessForUser where UserID=@ID", new { ID });
            return Data;
        }
        public async Task<bool> UpdateSeenStatus(string ID)
        {
            var Data = await AddRecord(@"UPDATE MessForUser SET Seen='true' where UserID=@ID", new { ID });
            return Data;
        }




        //Rateing Add system
        public async Task<Rateing> GetUserRateing(int UID)
        {
                var Data = await GetRecord<Rateing>(@"SELECT * From Rateing  where UserId=@UID ", new { UID });
                return Data;
        }
        public async Task<bool> AddNewRateing(Rateing rateing)
        {
            var Data = await AddRecord(@"Insert into Rateing (UserId,One,Two,Three,Four,Five) Values(@UserId,@One,@Two,@Three,@Four,@Five) ", new { rateing.UserId , rateing.One, rateing.Two, rateing.Three, rateing.Four, rateing.Five });
            return Data;
        }
        public async Task<bool> UpdateUserRateing(Rateing rateing)
        {
            var Data = await AddRecord(@"Update Rateing SET  One=@One , Two=@Two , Three=@Three , Four=@Four, Five=@Five where UserId=@UserId", new {rateing.One , rateing.Two , rateing.Three, rateing.Four, rateing.Five , UserId = rateing.UserId });
            return Data;
        }
        public async Task<bool> AddComment(Comments Comment)
        {
            var Data = await AddRecord(@"Insert into Comments (UserId,AddId,Comment,CommenterId) Values(@UserId,@AddId,@Comment,@CommenterId)", new { Comment.UserId , Comment.AddId , Comment.Comment , Comment.CommenterId });
            return Data;
        }
        public async Task<Comments> GetCommentOfAdd(int Addid ,string UID)
        {
            var Data = await GetRecord<Comments>(@"SELECT * From Comments  where AddId=@Addid AND UserId=@UID", new { Addid , UID });
            return Data;
        }
        public async Task<IEnumerable<Comments>> GetAllComments(int UID)
        {
            var Data = await GetRecords<Comments>(@"SELECT * From Comments  where UserId=@UID AND Comment != 'No Comment'", new { UID });
            return Data;
        }
        public async Task<bool> AddTrackingCode(TrackingDetail trackingDetail)
        {
            var Data = await AddRecord(@"Insert into Tracking (Buyer,Addid,Tracking) Values(@Buyer,@Addid,@Tracking)", new { trackingDetail.Buyer, trackingDetail.Addid, trackingDetail.Tracking });
            return Data;
        }

        public async Task<TrackingDetail> GetTrackingDetail(int Addid, string UID)
        {
            var Data = await GetRecord<TrackingDetail>(@"SELECT * From Tracking  where Addid=@Addid AND Buyer=@UID", new { Addid, UID });
            return Data;
        }

        public async Task<IEnumerable<Biding>> GetMycurrentbids(int adid , string MyID)
        {
           
                var Data = await GetRecords<Biding>(@"SELECT * From CurrentBiding  where Addid=@adid AND biderid=@MyID AND Status='Show' Order By id DESC LIMIT 5", new { adid , MyID });
                return Data;
            

        }
        public async Task<IEnumerable<Biding>> GetcurrentbidsWithUserId(int adid, string UID)
        {
            
            var Data = await GetRecords<Biding>(@"SELECT * From CurrentBiding  where Addid=@adid AND biderid=@UID AND Status='Show' Order By id DESC LIMIT 5", new { adid, UID });
            return Data;
        }

        public async Task<bool> SaveBidsToDB(Biding biding)
        {
            var Data = await AddRecord(@"Insert into CurrentBiding (Addid,userid,startingbid,currentAmt,biderName,biderid,PlaceDate,Status) Values(@Addid,@userid,@startingbid,@currentAmt,@biderName,@biderid,@PlaceDate,@Status) ", new { biding.Addid, biding.userid, biding.startingbid, biding.currentAmt, biding.biderName, biding.biderid , biding.PlaceDate, biding.Status });
            return Data;
        }

        public async Task<Biding> GetBidfromdb(int Addid, string ownerid , int latestbid , int biderid)
        {
            
                var Data = await GetRecord<Biding>(@"SELECT * From CurrentBiding  where Addid=@Addid AND userid=@ownerid AND currentAmt=@latestbid AND  biderid=@biderid ", new { Addid, ownerid, latestbid, biderid });
                return Data;
        }

        public async Task<bool> SaveToWonBids(WonBids wonBids)
        {

            var Data = await AddRecord(@"Insert into WonBids (Addid,AddOwnerId,AddOwnerName,BiderId,BiderName,BiderWonAmount,DefaultAmount,MessSeen,OfferAccepted,Title) 
                                        VALUES (@Addid,@AddOwnerId,@AddOwnerName,@BiderId,@BiderName,@BiderWonAmount,@DefaultAmount,@MessSeen,@OfferAccepted,@Title) ", 
                                        new { wonBids.Addid, wonBids.AddOwnerId, wonBids.AddOwnerName, wonBids.BiderId, wonBids.BiderName, wonBids.BiderWonAmount, wonBids.DefaultAmount, wonBids.MessSeen, wonBids.OfferAccepted , wonBids.Title });
            return Data;
        }

        public async Task<Biding> AlreadyAvailoffer(int Addid, int biderid)
        {

            var Data = await GetRecord<Biding>(@"SELECT * From WonBids  where Addid=@Addid AND BiderId=@biderid", new { Addid, biderid });
            return Data;
        }

        public async Task<bool> Deleteavailwons(int Addid, string ownerid,int biderid)
        {
            if(ownerid == "0" && biderid == 0)
            {
                var Data = await UpdateRecord(@"DELETE FROM WonBids where Addid=@Addid", new { Addid });
                if (Data)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                var Data = await UpdateRecord(@"DELETE FROM WonBids where Addid=@Addid AND AddOwnerId=@ownerid AND BiderId=@biderid", new { Addid, ownerid, biderid });
                if (Data)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            
        }

        public async Task<WonBids> CheckAnyavailwonbid(int Addid)
        {

            var Data = await GetRecord<WonBids>(@"SELECT * From WonBids where Addid=@Addid", new { Addid});
            return Data;
        }

        public async Task<IEnumerable<WonBids>> GetWonBidsById(string ID)
        {
            var Data = await GetRecords<WonBids>(@"SELECT * From WonBids where BiderId=@ID", new { ID });
            return Data;
        }

        public async Task<bool> UpdateWonBids(int ADDID , string owner, string Bider , string Value)
        {
            if(Value == "Accepted")
            {
                var Data = await UpdateRecord(@"Update WonBids SET  OfferAccepted='true' , MessSeen='true' where Addid=@ADDID AND AddOwnerId=@owner AND BiderId=@Bider", new { ADDID, owner, Bider });
                return Data;
            }
            else
            {
                var Data = await UpdateRecord(@"Update WonBids SET  OfferAccepted='false' , MessSeen='true' where Addid=@ADDID AND AddOwnerId=@owner AND BiderId=@Bider", new { ADDID, owner, Bider });
                return Data;
            }
        }

        public async Task<WonBids> CheckForDetail(int Addid, string owner, string bider)
        {

            var Data = await GetRecord<WonBids>(@"SELECT * From WonBids  where Addid=@Addid AND AddOwnerId=@owner AND BiderId=@bider", new { Addid, owner , bider });
            return Data;
        }

        public async Task<bool> SecondbestFinish(int addid , int ownerid)
        {
            var Data = await UpdateRecord(@"Update Adds SET  status='Completed' where  id=@addid AND userid=@ownerid", new { addid , ownerid });
            if (Data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public async Task<bool> SavePaidReq(GetPaid getPaid)
        {
            var sql =await AddRecord(@"Insert into PaidRequest (UserId,UserName,TRX,Seen) VALUES (@UserId,@UserName,@TRX,@Seen)", new { getPaid.UserID, getPaid.UserName, getPaid.TRX, getPaid.Seen });
            if (sql)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        public async Task<GetPaid> GetPaidRequests(string UID)
        {
            var sql = await GetRecord<GetPaid>(@"SELECT * FROM PaidRequest where UserId=@UID", new { UID});
            return sql;
        }

        public async Task<BidingBlocked> GetWDOfUser(int UID)
        {
            var sql = await GetRecord<BidingBlocked>(@"SELECT * FROM BidingBlocked where UserId=@UID", new { UID });
            return sql;
        }

        public async Task<bool> AddNewMessAdmin(MessForAdmin MESS)
        {
            var sql = await AddRecord(@"INSERT INTO  MessForAdmin (Sender , Text , Value , Seen) VALUES(@Sender , @Text , @Value , @Seen)", new { MESS.Sender, MESS.Text, MESS.Value , MESS.Seen });
            return sql;
        }
        public async Task<bool> UpdateMessAdmin(MessForAdmin MESS)
        {
            var sql = await UpdateRecord(@"UPDATE MessForAdmin SET Text=@text where Sender=@Sender AND Value='WD'", new { text=MESS.Text , Sender=MESS.Sender });
            return sql;
        }

        public async Task<bool> UpdateBidsStatus(Biding biding)
        {
            var Data = await AddRecord(@"Update CurrentBiding SET Status='WD' Where Addid=@Addid AND biderid=@biderid AND biderName=@biderName", new { biding.Addid, biding.biderid, biding.biderName });
            return Data;
        }
        public async Task<IEnumerable<Biding>> IfAlreadyWDThisAuction(int adid, int UID)
        {
            var Data = await GetRecords<Biding>(@"SELECT * From CurrentBiding  where Addid=@adid AND biderid=@UID AND Status='WD' Order By id DESC LIMIT 5", new { adid, UID });
            return Data;
        }
        public async Task<IEnumerable<Biding>> Alreadybidthisuser(int adid, int UID)
        {
            var Data = await GetRecords<Biding>(@"SELECT * From CurrentBiding  where Addid=@adid AND biderid=@UID Order By id DESC LIMIT 5", new { adid, UID });
            return Data;
        }

        public async Task<bool> AddOrUpdatebidingBlock(BidingBlocked blocked, string Value)
        {
            if (Value == "Add")
            {
                var sql = await AddRecord(@"INSERT INTO  BidingBlocked (UserId , Number , WithdrawDate , AddId , Chance) VALUES(@UserId , @Number , @WithdrawDate , @AddId , @Chance)", new { blocked.UserId, blocked.Number, blocked.WithdrawDate, blocked.AddId, blocked.Chance });
                return sql;
            }
            else
            {
                var sql = await AddRecord(@"UPDATE BidingBlocked SET Number=@Number , WithdrawDate=@WithdrawDate , AddId=@AddId  where ID=@ID AND UserId=@UserId", new { Number = blocked.Number, WithdrawDate = blocked.WithdrawDate, AddId = blocked.AddId, ID = blocked.ID, UserId = blocked.UserId });
                return sql;

            }

        }

        // ADMIN QUERIES

        public async Task<IEnumerable<User>> AllUnveriedUsers()
        {
            var Data = await GetRecords<User>(@"SELECT * From Users  where AdminVerified='false'", new { });
            return Data;
        }
        public async Task<IEnumerable<User>> ShowAllUsers()
        {
            var Data = await GetRecords<User>(@"SELECT * From Users where UserType!='1'", new { });
            return Data;
        }

        public async Task<bool> MarkUserVerified(string ID)
        {
            var Data = await UpdateRecord(@"Update Users Set AdminVerified='true' where  ID=@ID  ", new { ID });
            return Data;
        }

        public async Task<bool> UpdateUserDataAdmin(User user)
        {

            try
            {
                if (user.Paid == "true")
                {
                    UpdateUserPaidrequest(user.ID);
                }
                var saved = await UpdateRecord(@"UPDATE Users SET UserName=@UserName , Password=@Password ,Address=@Address ,Fathername=@Fathername , Mobile=@Mobile , Paid=@Paid , Blocked=@Blocked where ID=@ID", new { UserName=user.UserName, Password = user.Password, Address = user.Address, Fathername=user.Fathername, Mobile=user.Mobile, Paid = user.Paid , Blocked = user.Blocked, ID = user.ID });
                if (saved)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception e)
            {
                return false;
            }

            return true;
        }

        public async Task UpdateUserPaidrequest(string UID)
        {

            try
            {
                var saved = await GetRecord<GetPaid>(@"SELECT * From PaidRequest where UserId=@UID and Seen='false'", new { UID });
                if (saved != null)
                {
                     await UpdateRecord(@"UPDATE PaidRequest SET Seen='true' where UserId=@UID" , new { UID});
                }
            }
            catch (Exception e)
            {
                
            }

           
        }






        public async Task<bool> DeleteUserByAdmin(User user)
        {
            var Data = await UpdateRecord(@"DELETE FROM Users  where ID=@UID", new { UID= user.ID });
            if (Data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<IEnumerable<Postadd>> AllAddsForAdmin()
        {
            var Data = await GetRecords<Postadd>(@"SELECT * from Adds where Deleted='false'");
            return Data;
        }

        public async Task<string> GetUserNameById(int ID)
        {
            var Data = await GetRecord<string>(@"SELECT UserName from Users where ID=@ID", new { ID});
            return Data;
        }


        public async Task<bool> AdminEditAdd(Postadd postadd)
        {
            var Data = await UpdateRecord(@"Update Adds SET  Title=@Title,Description=@Description,startingbid=@startingbid,status=@status where userid=@userid AND id=@id", new { Title = postadd.Title, Description = postadd.Description, startingbid = postadd.startingbid, userid = postadd.userid, id = postadd.id , status=postadd.status });
            if (Data)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public async Task<int> CountOfAllusers()
        {
            var Data = await GetRecord<int>(@"SELECT Count(*) FROM Users where UserType='0'");
            return Data;
        }
        public async Task<int> CountOfAllUnVerified()
        {
            var Data = await GetRecord<int>(@"SELECT Count(*) FROM Users where UserType='0' AND AdminVerified='false'");
            return Data;
        }

        public async Task<int> CountOfAllAuctions()
        {
            var Data = await GetRecord<int>(@"SELECT Count(*) FROM Adds where Deleted='false'");
            return Data;
        }
        public async Task<int> CountOfAllAdds()
        {
            var Data = await GetRecord<int>(@"SELECT Count(*) FROM Adds");
            return Data;
        }
        public async Task<int> CountOfBlockedAuctioner()
        {
            var Data = await GetRecord<int>(@"SELECT Count(*) FROM BidingBlocked where Number='3'");
            return Data;
        }
        public async Task<int> CountOfQuries()
        {
            var Data = await GetRecord<int>(@"SELECT Count(*) FROM MessForAdmin where Seen='false'");
            return Data;
        }

        public async Task<int> CountOfAllPaidReq()
        {
            var Data = await GetRecord<int>(@"SELECT Count(*) FROM PaidRequest where Seen='false'");
            return Data;
        }

        public async Task<bool> AllUnPaidReqstatuschange()
        {
            var Data = await AddRecord(@"UPDATE PaidRequest Set Seen='true' where Seen='false'");
            return Data;
        }

        public async Task<IEnumerable<GetPaid>> AllUnPaidReq()
        {
            var Data = await GetRecords<GetPaid>(@"SELECT * FROM PaidRequest where Seen='false'");
            return Data;
        }

        public async Task<IEnumerable<User>> GetAllUsersIds()
        {
            var Data = await GetRecords<User>(@"SELECT * FROM Users where userType='0'");
            return Data;
        }

        public async Task<string> GetAllAddsCount(string id)
        {
            var Data = await GetRecord<string>(@"SELECT Count(*) FROM Adds where userid=@id", new { id });
            return Data;
        }

        public async Task<string> GetAllBidsCount(string id)
        {
            var Data = await GetRecord<string>(@"SELECT Count(*) FROM CurrentBiding where userid=@id", new { id });
            return Data;
        }

        public async Task<string> GetAllWonsCount(string id)
        {
            var Data = await GetRecord<string>(@"SELECT Count(*) FROM WonBids where BiderId=@id AND OfferAccepted='true'", new { id });
            return Data;
        }

        //ORG REPORT

        public async Task<IEnumerable<User>> OrgUsers()
        {
            var Data = await GetRecords<User>(@"SELECT [ID],[Paid],[Blocked] FROM Users where userType='0'");
            return Data;
        }
        public async Task<IEnumerable<WonBids>> OrgWonbids()
        {
            var Data = await GetRecords<WonBids>(@"SELECT [OfferAccepted] FROM WonBids");
            return Data;
        }
        public async Task<string> OrgAllAuction()
        {
            var Data = await GetRecord<string>(@"SELECT Count(*) FROM Adds");
            return Data;
        }

        public async Task<string> OrgAllBids()
        {
            var Data = await GetRecord<string>(@"SELECT Count(*) FROM CurrentBiding");
            return Data;
        }

        public async Task<IEnumerable<BidingBlocked>> AllBlockedAuctioners()
        {
            var Data = await GetRecords<BidingBlocked>(@"SELECT * FROM BidingBlocked where Number='3'");
            return Data;
        }

        public async Task<bool> UnblockBlockedAuctioners(int UID , int ID)
        {
            var sql = await AddRecord(@"UPDATE BidingBlocked SET Number='0' , Chance='true'  where ID=@ID AND UserId=@UID", new { ID , UID });
            return sql;
        }

        public async Task<IEnumerable<MessForAdmin>> AllQuriesForAdmin()
        {
            var sql = await GetRecords<MessForAdmin>(@"SELECT * FROM MessForAdmin where Seen='false'", new { });
            return sql;
        }
        public async Task<MessForAdmin> Querywithid(int ID)
        {
            var sql = await GetRecord<MessForAdmin>(@"SELECT * FROM MessForAdmin where Seen='false' and ID=@ID", new { ID });
            return sql;
        }

        public async Task<bool> Updateseenandreply(MessForUser Reply , int ID)
        {
            await AddRecord(@"UPDATE MessForAdmin SET Seen='true' where ID=@ID", new { ID = ID });
            var saved =  await AddRecord(@"INSERT INTO  MessForUser (UserID , Text , Value , Received) VALUES(@UserID , @Text , @Value , @Received)", new { ID = ID , UserID = Reply.UserID, Text = Reply.Text, Value = Reply.Value, Received = Reply.Received });
            return saved;
        }


    }
}
