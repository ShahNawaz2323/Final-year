﻿using Dapper;
using LinqToDB;
using Microsoft.AspNetCore.Connections;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.Repositories
{
    public class DapperWrap
    {
        //string connectionstring = "Integrated Security=SSPI;Initial Catalog=model;Data Source=DESKTOP-H858HDP\\SQLEXPRESS;";
        string connectionstring = "Data Source=.\\projectdb.db";
        public async Task<long> AddAsync<TEntity>(string sql, TEntity entity)
        {
            using (var connection = new SQLiteConnection(connectionstring))
            {
                try
                {
                    await connection.OpenAsync();

                    var results = await connection.QueryAsync<long>(sql, entity);

                    // await _mediator.Send(new EntityCreatedEventData<TEntity>(entity));

                    return results.Single();
                }
                catch (SqlException e)
                {
                   
                }
            }
            return 0;
            
        }
        public async Task<IEnumerable<T>> GetRows<T>(string sql, object parameters = null)
        {
            return await GetRecords<T>(sql, parameters);
        }

        /// <summary>
        /// Return rows from db, supports very long list of params
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sql"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        
        public async Task<IEnumerable<T>> GetRecords<T>(string sql, object parameters = null)
        {
            IEnumerable<T> records = default;

            using (var connection = new SQLiteConnection(connectionstring))
            {
                try
                {
                    await connection.OpenAsync();
                    records = await connection.QueryAsync<T>(sql, parameters);
                }
                catch (Exception originalException)
                {
                   
                }
            }

            // @TODO: return empty lists instead of null
            /*if (records == null)
            {
                records = new List<T>();
            }*/
            return records;
        }

        public async Task<T> GetRecord<T>(string sql, object parameters = null)
        {
            T record = default;

            using (var connection = new SQLiteConnection(connectionstring))
            {
                try
                {
                    await connection.OpenAsync();
                    record = await connection.QueryFirstOrDefaultAsync<T>(sql, parameters);
                }
                catch (Exception originalException)
                {
                    
                }
            }

            return record;
        }

        /// <summary>
        /// Create new entity and fire EntityCreatedEventData event
        /// </summary>
        /// <typeparam name="TEntity"></typeparam>
        /// <param name="sql"></param>
        /// <param name="entity"></param>
        /// <returns>Scope Identity</returns>
       

        public async Task<bool> AddRecord(string sql, object parameters = null)
        {
            
            using (var connection = new SQLiteConnection(connectionstring))
            {
                try
                {
                    await connection.OpenAsync();
                    await connection.QueryFirstAsync(sql, parameters);
                    return true;
                }
                catch (Exception originalException)
                {
                    if(originalException.Message ==  "Sequence contains no elements")
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    
                }
            }
        }

        public async Task<bool> AddRecords(string sql, object parameters = null)
        {
            using (var connection = new SQLiteConnection(connectionstring))
            {
                try
                {
                    await connection.OpenAsync();
                    await connection.ExecuteAsync(sql, parameters);
                    return true;
                }
                catch (Exception originalException)
                {
                    return false;
                }
            }
        }

        public async Task<bool> UpdateRecord(string sql, object parameters = null)
        {
           
            using (var connection = new SQLiteConnection(connectionstring))
            {
                try
                {
                    await connection.OpenAsync();
                    await connection.ExecuteAsync(sql, parameters);
                    return true;
                }
                catch (Exception originalException)
                {
                    return false;
                }
            }
        }

        public async Task<long> ExecSP(string sql, object parameters = null)
        {
            long count = 0;

            using (var connection = new SQLiteConnection(connectionstring))
            {
                try
                {
                    await connection.OpenAsync();
                    count = await connection.ExecuteAsync(sql, parameters, commandType: System.Data.CommandType.StoredProcedure);
                }
                catch (SqlException e)
                {
                    
                }
                catch (Exception originalException)
                {
                   
                }
            }
            return count;
        }

        public async Task<IEnumerable<T>> GetExecSP<T>(string SP, object parameters = null)
        {
            IEnumerable<T> records = default;

            using (var connection = new SQLiteConnection(connectionstring))
            {
                try
                {
                    await connection.OpenAsync();
                    records = await connection.QueryAsync<T>(SP, parameters, commandType: System.Data.CommandType.StoredProcedure);
                }
                catch (Exception originalException)
                {
                    
                }
            }
            return records;
        }
    }
}