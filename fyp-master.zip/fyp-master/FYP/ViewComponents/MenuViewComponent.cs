﻿
using FYP.classes;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.ViewComponents
{
    public class MenuViewComponent : ViewComponent
    {
        private readonly IConfiguration _configuration;
        
        public MenuViewComponent()
        {
           
        }

        public async Task<IViewComponentResult> InvokeAsync(MenuType menuType, UserType userType)
        {
            Menu menu = null;
            
            switch (menuType)
            {
                case MenuType.BackendTop:
                    menu = BackendTopMenu(userType);
                    break;

                case MenuType.BackendSideManager:
                    menu = BackendSide(userType);
                    break;

                case MenuType.BackendSide:
                    menu = BackendSide(userType);
                    break;


                case MenuType.FrontendSide:
                    menu = BettorMenu(userType);
                    break;
            }

            var viewName = menuType.ToString();
            return View(viewName, menu);
        }

        private Menu BackendTopMenu(UserType userType)
        {
            var menu = new Menu();

            return menu;
        }

        private Menu BackendSide(UserType userType)
        {
            var menu = new Menu();
            switch (userType)
            {
                case UserType.Admin:
                    menu.Add(MenuFactory.Deleted);
                    break;
                case UserType.Manager:
                    menu.Add(MenuFactory.DeletedManagerAdds);
                    break;
            }
            return menu;
        }

        private Menu BettorMenu(UserType userType)
        {
            var menu = new Menu();

            switch (userType)
            {
                case UserType.Customer:
                    menu.Add(MenuFactory.PostAdd);
                    menu.Add(MenuFactory.WinningBids);
                    break;

            }
            return menu;
        }

    }
}
