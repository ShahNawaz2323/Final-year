﻿using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace FYP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class signuploginController : ControllerBase
    {
        
        //[HttpPost("AddUser", Name = "AddUser")]
        //public async Task<string> AddUser(User user)
        //{
        //   var Data =  userRepo.AddAsync(user);

        //    string empty = "";
        //    return empty;
        //}
    }
}
