using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class HomeModel : PageModel
    {
        public async Task<IActionResult> OnGetAsync()
        {
            var TypeExist = HttpContext.Session.GetString("UserType");
            if (!string.IsNullOrEmpty(TypeExist))
            {
                if (TypeExist == "0")
                {
                    return RedirectToPage("/Common/Dashboard");
                }
                else if (TypeExist == "1")
                {
                    return RedirectToPage("/Admin/Home");
                }
                else if (TypeExist == "2")
                {
                    return RedirectToPage("/Manager/Home");
                }
            }
            return default;
        }
    }
}
