using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class AddDetailModel : PageModel
    {
        [BindProperty]
        public Postadd AddData { get; set; }
        public bool CanStart { get; set; }

        public string Status { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            try
            {
                var user = HttpContext.Session.GetString("UserName".ToString());
                var ID = HttpContext.Session.GetString("ID".ToString());
                var Type = HttpContext.Session.GetString("UserType".ToString());
                if (string.IsNullOrEmpty(user) || ID == "0" || Type != "0")
                {
                    return RedirectToPage("/Common/Login");
                }
                var MyID = HttpContext.Session.GetString("ID".ToString());
                if (id != 0)
                {
                    UserRepo userRepo = new UserRepo();
                    var Add = await userRepo.AddById(id);
                    if(Add == null)
                    {
                        return RedirectToPage("/Common/Dashboard");
                    }
                    var CB = await userRepo.Getcurrentbids(id, true);
                    AddData = Add;
                    if (AddData.userid.ToString() == MyID)
                    {
                        CanStart = true;
                    }
                    if (AddData != null)
                    {
                        List<string> Imagenames = new List<string>();
                        string[] names = AddData.Imagestring.Split("///");
                        foreach (var img in names)
                        {
                            Imagenames.Add(img);
                        }
                        AddData.ImgNameInFolder = Imagenames;

                    }

                    if (Add.Bidstart == "false" && CB.Count() > 0)
                    {
                        Status = "Biding Finished ";
                    }
                    else if (Add.Bidstart == "false" && CB.Count() == 0 || CB == null)
                    {
                        Status = "Biding Not Started Yet";
                    }
                    else if (Add.Bidstart == "true")
                    {
                        Status = "Biding Started";
                    }
                }
            }
            catch (Exception e)
            {

            }
            return Page();
        }

        public async Task<IActionResult> OnGetStatus(int ADDID)
        {
            var status = "";
            var userid = HttpContext.Session.GetString("ID".ToString());
            UserRepo userRepo = new UserRepo();
            var Add = await userRepo.AddById(ADDID);
            if (Add == null)
            {
                status = "Auction WithDrawn By Owner";
            }
            var TimeNow = DateTime.Now;
            if (!string.IsNullOrEmpty(Add.AutoStop))
            {
                var AddStopTime = Convert.ToDateTime(Add.AutoStop);
                if(AddStopTime <= TimeNow)
                {
                    await userRepo.StartStopBiding(userid, ADDID, "false");
                    await userRepo.FinishBidingstatus(userid, ADDID, "Completed");
                }
            }
            var CB = await userRepo.Getcurrentbids(ADDID, true);
            
            if (Add.Bidstart == "false" && CB.Count() > 0)
            {
                status = "Biding Finished";
            }else if (Add.Bidstart == "false" && Add.status == "Completed"  && CB.Count() == 0 || CB == null)
            {
                status = "Biding Finished With No Bids";
            }
            else if (Add.Bidstart == "false" && Add.status == "NotCompleted" && CB.Count() == 0 || CB == null)
            {
                status = "Biding Not started";
            }
            else if (Add.Bidstart == "true" && Add.status == "NotCompleted")
            {
                status = "Biding Started";
            }

            return new JsonResult(status);
        }

        public async Task<IActionResult> OnGetStatusOfStop(int ADDID)
        {
            var status = "";
            var userid = HttpContext.Session.GetString("ID".ToString());
            UserRepo userRepo = new UserRepo();
            var Add = await userRepo.AddById(ADDID);
            if (Add == null)
            {
                status = "Auction WithDrawn By Owner";
            }
            else
            {
                if(Add.Bidstart == "true")
                {
                    var currenttime = DateTime.Now;
                    var stoptime = Convert.ToDateTime(Add.AutoStop);
                    var remaining = stoptime-currenttime;
                    status = remaining.ToString(@"dd\.hh\:mm\:ss");
                    var split = status.Split(".");
                    status = split[0] + " Days " + split[1]; 
                }
                else
                {
                    status = "Biding Stoped";
                }
                
            }
            
            return new JsonResult(status);
        }





        public async Task<IActionResult> OnGetAutostartstop(int ADDID)
        {
            UserRepo userRepo = new UserRepo();
            var Add = await userRepo.AddById(ADDID);
            if (!string.IsNullOrEmpty(Add.AutoStart))
            {
                var alreadybids = await userRepo.Getcurrentbids(Add.id, true);
                if (alreadybids != null && alreadybids.Count() == 0)
                {
                    var addtime = Convert.ToDateTime(Add.AutoStart);
                    if (addtime <= DateTime.Now)
                    {
                        await userRepo.StartStopBiding(Add.userid.ToString(), Add.id, "true");
                    }
                }

            }
            if (!string.IsNullOrEmpty(Add.AutoStop))
            {
                    var addtime = Convert.ToDateTime(Add.AutoStop);
                    var current = DateTime.Now;
                    if (current >= addtime)
                    {
                        await userRepo.StartStopBiding(Add.userid.ToString(), Add.id, "false");
                        await userRepo.FinishBidingstatus(Add.userid.ToString(), Add.id, "Completed");
                    }
                var Osended = await userRepo.CheckAnyavailwonbid(ADDID);
                if(Osended == null)
                {
                    var bidings = await userRepo.Getcurrentbids(ADDID, false);
                    if(bidings != null)
                    {
                        var Values = bidings.Select(x => x.currentAmt);
                        var maxval = Values.Max();

                        var maxbid = bidings.Where(x => x.currentAmt == maxval).FirstOrDefault();
                        var Livebid = await userRepo.GetBidfromdb(maxbid.Addid, maxbid.userid.ToString(), maxbid.currentAmt, maxbid.biderid);
                        if(Livebid != null)
                        {
                            var bider = await userRepo.GetByIdAsync(maxbid.biderid);
                            var addowner = await userRepo.GetByIdAsync(Add.userid);
                            WonBids wonBids = new WonBids();
                            wonBids.Addid = ADDID;
                            wonBids.AddOwnerId = maxbid.userid;
                            wonBids.AddOwnerName = addowner.UserName;
                            wonBids.BiderId = maxbid.biderid;
                            wonBids.BiderName = bider.UserName;
                            wonBids.BiderWonAmount = maxbid.currentAmt;
                            wonBids.DefaultAmount = Add.startingbid;
                            wonBids.MessSeen = "false";
                            wonBids.OfferAccepted = "false";
                            wonBids.Title = Add.Title;
                            await userRepo.SaveToWonBids(wonBids);
                        }
                    }
                }
            }
            return new JsonResult("");
        }

        public async Task<IActionResult> OnGetShowbids(int ADDID)
             {
            List<Biding> bids = new List<Biding>();
            UserRepo userRepo = new UserRepo();
            var Add = await userRepo.AddById(ADDID);
            var MyID = HttpContext.Session.GetString("ID".ToString());
            if (Add != null)
            {
                if(Add.userid != Convert.ToInt32(MyID))
                {
                    if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype != "Private")
                    {
                        var CB = await userRepo.Getcurrentbids(ADDID, true);
                        return Partial("../PartialViews/_CurrentBids", CB);
                    }
                    else if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "Private")
                    {
                        var CB = await userRepo.GetcurrentbidsWithUserId(ADDID, MyID);
                        return Partial("../PartialViews/_CurrentBids", CB);
                    }
                    else if (Add.Bidstart == "true" && Add.status == "Completed" && Add.bidtype != "Private")
                    {
                        var CB = await userRepo.GetcurrentbidsWithUserId(ADDID, MyID);
                        return Partial("../PartialViews/_CurrentBids", CB);
                    }
                    else
                    {
                        var CB = await userRepo.Getcurrentbids(ADDID, true);
                        return Partial("../PartialViews/_CurrentBids", CB);
                    }
                }
                else
                {
                    var CB = await userRepo.Getcurrentbids(ADDID, true);
                    if(CB.Count() > 0 && CB != null)
                    {
                        return Partial("../PartialViews/_CurrentBids", CB);
                    }
                    
                }
                
            }

            return new JsonResult("");
        }

        public async Task<IActionResult> OnGetAddorminusamount(int UID, int ADDID) 
        {
            var MyID = HttpContext.Session.GetString("ID".ToString());
            BidingAmounts bidAMT = new BidingAmounts();
            UserRepo userRepo = new UserRepo();
            var user = await userRepo.GetByIdAsync(Convert.ToInt32(MyID));
            if (user.Paid == "true")
            {
                bidAMT.ADDOID = UID.ToString();
                bidAMT.ADDID = ADDID.ToString();
                bidAMT.CUID = MyID;
                var CB = await userRepo.Getcurrentbids(ADDID, true);
                if (CB != null || CB.Count() > 0)
                {
                    bidAMT.samebid = false;
                }
                else
                {
                    bidAMT.samebid = true;
                }

                var Add = await userRepo.AddById(ADDID);
                if (Add.userid != Convert.ToInt32(MyID))
                {
                    if (Add != null)
                    {
                        if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "English")
                        {
                            bidAMT.BidType = "English";
                            return Partial("../PartialViews/_Amounts", bidAMT);
                        }
                        else if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "Reverse")
                        {
                            bidAMT.BidType = "Reverse";
                            return Partial("../PartialViews/_Amounts", bidAMT);
                        }
                        else if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "SecondBest")
                        {
                            bidAMT.BidType = "SecondBest";
                            return Partial("../PartialViews/_Amounts", bidAMT);
                        }
                        else if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "Private")
                        {
                            bidAMT.BidType = "Private";
                            return Partial("../PartialViews/_Amounts", bidAMT);
                        }
                    }
                }
            }
            return new JsonResult("");
        }


        public async Task<IActionResult> OnGetSendbid(int AMOUNT, int CUID , int ADDOID , int ADDID)
        {
            UserRepo userRepo = new UserRepo();
            Biding biding = new Biding();
            int reverseBid = 0;
            biding.Addid = ADDID;
            biding.biderid = CUID;
            biding.biderName =  HttpContext.Session.GetString("UserName".ToString());


            var AlreadyBlocked = await userRepo.GetWDOfUser(CUID);

            var AlreadyThis = await userRepo.IfAlreadyWDThisAuction(ADDID, CUID);
            var AddData = await userRepo.AddById(ADDID);
            var CB = await userRepo.Getcurrentbids(ADDID, true);
            if(AMOUNT == 101)
            {
                if(CB != null &&  CB.Count() > 0)
                {
                    return new JsonResult("Same Bid Is Not Allowed");
                }
            }

            if (AMOUNT < 0 && CB.Count() > 0 && CB != null)
            {
                if(CB.FirstOrDefault().currentAmt > AddData.startingbid)
                {
                    return new JsonResult("Now Reverse value is not allowed");
                }
            }
            //checked if user already withdraw in this auction
            if (AlreadyThis.Any() && AlreadyThis != null)
            {
                return new JsonResult("You Are Not Allowed To Bid AnyMore In This Auction");
            }

            //checked that user already withdrawn 3 auctions or not
            if(AlreadyBlocked != null && AlreadyBlocked.Number == 3)
            {
                return new JsonResult("Biding Permanently Blocked. Contact Admin");
            }

            //this is the actual with drawn function
            if (AMOUNT == 00000 || AMOUNT == 0)
            {

                var Alreadybid = await userRepo.Alreadybidthisuser(ADDID, CUID);
                if(Alreadybid == null || Alreadybid.Count() == 0)
                {
                    return new JsonResult("No Bids Found To Withdraw");
                }
                if (AlreadyBlocked == null)
                {
                    BidingBlocked bidblock = new BidingBlocked();
                    bidblock.UserId = CUID;
                    bidblock.Number = 1;
                    bidblock.WithdrawDate = DateTime.Now.ToString();
                    bidblock.AddId = ADDID.ToString();
                    bidblock.Chance = "false";
                    var saved = await userRepo.AddOrUpdatebidingBlock(bidblock,"Add");
                    if (saved)
                    {
                        await userRepo.UpdateBidsStatus(biding);
                        return new JsonResult("Your Auction WithDrawn");
                    }
                    else
                    {
                        return new JsonResult("Error While With Drawing");
                    }
                }
                else
                {
                    if (AlreadyBlocked.Number == 0)
                    {
                        BidingBlocked bidblock = new BidingBlocked();
                        bidblock.ID = AlreadyBlocked.ID;
                        bidblock.UserId = CUID;
                        bidblock.Number = 1;
                        bidblock.WithdrawDate = AlreadyBlocked.WithdrawDate + " NEXT "+ DateTime.Now.ToString();
                        bidblock.AddId = AlreadyBlocked.AddId+" NEXT "+ADDID;

                        var saved = await userRepo.AddOrUpdatebidingBlock(bidblock, "Update");
                        if (saved)
                        {
                            await userRepo.UpdateBidsStatus(biding);
                            return new JsonResult("Your Auction WithDrawn");
                        }
                        else
                        {
                            return new JsonResult("Error While With Drawing");
                        }

                    }
                    else if (AlreadyBlocked.Number == 1)
                    {
                        BidingBlocked bidblock = new BidingBlocked();
                        bidblock.ID = AlreadyBlocked.ID;
                        bidblock.UserId = CUID;
                        bidblock.Number = 2;
                        bidblock.WithdrawDate = AlreadyBlocked.WithdrawDate + " NEXT " + DateTime.Now.ToString();
                        bidblock.AddId = AlreadyBlocked.AddId + " NEXT " + ADDID;

                        var saved = await userRepo.AddOrUpdatebidingBlock(bidblock, "Update");
                        if (saved)
                        {
                            await userRepo.UpdateBidsStatus(biding);
                            return new JsonResult("Your Auction WithDrawn");
                        }
                        else
                        {
                            return new JsonResult("Error While With Drawing");
                        }
                    }
                    else if(AlreadyBlocked.Number == 2)
                    {

                        BidingBlocked bidblock = new BidingBlocked();
                        bidblock.ID = AlreadyBlocked.ID;
                        bidblock.UserId = CUID;
                        bidblock.Number = 3;
                        bidblock.WithdrawDate = AlreadyBlocked.WithdrawDate + " NEXT " + DateTime.Now.ToString();
                        bidblock.AddId = AlreadyBlocked.AddId + " NEXT " + ADDID;

                        var saved = await userRepo.AddOrUpdatebidingBlock(bidblock, "Update");
                        if (saved)
                        {
                            await userRepo.UpdateBidsStatus(biding);
                            return new JsonResult("Your Auction WithDrawn");
                        }
                        else
                        {
                            return new JsonResult("Error While With Drawing");
                        }

                    }
                }
            }

            else
            {
                if (AddData.bidtype == "Reverse")
                {
                    var Firstvalue = (AddData.startingbid * 20) / 100;
                    var final = AddData.startingbid - Firstvalue;
                    reverseBid = final;
                    if (CB != null && CB.Count() > 0)
                    {
                        var CAMT = CB.FirstOrDefault().currentAmt;
                        var ToBid = CAMT + AMOUNT;
                        if (ToBid < reverseBid)
                        {
                            return new JsonResult("Price Less Then 20% Is Not Allowed");
                        }
                        else
                        {
                            biding.currentAmt = ToBid;
                        }
                    }
                    else
                    {
                        var ToBid = AddData.startingbid + AMOUNT;

                        if (ToBid < reverseBid)
                        {
                            return new JsonResult("Price Less Then 20% Is Not Allowed");
                        }
                        else
                        {
                            biding.currentAmt = ToBid;
                        }
                        //biding.currentAmt = AddData.startingbid + AMOUNT;
                    }
                    //Reverse Biding Amount Set End Here

                }
                else if (AddData.bidtype == "SecondBest")
                {
                    if (CB == null || CB.Count() == 0)
                    {
                        biding.currentAmt = AddData.startingbid + AMOUNT;
                    }
                    else
                    {
                        if (CB.Count() <= 1)
                        {
                            var CAMT = CB.FirstOrDefault().currentAmt;
                            biding.currentAmt = CAMT + AMOUNT;
                            biding.startingbid = AddData.startingbid;
                            biding.userid = ADDOID;
                            await userRepo.SaveBidsToDB(biding);
                            await userRepo.SecondbestFinish(ADDID, ADDOID);
                            return new JsonResult("");
                        }
                        else if (CB.Count() >= 2)
                        {
                            await userRepo.SecondbestFinish(ADDID, ADDOID);
                            return new JsonResult("");
                        }
                    }
                }
                else if (AddData.bidtype == "Private")
                {
                    var myId = HttpContext.Session.GetString("ID".ToString());
                    CB = await userRepo.GetMycurrentbids(ADDID, myId);
                    if (CB != null && CB.Count() > 0)
                    {
                        var CAMT = CB.FirstOrDefault().currentAmt;
                        biding.currentAmt = CAMT + AMOUNT;
                    }
                    else
                    {
                        biding.currentAmt = AddData.startingbid + AMOUNT;
                    }
                }
                else
                {
                    if (CB != null && CB.Count() > 0)
                    {
                        var CAMT = CB.FirstOrDefault().currentAmt;
                        biding.currentAmt = CAMT + AMOUNT;
                    }
                    else
                    {
                        biding.currentAmt = AddData.startingbid + AMOUNT;
                    }
                }
                biding.startingbid = AddData.startingbid;
                biding.userid = ADDOID;
                biding.PlaceDate = DateTime.Now.ToString();
                biding.Status = "Show";
                if(AMOUNT == 0101)
                {
                    if(CB == null || CB.Count() == 0)
                    {
                        biding.currentAmt = AddData.startingbid;
                    }
                }
                if(AddData.Grace < 5)
                {
                    if (!string.IsNullOrEmpty(AddData.AutoStop))
                    {
                        var stoptime = Convert.ToDateTime(AddData.AutoStop);
                        var timenow = DateTime.Now;

                        var timeremaining = stoptime - timenow;
                        if (timeremaining < TimeSpan.FromMinutes(5))
                        {
                         var grace = AddData.Grace + 1;
                            var OldTime = Convert.ToDateTime(AddData.AutoStop);
                            var newTime = OldTime.AddMinutes(30).ToString();
                            await userRepo.UpdateGraceTime(AddData.userid.ToString(), AddData.id, newTime, grace);
                        }


                    }
                }
                await userRepo.SaveBidsToDB(biding);
                return new JsonResult("");
            }

            return new JsonResult("");
        }


    }
}
