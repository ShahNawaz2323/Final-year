using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class ReviewProfileModel : PageModel
    {
        public List<Commentview> commentview { get; set; }
        public double overall  { get; set; }
        public Rateing Rateing { get; set; }
        public User user { get; set; }
        public async Task OnGetAsync(int UID)
        {
            try
            {
                UserRepo userRepo = new UserRepo();
                user = await userRepo.GetByIdAsync(UID);
                Rateing = await userRepo.GetUserRateing(UID);
                if (Rateing != null)
                {
                    overall = (double)(5 * Rateing.Five + 4 * Rateing.Four + 3 * Rateing.Three + 2 * Rateing.Two + 1 * Rateing.One) / (Rateing.One + Rateing.Two + Rateing.Three + Rateing.Four + Rateing.Five);

                    overall = Math.Round(overall, 1);
                }
                else
                {
                    Rateing = new Rateing();
                    Rateing.UserId = UID.ToString();
                }
                var Comments = await userRepo.GetAllComments(UID);
                if (Comments != null && Comments.Count() > 0)
                {
                    List<Commentview> List = new List<Commentview>();
                    foreach (var comment in Comments)
                    {
                        Commentview single = new Commentview();
                        var commenter = await userRepo.GetByIdAsync(Convert.ToInt32(comment.CommenterId));
                        single.commentername = commenter.UserName;
                        single.comment = comment.Comment;
                        List.Add(single);
                    }
                    commentview = List;
                }
            }
            catch (Exception e)
            {

            }
        }
    }
}
