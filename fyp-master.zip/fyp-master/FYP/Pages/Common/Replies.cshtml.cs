using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class RepliesModel : PageModel
    {
        UserRepo userRepo = new UserRepo();


        public IEnumerable<MessForUser> messForUser { get; set; }


        public async Task<IActionResult> OnGetAsync()
        {
            var ID = HttpContext.Session.GetString("ID");
            if (string.IsNullOrEmpty(ID))
            {
                return RedirectToPage("/Common/Login");
            }
            else
            {
                messForUser = await userRepo.RepliesFromAdmin(ID);
                await userRepo.UpdateSeenStatus(ID);
                return Page();
            }
            return default;
           
        }
    }
}
