using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class MyWonModel : PageModel
    {
        public IEnumerable<WonBids> wonBids { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            UserRepo userRepo = new UserRepo();
            var CUID = HttpContext.Session.GetString("ID".ToString());
            if (string.IsNullOrEmpty(CUID) || CUID == "0")
            {
                return RedirectToPage("/Common/Login");
            }
            wonBids =  await userRepo.GetWonBidsById(CUID);
            wonBids = wonBids.Reverse();
            return default;
        }

        public async Task<IActionResult> OnGetAcceptedOffer(int ADDID, string ownr)
        {
            UserRepo userRepo = new UserRepo();
            var userid = HttpContext.Session.GetString("ID".ToString());
            var saved = await userRepo.UpdateWonBids(ADDID, ownr, userid, "Accepted");
            if (saved)
            {
                return new JsonResult("success");
            }
            else
            {
                return new JsonResult("error");
            }
        }
        public async Task<IActionResult> OnGetDeclineOffer(int ADDID, string ownr)
        {
            UserRepo userRepo = new UserRepo();
            var userid = HttpContext.Session.GetString("ID".ToString());
            var saved = await userRepo.UpdateWonBids(ADDID, ownr, userid, "Decline");
            if (saved)
            {
                return new JsonResult("success");
            }
            else
            {
                return new JsonResult("error");
            }
        }

        public async Task<IActionResult> OnGetShowDetail(int addid, string addownr)
        {
            UserRepo userRepo = new UserRepo();
            OwnerDetail ownerDetail = new OwnerDetail();
            var userid = HttpContext.Session.GetString("ID".ToString());
            var data =await userRepo.CheckForDetail(addid, addownr, userid);
            if(data != null)
            {
                if(data.MessSeen == "true" && data.OfferAccepted == "true")
                {
                    var owner = await userRepo.GetByIdAsync(Convert.ToInt32(addownr));

                    var rated = await userRepo.GetCommentOfAdd(addid, addownr);
                    var tracking = await userRepo.GetTrackingDetail(addid, userid);

                    ownerDetail.ownername = owner.UserName;
                    ownerDetail.Email = owner.Email;
                    ownerDetail.Number = owner.Mobile;
                    ownerDetail.sellerid = owner.ID;
                    ownerDetail.addid = addid;

                    if(rated != null)
                    {
                        ownerDetail.alreadyrated = true;
                    }
                    if(tracking != null)
                    {
                        ownerDetail.trackingcode = tracking.Tracking;
                    }
                }
            }
            return Partial("../PartialViews/_OwnerDetail", ownerDetail);
        }

        public async Task<IActionResult> OnGetRateing(int UID, int star, string Comment, int Addid)
        {
            UserRepo userRepo = new UserRepo();
            var oldrate = await userRepo.GetUserRateing(UID);
            var Commenter = HttpContext.Session.GetString("ID".ToString());
            Comments comment = new Comments();
            if (oldrate == null)
            {
                Rateing rateing = new Rateing();
                rateing.UserId = UID.ToString();
                if (star == 5)
                {
                    rateing.Five = 1;
                }
                if (star == 4)
                {
                    rateing.Four = 1;
                }
                if (star == 3)
                {
                    rateing.Three = 1;
                }
                if (star == 2)
                {
                    rateing.Two = 1;
                }
                if (star == 1 || star == 0)
                {
                    rateing.One = 1;
                }
                comment.CommenterId = Commenter;
                comment.UserId = UID.ToString();
                comment.AddId = Addid;
                if (string.IsNullOrEmpty(Comment))
                {
                    comment.Comment = "No Comment";
                }
                else
                {
                    comment.Comment = Comment;
                }
                await userRepo.AddComment(comment);
                await userRepo.AddNewRateing(rateing);
            }
            else
            {
                if (star == 5)
                {
                    oldrate.Five = oldrate.Five + 1;
                }
                if (star == 4)
                {
                    oldrate.Four = oldrate.Four + 1;
                }
                if (star == 3)
                {
                    oldrate.Three = oldrate.Three + 1;
                }
                if (star == 2)
                {
                    oldrate.Two = oldrate.Two + 1;
                }
                if (star == 1 || star == 0)
                {
                    oldrate.One = oldrate.One + 1;
                }
                comment.UserId = UID.ToString();
                comment.AddId = Addid;
                if (string.IsNullOrEmpty(Comment))
                {
                    comment.Comment = "No Comment";
                }
                else
                {
                    comment.Comment = Comment;
                }
                comment.CommenterId = Commenter;
                await userRepo.AddComment(comment);
                await userRepo.UpdateUserRateing(oldrate);
            }

            return new JsonResult("");

        }


    }
}
