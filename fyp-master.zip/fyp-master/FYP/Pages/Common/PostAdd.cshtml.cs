using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.IO;
using Microsoft.AspNetCore.Hosting;
namespace FYP.Pages.Common
{
    public class PostAddModel : PageModel
    {
        [BindProperty]
        public Postadd AddData { get; set; } = new Postadd();

        [BindProperty]
        public IFormFile image1 { get; set; }

        [BindProperty]
        public IFormFile image2 { get; set; }

        [BindProperty]
        public IFormFile image3 { get; set; }

        [BindProperty]
        public IFormFile image4 { get; set; }


        [BindProperty]
        public string Username { get; set; }

        [BindProperty]
        public bool AutoStartbool { get; set; }

        [BindProperty]
        public DateTime AutoStart { get; set; }


        public List<SelectListItem> Cities = new List<SelectListItem>();

        public readonly IWebHostEnvironment _webHostEnvironment;

        public PostAddModel(IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
        }

        public async Task<IActionResult> OnGetAsync()
        {
            var user = HttpContext.Session.GetString("UserName".ToString());
            var ID = HttpContext.Session.GetString("ID".ToString());
            Username = user;
            if (string.IsNullOrEmpty(user) || ID == "0")
            {
                return RedirectToPage("/Common/Dashboard");
            }

            UserRepo userRepo = new UserRepo();
            var cities = await userRepo.GetCities();
            foreach(var city in cities)
            {
                Cities.Add(new SelectListItem { Value = city, Text = city });
            }
            AutoStart = DateTime.Now;
            return default;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            try
            {
                UserRepo userRepo = new UserRepo();
                var cities = await userRepo.GetCities();
                foreach (var city in cities)
                {
                    Cities.Add(new SelectListItem { Value = city, Text = city });
                }
                var UID = HttpContext.Session.GetString("ID");
                var Name = HttpContext.Session.GetString("UserName");
                if (string.IsNullOrEmpty(UID))
                {
                    return RedirectToPage("/Common/Dashboard");
                }
                if(AddData.Title.Length > 30)
                {
                    ModelState.AddModelError("titlelong", "Title Is Too Much Lenghty. Use Short Title");
                    return Page();
                }
                if(AddData.startingbid < 1500)
                {
                    ModelState.AddModelError("price", "Price Less Then 1500 Is Not Allowed");
                    return Page();
                }
                if (image1 == null )
                {
                    ModelState.AddModelError("No Image", "Atleast One Image Is Required");
                    return Page();
                }
                if (image1== null && image2 == null &&  image3 == null && image4 == null)
                {
                    ModelState.AddModelError("No Image", "Atleast One Image Is Required");
                    return Page();
                }
                var imgstring = "";
                var Image1 = "";
                var Image2 = "";
                var Image3 = "";
                var Image4 = "";

                var ANYADD = await userRepo.UserAnyAddAvail(UID);
                if (ANYADD)
                {
                    ModelState.AddModelError("AddPostFail", "You Only Allowed One Add.Complete Your posted add and delete it to post new add.");
                    return Page();
                }
                else
                {
                    AddData.userid = Convert.ToInt32(UID);

                    if (image1 != null)
                    {
                        Image1 = UID + "@" + image1.FileName.ToString();
                        imgstring = Image1;
                    }
                    if (image2 != null)
                    {
                        Image2 = UID + "@" + image2.FileName.ToString();
                        imgstring = imgstring + "///" + Image2;
                        
                    }
                    if (image3 != null)
                    {
                        Image3 = UID + "@" + image3.FileName.ToString();
                        imgstring = imgstring + "///" + Image3;
                        
                    }
                    if (image4 != null)
                    {
                        Image4 = UID + "@" + image4.FileName.ToString();
                        imgstring = imgstring + "///" + Image4;
                        
                    }
                    AddData.Imagestring = imgstring;
                    AddData.Bidstart = "false";
                    AddData.status = "NotCompleted";
                    AddData.username = Name;
                    AddData.visible = "true";
                    AddData.Deleted = "false";
                    if (AutoStartbool)
                    {
                        var cdate = DateTime.Now;
                        if(AutoStart < cdate)
                        {
                            ModelState.AddModelError("date error", "You can only select Future Auto start time");
                            return Page();
                        }
                        AddData.AutoStart = AutoStart.ToString();
                        AddData.AutoStop = AutoStart.AddDays(2).ToString();
                    }
                    AddData.PlaceDate = DateTime.Now.ToString();
                    AddData.Grace = 0;
                    var saved = await userRepo.SaveAdd(AddData);
                    if (!saved)
                    {
                        ModelState.AddModelError("AddPostFail", "Add Not Saved Yet.Please Retry");
                        return Page();
                    }
                    else
                    {

                        if (image1 !=null)
                        {
                            var fileupload1 = Path.Combine(_webHostEnvironment.WebRootPath, "images", Image1);
                            using (var FS = new FileStream(fileupload1, FileMode.Create))
                            {
                                await image1.CopyToAsync(FS);
                            }

                        }
                        if (image2 != null)
                        {
                            var fileupload2 = Path.Combine(_webHostEnvironment.WebRootPath, "images", Image2);
                            using (var FS = new FileStream(fileupload2, FileMode.Create))
                            {
                                await image2.CopyToAsync(FS);
                            }
                        }

                        if (image3 != null)
                        {
                            var fileupload3 = Path.Combine(_webHostEnvironment.WebRootPath, "images", Image3);
                            using (var FS = new FileStream(fileupload3, FileMode.Create))
                            {
                                await image3.CopyToAsync(FS);
                            }
                        }

                        if (image4 != null)
                        {
                            var fileupload4 = Path.Combine(_webHostEnvironment.WebRootPath, "images", Image4);
                            using (var FS = new FileStream(fileupload4, FileMode.Create))
                            {
                                await image4.CopyToAsync(FS);
                            }
                        }
                        return RedirectToPage("/Common/Dashboard");
                    }

                    return Page();
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("AddPostFail", e.Message);
                return Page();
            }
        }

    }
}
