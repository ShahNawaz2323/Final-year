﻿using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public User user { get; set; } = new User();

        UserRepo userRepo = new UserRepo(); 

        [BindProperty]
        public int UtcOffset { get; set; }

        public async Task<IActionResult> OnGet(bool created)
        {
            
            if (created)
            {
                ModelState.AddModelError("newcreated", "Account Created.Wait for Manager to Verify Your Data.");
                HttpContext.Session.Clear();
                return Page();
            }
            var TypeExist = HttpContext.Session.GetString("UserType");
            if (!string.IsNullOrEmpty(TypeExist))
                {
                    if (TypeExist == "0")
                    {
                        return RedirectToPage("/Common/Dashboard");
                    }
                    else if (TypeExist == "1")
                    {
                        return RedirectToPage("/Admin/Home");
                    }
                    else if (TypeExist == "2")
                    {
                        return RedirectToPage("/Manager/Home");
                    }
                }
            
            return default;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            try
            {
                user.UserName = user.UserName.ToUpper();
                user = await userRepo.GetByNameAndPasswordAsync(user);
                if (user == null)
                {
                    ModelState.AddModelError("NullUser","Incorrect Password / UserName");
                    return Page();
                }
                if (user.Blocked == "true")
                {
                    ModelState.AddModelError("UserBlocked", "You Are Blocked by The Admin");
                    return Page();
                }
                if (user.AdminVerified == "false")
                {
                    ModelState.AddModelError("UnVerified", "Your Account Is Under Verification. Please Wait!");
                    return Page();
                }
            }
            catch(Exception e)
            {
                return Page();
            }
            HttpContext.Session.SetString("UserName", user.UserName.ToString());
            HttpContext.Session.SetString("ID", user.ID);
            HttpContext.Session.SetString("UserType", user.userType.ToString());
            return RedirectToPage(user.getHomePageMenuItem().Uri);
        }
    }
}
