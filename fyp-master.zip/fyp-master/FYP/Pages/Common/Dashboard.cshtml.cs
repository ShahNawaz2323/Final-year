using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FYP.Pages.Common
{
    public class DashboardModel : PageModel
    {
        public IEnumerable<Postadd> AllAdds { get; set; }

        public List<SelectListItem> Cities = new List<SelectListItem>();

        public string CurrentLocation { get; set; }

        [BindProperty]
        public bool LocationFound { get; set; }

        [BindProperty]
        public string NewLocation { get; set; }

        public async Task<IActionResult> OnGetAsync(string Cat)
        {
            if (!string.IsNullOrEmpty(Cat))
            {
                HttpContext.Session.SetString("CAT", Cat);
            }
            else
            {
                HttpContext.Session.SetString("CAT", "");
            }
            UserRepo userRepo = new UserRepo();
            var user = HttpContext.Session.GetString("UserName".ToString());
            var ID = HttpContext.Session.GetString("ID".ToString());
            var UT = HttpContext.Session.GetString("UserType".ToString());
            if (string.IsNullOrEmpty(user) || UT != "0")
            {
                return RedirectToPage("/Common/Login");
            }

            var locat = HttpContext.Session.GetString("Location".ToString());
            CurrentLocation = locat;
            if (string.IsNullOrEmpty(locat))
            {
                LocationFound = false;
                var cities = await userRepo.GetCities();
                foreach (var city in cities)
                {
                    Cities.Add(new SelectListItem { Value = city, Text = city });
                }
            }
            else
            {
                LocationFound = true;
                if (string.IsNullOrEmpty(Cat))
                {

                    var Adds = await userRepo.GetAdds("" , locat);
                    AllAdds = Adds;
                }
                else
                {
                    var Adds = await userRepo.GetAdds(Cat , locat);
                    AllAdds = Adds;
                }

                if (AllAdds != null)
                {
                    foreach (var single in AllAdds)
                    {
                        List<string> Imagenames = new List<string>();
                        string[] names = single.Imagestring.Split("///");
                        foreach (var img in names)
                        {
                            Imagenames.Add(img);
                        }
                        single.ImgNameInFolder = Imagenames;
                    }
                }
            }
            return default;
        }

        public async Task OnGetChangeLocation()
        {
            HttpContext.Session.SetString("Location", "");
        }

        public async Task<IActionResult> OnPostAsync(string Cat)
        {
            HttpContext.Session.SetString("Location", NewLocation);
            var loc = HttpContext.Session.GetString("CAT".ToString());
            if (string.IsNullOrEmpty(loc))
            {
                return RedirectToPage("/Common/Dashboard");
            }
            else
            {
                Response.Redirect("/Common/Dashboard?Cat=" + loc);
            }

            return default;
            
        }
    }
}
