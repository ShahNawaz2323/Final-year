using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class ContactModel : PageModel
    {
        public UserRepo userRepo = new UserRepo();
        public User user { get; set; }

        [BindProperty]
        public MessForAdmin Message { get; set; }

        public async Task<IActionResult> OnGetAsync(string mess)
        {
            var UName = HttpContext.Session.GetString("UserName".ToString());
            var ID = HttpContext.Session.GetString("ID".ToString());
            var Type = HttpContext.Session.GetString("UserType".ToString());

            if (string.IsNullOrEmpty(ID) || string.IsNullOrEmpty(Type))
            {
                return RedirectToPage("/Common/Login");
            }
            else
            {
                user = await userRepo.GetByIdAsync(Convert.ToInt32(ID));
                if (!string.IsNullOrEmpty(mess))
                {
                    ModelState.AddModelError("NullUser", "Message Sended To Team.");
                    return Page();
                }
            }
            return Page();
        }
        public async Task<IActionResult> OnPostAsync()
        {
            var ID = HttpContext.Session.GetString("ID".ToString());
            if (!string.IsNullOrEmpty(ID))
            {
                if(!string.IsNullOrEmpty(Message.Value) && !string.IsNullOrEmpty(Message.Text))
                {
                    Message.Sender = Convert.ToInt32(ID);
                    Message.Seen = "false";
                    await userRepo.AddNewMessAdmin(Message);
                    Response.Redirect("/Common/Contact?mess='Message'");
                }
            }
            return new JsonResult("");

        }
    }
}
