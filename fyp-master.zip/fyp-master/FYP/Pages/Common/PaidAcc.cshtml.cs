using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class PaidAccModel : PageModel
    {
        public bool AlreadyPaid { get; set; }

        [BindProperty]
        public string Name { get; set; }

        [BindProperty]
        public string? TRXID { get; set; }

        
        public bool Applied { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var id = HttpContext.Session.GetString("ID");
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                return RedirectToPage("/Common/Login");
            }
            UserRepo userRepo = new UserRepo();
            var user =await userRepo.GetByIdAsync(Convert.ToInt32(id));
            var paid = await userRepo.GetPaidRequests(id);
            Name = user.UserName;
            if(paid != null)
            {
                Applied = true;
            }
            if (user.Paid == "true")
            {
                AlreadyPaid = true;
            }
            else
            {
                AlreadyPaid = false;
            }
            TRXID = null;

            return default;
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var id = HttpContext.Session.GetString("ID");
            if (!string.IsNullOrEmpty(id))
            {
                UserRepo userRepo = new UserRepo();
                GetPaid getPaid = new GetPaid();
                getPaid.UserID = id;
                getPaid.UserName = Name;
                getPaid.TRX = TRXID;
                getPaid.Seen = "false";
               var saved =  await userRepo.SavePaidReq(getPaid);
                if (!saved)
                {
                    ModelState.AddModelError("No saved", "TRX Id Is Already Used.");
                    return Page();
                }
                else
                {
                    return RedirectToPage("/Common/PaidAcc");
                }
            }
            return Page();
        }
    }
}
