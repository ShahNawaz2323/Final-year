using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class ProfileModel : PageModel
    {
        [BindProperty]
        public User user { get; set; }

        [BindProperty]
        public IFormFile Profilepic { get; set; }

        public readonly IWebHostEnvironment _webHostEnvironment;

        public ProfileModel(IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
        }



        public async Task<IActionResult> OnGetAsync()
        {
            var id = HttpContext.Session.GetString("ID");
            if (string.IsNullOrEmpty(id) || id == "0")
            {
                return RedirectToPage("/Common/Login");
            }
            UserRepo userRepo = new UserRepo();
            user = await   userRepo.GetByIdAsync(Convert.ToInt32(id));

            return default;
        }
        public async Task<IActionResult> OnPostAsync()
         {
            user.ID = HttpContext.Session.GetString("ID");

            var Image1 = "";
            if (Profilepic != null)
            {
                var UID = HttpContext.Session.GetString("ID");
                Image1 = UID + "@" + Profilepic.FileName.ToString();
                if (Profilepic != null)
                {
                    var fileupload1 = Path.Combine(_webHostEnvironment.WebRootPath, "Profile", Image1);
                    using (var FS = new FileStream(fileupload1, FileMode.Create))
                    {
                        await Profilepic.CopyToAsync(FS);
                    }

                }
                user.profilepic = Image1;
            }
            UserRepo userRepo = new UserRepo();
            await userRepo.UpdateUserData(user);
            return Page();
        }
    }
}
