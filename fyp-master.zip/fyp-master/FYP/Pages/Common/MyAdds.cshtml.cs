using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class MyAddsModel : PageModel
    {

        public List<Postadd> Adds { get; set; }

        public bool bidsavaila { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            var userid = HttpContext.Session.GetString("ID".ToString());
            if (string.IsNullOrEmpty(userid) || userid == "0")
            {  
                return RedirectToPage("/Common/Login");
            }
            else
            {
                UserRepo userRepo = new UserRepo();
               var Addss = await userRepo.AllAddsById(userid);
                if(Addss.Count() > 0  && Addss != null)
                {
                    var already = await userRepo.Getcurrentbids(Addss.FirstOrDefault().id, true);
                    if (already.Count() > 0 && already != null && Addss.FirstOrDefault().status == "NotCompleted")
                    {
                        bidsavaila = true;
                    }
                }
                Adds = Addss.ToList();

                return Page();
            }
        }
        public async Task<IActionResult> OnGetSaveedited(int addid, string TTL , string AMT ,string DESC)
        {
            var userid = HttpContext.Session.GetString("ID".ToString());
            Postadd postadd = new Postadd();
            UserRepo userRepo = new UserRepo();
            postadd.id = addid;
            postadd.Title = TTL;
            postadd.startingbid = Convert.ToInt32(AMT);
            postadd.Description = DESC;
            postadd.userid = Convert.ToInt32(userid);

           var saved = await userRepo.SaveEdited(postadd);
            if (saved)
            {
                return new JsonResult("success");
            }
            else
            {
                return new JsonResult("error");
            }
        }

        public async Task<IActionResult> OnGetStartstop(int addid , string value)
        {
            UserRepo userRepo = new UserRepo();
            var userid = HttpContext.Session.GetString("ID".ToString());
            var Add = await userRepo.AddById(addid);
            if (string.IsNullOrEmpty(Add.AutoStop))
            {
                var Stop = DateTime.Now.AddDays(2).ToString();
                await userRepo.UpdateAutoStop(userid, addid, Stop);
            }
            else
            {
                var Stop = DateTime.Now.AddDays(2).ToString();
                await userRepo.UpdateAutoStop(userid, addid, Stop);
            }
            var adid = addid;
            var Value = value;
           var saved = await userRepo.StartStopBiding(userid, adid, Value);
            if (saved)
            {
                return new JsonResult("success");
            }
            else
            {
                return new JsonResult("error");
            }
            
        }

        public async Task<IActionResult> OnGetFinishbiding(int addid)
        {
            UserRepo userRepo = new UserRepo();
            var userid = HttpContext.Session.GetString("ID".ToString());
            var adid = addid;
            var saved = await userRepo.FinishBidingstatus(userid, adid, "Completed");
            await OnGetStartstop(addid, "false");
            if (saved)
            {
                return new JsonResult("success");
            }
            else
            {
                return new JsonResult("error");
            }
           
        }

        public async Task<IActionResult> OnGetDELETEADD(int ADDID)
        {
            UserRepo userRepo = new UserRepo();
            var userid = HttpContext.Session.GetString("ID".ToString());
            var adid = ADDID;
            var saved = await userRepo.DELETEADD(userid, adid);
            if (saved)
            {
                return new JsonResult("success");
            }
            else
            {
                return new JsonResult("error");
            }
        }
    }
}
