using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Common
{
    public class BidsDetailModel : PageModel
    {
        public IEnumerable<Biding> bidings { get; set; }
        public Postadd postadd { get; set; }

        public TrackingDetail Tracking { get; set; }
        public bool TrackingAvailable { get; set; }

        public WonBids AvailWonBid { get; set; }
        public bool offersended { get; set; }
        public bool RateAllowed { get; set; }
        public string AlreadyCommented { get; set; }

        public string contact { get; set; }

        public string sendedofferaccepted { get; set; }
        public async Task<IActionResult> OnGetAsync(int ID)
        {
            UserRepo userRepo = new UserRepo();
            var Add = await userRepo.AddById(ID);
            postadd = Add;
            var CUID = HttpContext.Session.GetString("ID".ToString());
            if (string.IsNullOrEmpty(CUID) || CUID == "0")
            {
                return RedirectToPage("/Common/Login");
            }
            if (Add.userid.ToString() != CUID)
            {
                return RedirectToPage("/Common/Dashboard");
            }
            var Osended =  await userRepo.CheckAnyavailwonbid(ID);
            if(Osended != null)
            {
                offersended = true;
                AvailWonBid = Osended;
                if (Osended.OfferAccepted == "true")
                {
                    sendedofferaccepted = "Accepted";
                   var data =  await userRepo.GetByIdAsync(Osended.BiderId);
                    contact = data.Mobile;
                }
                else if (Osended.OfferAccepted == "false" && Osended.MessSeen == "true")
                {
                    sendedofferaccepted = "Rejected";
                }
                else
                {
                    sendedofferaccepted = "";
                }
            }
            else
            {
                offersended = false;
            }
            

            bidings = await userRepo.Getcurrentbids(ID, false);
            if(AvailWonBid != null)
            {
                var alreadyRates = await userRepo.GetCommentOfAdd(ID, AvailWonBid.BiderId.ToString());
                if (alreadyRates != null)
                {
                    RateAllowed = false;
                    AlreadyCommented = alreadyRates.Comment;
                }
                else
                {
                    RateAllowed = true;
                }

                var tracking = await userRepo.GetTrackingDetail(ID, AvailWonBid.BiderId.ToString());
                if(tracking != null)
                {
                    TrackingAvailable = true;
                    Tracking = tracking;
                }
            }
            return default;
        }

        public async Task<IActionResult> OnGetSendOffer(int Addid, string ownerid, int latestbid, int biderid)
        {
            UserRepo userRepo = new UserRepo();
            var CUID = HttpContext.Session.GetString("ID".ToString());
            if(ownerid != CUID)
            {
                return new JsonResult("You Are Not Owner Of this Add");
            }
            else
            {
                var Alreadyavail =await userRepo.AlreadyAvailoffer(Addid, biderid);
                if(Alreadyavail != null)
                {
                    await userRepo.Deleteavailwons(Addid, ownerid, biderid);
                }


                var Username = HttpContext.Session.GetString("UserName".ToString());
                var Add = await userRepo.AddById(Addid);
                if(Add == null)
                {
                    return RedirectToPage("/Common/Dashboard");
                }
                var bider = await userRepo.GetByIdAsync(biderid);
                WonBids wonBids = new WonBids();
                var Livebid =await userRepo.GetBidfromdb(Addid, ownerid, latestbid, biderid);
                if(Livebid == null)
                {
                    return new JsonResult("No Bid Found Related to this Add");
                }
                else
                {
                    wonBids.Addid = Addid;
                    wonBids.AddOwnerId =Convert.ToInt32(ownerid);
                    wonBids.AddOwnerName = Username;
                    wonBids.BiderId = biderid;
                    wonBids.BiderName = bider.UserName;
                    wonBids.BiderWonAmount = latestbid;
                    wonBids.DefaultAmount = Add.startingbid;
                    wonBids.MessSeen = "false";
                    wonBids.OfferAccepted = "false";
                    wonBids.Title = Add.Title;
                    var saved = await userRepo.SaveToWonBids(wonBids);
                    if (saved)
                    {
                        return new JsonResult("success");
                    }
                    else
                    {
                        return new JsonResult("error");
                    }
                }
            }
        }

        public async Task<IActionResult> OnGetDeleteoffer(int Addid)
        {
            UserRepo userRepo = new UserRepo();
            await userRepo.Deleteavailwons(Addid, "0", 0);
            return new JsonResult("");
        }

        public async Task<IActionResult> OnGetRateing(int UID , int star , string Comment , int Addid)
        {
            UserRepo userRepo = new UserRepo();
            var oldrate = await userRepo.GetUserRateing(UID);
            var Commenter = HttpContext.Session.GetString("ID".ToString());
            Comments comment = new Comments();
            if (oldrate == null)
            {
                Rateing rateing = new Rateing();
                rateing.UserId = UID.ToString();
                if(star == 5)
                {
                    rateing.Five = 1;
                }
                if (star == 4)
                {
                    rateing.Four = 1;
                }
                if (star == 3)
                {
                    rateing.Three = 1;
                }
                if (star == 2)
                {
                    rateing.Two = 1;
                }
                if (star == 1 || star == 0)
                {
                    rateing.One = 1;
                }
                comment.UserId = UID.ToString();
                comment.AddId = Addid;
                if (string.IsNullOrEmpty(Comment))
                {
                    comment.Comment = "No Comment";
                }
                else
                {
                    comment.Comment = Comment;
                }
                comment.CommenterId = Commenter;
                await userRepo.AddComment(comment);
                await userRepo.AddNewRateing(rateing);
            }
            else
            {
                if (star == 5)
                {
                    oldrate.Five = oldrate.Five+1;
                }
                if (star == 4)
                {
                    oldrate.Four = oldrate.Four+ 1;
                }
                if (star == 3)
                {
                    oldrate.Three = oldrate.Three + 1;
                }
                if (star == 2)
                {
                    oldrate.Two = oldrate.Two+1;
                }
                if (star == 1 || star == 0)
                {
                    oldrate.One = oldrate.One + 1;
                }
                comment.UserId = UID.ToString();
                comment.AddId = Addid;
                if (string.IsNullOrEmpty(Comment))
                {
                    comment.Comment = "No Comment";
                }
                else
                {
                    comment.Comment = Comment;
                }
                comment.CommenterId = Commenter;
                await userRepo.AddComment(comment);
                await userRepo.UpdateUserRateing(oldrate);
            }

            return new JsonResult("");
        
        }

        public async Task<IActionResult> OnGetTrackingCode(string buyerid , int addid , string trackingcode)
        {
            TrackingDetail trackingDetail = new TrackingDetail();
            trackingDetail.Buyer = buyerid;
            trackingDetail.Addid = addid;
            trackingDetail.Tracking = trackingcode;
            UserRepo userRepo = new UserRepo();
            await userRepo.AddTrackingCode(trackingDetail);

            return new JsonResult("");
        }

    }
}
