using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Admin
{
    public class OrgReportModel : PageModel
    {
        UserRepo userRepo = new UserRepo();
       public  OrgReport Data = new OrgReport();
        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                var UT = HttpContext.Session.GetString("UserType");
                if (UT != "1" || string.IsNullOrEmpty(UT))
                {
                    return RedirectToPage("/Common/Login");
                }
                OrgReport orgReport = new OrgReport();

                var Users = await userRepo.OrgUsers();
                var WonBids = await userRepo.OrgWonbids();
                var Auctions = await userRepo.OrgAllAuction();
                var Bids = await userRepo.OrgAllBids();
                try
                {
                    orgReport.Auctions = Auctions;
                    orgReport.Bids = Bids;
                    orgReport.UnSuccess = WonBids.Where(x => x.OfferAccepted == "false").Count().ToString();
                    orgReport.Success = WonBids.Where(x => x.OfferAccepted == "true").Count().ToString();
                    orgReport.PaidUsers = Users.Where(x => x.Paid == "true").Count().ToString();
                    orgReport.UnpaidUsers = Users.Where(x => x.Paid == "false").Count().ToString();
                    orgReport.blocked = Users.Where(x => x.Blocked == "true").Count().ToString();
                }
                catch (Exception e)
                {

                }

                Data = orgReport;
            }
            catch (Exception e)
            {

            }
            return default;

        }
    }
}
