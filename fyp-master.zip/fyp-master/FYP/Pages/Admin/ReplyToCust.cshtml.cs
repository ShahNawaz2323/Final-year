using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Admin
{
    public class ReplyToCustModel : PageModel
    {
        UserRepo userrepo = new UserRepo();

        [BindProperty]
        public MessForAdmin query { get; set; }

        [BindProperty]
        public string Reply { get; set; }


        public async Task<IActionResult> OnGetAsync(int ID)
        {
            var UT = HttpContext.Session.GetString("UserType");
            if (UT != "1")
            {
                return RedirectToPage("/Admin/Home");
            }
            query =  await userrepo.Querywithid(ID);
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            MessForUser ToReply = new MessForUser();
            ToReply.Received = query.Text;
            ToReply.Text = Reply;
            ToReply.UserID = query.Sender;
            ToReply.Value = query.Value;
            ToReply.Seen = "false";

            var sended = await userrepo.Updateseenandreply(ToReply , query.ID);
            if (sended)
            {
                return RedirectToPage("/Admin/AdminQuries");
            }
            return default;
        }





    }
}
