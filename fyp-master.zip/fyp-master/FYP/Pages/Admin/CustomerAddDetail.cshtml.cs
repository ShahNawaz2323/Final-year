using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Admin
{
    public class CustomerAddDetailModel : PageModel
    {
        [BindProperty]
        public Postadd AddData { get; set; }
        public bool CanStart { get; set; }

        public string Status { get; set; }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            try
            {
                var user = HttpContext.Session.GetString("UserName".ToString());
                var ID = HttpContext.Session.GetString("ID".ToString());
                var UT = HttpContext.Session.GetString("UserType");
                if (string.IsNullOrEmpty(UT) || UT != "1")
                {
                    return RedirectToPage("/Admin/Home");
                }
                else
                {
                    var MyID = HttpContext.Session.GetString("ID".ToString());
                    if (UT == "1")
                    {
                        UserRepo userRepo = new UserRepo();
                        var Add = await userRepo.AddById(id);
                        var CB = await userRepo.Getcurrentbids(id, true);
                        AddData = Add;
                        if (AddData.userid.ToString() == MyID)
                        {
                            CanStart = true;
                        }
                        if (AddData != null)
                        {
                            List<string> Imagenames = new List<string>();
                            string[] names = AddData.Imagestring.Split("///");
                            foreach (var img in names)
                            {
                                Imagenames.Add(img);
                            }
                            AddData.ImgNameInFolder = Imagenames;

                        }

                        if (Add.Bidstart == "false" && CB.Count() > 0)
                        {
                            Status = "Biding Finished ";
                        }
                        else if (Add.Bidstart == "false" && CB.Count() == 0 || CB == null)
                        {
                            Status = "Biding Not Started Yet";
                        }
                        else if (Add.Bidstart == "true")
                        {
                            Status = "Biding Started";
                        }
                    }
                    
                }

                

            }
            catch (Exception e)
            {

            }
            return Page();
        }

        public async Task<IActionResult> OnGetStatus(int ADDID)
        {
            UserRepo userRepo = new UserRepo();
            var Add = await userRepo.AddById(ADDID);
            var CB = await userRepo.Getcurrentbids(ADDID, true);
            var status = "";
            if (Add.Bidstart == "false" && CB.Count() > 0)
            {
                status = "Biding Finished";
            }
            else if (Add.Bidstart == "false" && Add.status == "Completed" && CB.Count() == 0 || CB == null)
            {
                status = "Biding Finished With No Bids";
            }
            else if (Add.Bidstart == "false" && CB.Count() == 0 || CB == null)
            {
                status = "Biding Not Started Yet";
            }
            else if (Add.Bidstart == "true")
            {
                status = "Biding Started";
            }

            return new JsonResult(status);
        }

        public async Task<IActionResult> OnGetAutostartstop(int ADDID)
        {
            UserRepo userRepo = new UserRepo();
            var Add = await userRepo.AddById(ADDID);
            if (!string.IsNullOrEmpty(Add.AutoStart))
            {
                var alreadybids = await userRepo.Getcurrentbids(Add.id, true);
                if (alreadybids != null && alreadybids.Count() == 0)
                {
                    var addtime = Convert.ToDateTime(Add.AutoStart);
                    if (addtime <= DateTime.Now)
                    {
                        await userRepo.StartStopBiding(Add.userid.ToString(), Add.id, "true");
                    }
                }

            }
            if (!string.IsNullOrEmpty(Add.AutoStart))
            {
                var alreadybids = await userRepo.Getcurrentbids(Add.id, true);
                if (alreadybids != null && alreadybids.Count() > 0)
                {
                    var addtime = Convert.ToDateTime(Add.AutoStart);
                    var endtime = addtime.AddDays(2);
                    var current = DateTime.Now;
                    if (current >= endtime)
                    {
                        await userRepo.StartStopBiding(Add.userid.ToString(), Add.id, "false");
                        await userRepo.FinishBidingstatus(Add.userid.ToString(), Add.id, "Completed");
                    }
                }

            }
            return new JsonResult("");
        }

        public async Task<IActionResult> OnGetShowbids(int ADDID)
        {
            List<Biding> bids = new List<Biding>();
            UserRepo userRepo = new UserRepo();
            var Add = await userRepo.AddById(ADDID);
            var MyID = HttpContext.Session.GetString("ID".ToString());
            if (Add != null)
            {
                if (Add.userid != Convert.ToInt32(MyID))
                {
                    if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype != "Private")
                    {
                        var CB = await userRepo.Getcurrentbids(ADDID, true);
                        return Partial("../PartialViews/_CurrentBids", CB);
                    }
                    else if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "Private")
                    {
                        var CB = await userRepo.GetcurrentbidsWithUserId(ADDID, MyID);
                        return Partial("../PartialViews/_CurrentBids", CB);
                    }
                    else if (Add.Bidstart == "true" && Add.status == "Completed" && Add.bidtype != "Private")
                    {
                        var CB = await userRepo.GetcurrentbidsWithUserId(ADDID, MyID);
                        return Partial("../PartialViews/_CurrentBids", CB);
                    }
                }
                else
                {
                    var CB = await userRepo.Getcurrentbids(ADDID, true);
                    return Partial("../PartialViews/_CurrentBids", CB);
                }

            }

            return Partial("../PartialViews/_CurrentBids", null);
        }

        //public async Task<IActionResult> OnGetAddorminusamount(int UID, int ADDID)
        //{
        //    var MyID = HttpContext.Session.GetString("ID".ToString());
        //    BidingAmounts bidAMT = new BidingAmounts();
        //    UserRepo userRepo = new UserRepo();
        //    var user = await userRepo.GetByIdAsync(Convert.ToInt32(MyID));
        //    if (user.Paid == "true")
        //    {
        //        bidAMT.ADDOID = UID.ToString();
        //        bidAMT.ADDID = ADDID.ToString();
        //        bidAMT.CUID = MyID;

        //        var Add = await userRepo.AddById(ADDID);
        //        if (Add.userid != Convert.ToInt32(MyID))
        //        {
        //            if (Add != null)
        //            {
        //                if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "English")
        //                {
        //                    bidAMT.BidType = "English";
        //                    return Partial("../PartialViews/_Amounts", bidAMT);
        //                }
        //                else if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "Reverse")
        //                {
        //                    bidAMT.BidType = "Reverse";
        //                    return Partial("../PartialViews/_Amounts", bidAMT);
        //                }
        //                else if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "SecondBest")
        //                {
        //                    bidAMT.BidType = "SecondBest";
        //                    return Partial("../PartialViews/_Amounts", bidAMT);
        //                }
        //                else if (Add.Bidstart == "true" && Add.status == "NotCompleted" && Add.bidtype == "Private")
        //                {
        //                    bidAMT.BidType = "Private";
        //                    return Partial("../PartialViews/_Amounts", bidAMT);
        //                }
        //            }
        //        }
        //    }
        //    return new JsonResult("");
        //}


        //public async Task<IActionResult> OnGetSendbid(int AMOUNT, int CUID, int ADDOID, int ADDID)
        //{
        //    UserRepo userRepo = new UserRepo();
        //    Biding biding = new Biding();
        //    int reverseBid = 0;
        //    biding.Addid = ADDID;
        //    biding.biderid = CUID;
        //    biding.biderName = HttpContext.Session.GetString("UserName".ToString());


        //    var AlreadyWD = await userRepo.GetWDOfUser(CUID);
        //    var AlreadyThis = await userRepo.IfAlreadyWDThisAuction(ADDID, CUID);
        //    var AddData = await userRepo.AddById(ADDID);
        //    var CB = await userRepo.Getcurrentbids(ADDID, true);


        //    //checked if user already withdraw in this auction
        //    if (AlreadyThis.Any() && AlreadyThis != null)
        //    {
        //        return new JsonResult("You Are Not Allowed To Bid AnyMore In This Auction");
        //    }

        //    //checked that user already withdrawn 3 auctions or not
        //    if (AlreadyWD != null)
        //    {
        //        if (!AlreadyWD.Text.Contains("1") || !AlreadyWD.Text.Contains("2"))
        //        {
        //            return new JsonResult("Biding Permanently Blocked. Contact Admin");
        //        }
        //    }

        //    //this is the actual with drawn function
        //    if (AMOUNT == 00000)
        //    {

        //        var Alreadybid = await userRepo.Alreadybidthisuser(ADDID, CUID);
        //        if (Alreadybid == null || Alreadybid.Count() == 0)
        //        {
        //            return new JsonResult("No Bids Found To Withdraw");
        //        }
        //        if (AlreadyWD == null)
        //        {
        //            MessForAdmin messForAdmin = new MessForAdmin();
        //            messForAdmin.Sender = CUID;
        //            messForAdmin.Text = biding.biderName + " WithDraw 1 Time";
        //            messForAdmin.Value = "WD";
        //            var saved = await userRepo.AddNewMessAdmin(messForAdmin);
        //            if (saved)
        //            {
        //                await userRepo.UpdateBidsStatus(biding);
        //                return new JsonResult("Your Auction WithDrawn");
        //            }
        //        }
        //        else
        //        {
        //            if (AlreadyWD.Text.Contains("1"))
        //            {
        //                AlreadyWD.Text = biding.biderName + " WithDraw 2 Time";
        //                var saved = await userRepo.UpdateMessAdmin(AlreadyWD);
        //                if (saved)
        //                {
        //                    await userRepo.UpdateBidsStatus(biding);
        //                    return new JsonResult("Your Auction WithDrawn");
        //                }
        //            }
        //            else if (AlreadyWD.Text.Contains("2"))
        //            {
        //                AlreadyWD.Text = biding.biderName + " WithDraw 3 Time";
        //                var saved = await userRepo.UpdateMessAdmin(AlreadyWD);
        //                if (saved)
        //                {
        //                    await userRepo.UpdateBidsStatus(biding);
        //                    return new JsonResult("Your Auction WithDrawn");
        //                }
        //            }
        //            //else
        //            //{
        //            //    return new JsonResult("Biding Permanently Blocked. Contact Admin");
        //            //}
        //        }
        //    }



        //    if (AddData.bidtype == "Reverse")
        //    {
        //        var Firstvalue = (AddData.startingbid * 20) / 100;
        //        var final = AddData.startingbid - Firstvalue;
        //        reverseBid = final;
        //        if (CB != null && CB.Count() > 0)
        //        {
        //            var CAMT = CB.FirstOrDefault().currentAmt;
        //            var ToBid = CAMT + AMOUNT;
        //            if (ToBid < reverseBid)
        //            {
        //                return new JsonResult("Price Less Then 20% Is Not Allowed");
        //            }
        //            else
        //            {
        //                biding.currentAmt = ToBid;
        //            }
        //        }
        //        else
        //        {
        //            var ToBid = AddData.startingbid + AMOUNT;

        //            if (ToBid < reverseBid)
        //            {
        //                return new JsonResult("Price Less Then 20% Is Not Allowed");
        //            }
        //            else
        //            {
        //                biding.currentAmt = ToBid;
        //            }
        //            //biding.currentAmt = AddData.startingbid + AMOUNT;
        //        }
        //        //Reverse Biding Amount Set End Here

        //    }
        //    else if (AddData.bidtype == "SecondBest")
        //    {
        //        if (CB == null || CB.Count() == 0)
        //        {
        //            biding.currentAmt = AddData.startingbid + AMOUNT;
        //        }
        //        else
        //        {
        //            if (CB.Count() <= 1)
        //            {
        //                var CAMT = CB.FirstOrDefault().currentAmt;
        //                biding.currentAmt = CAMT + AMOUNT;
        //                biding.startingbid = AddData.startingbid;
        //                biding.userid = ADDOID;
        //                await userRepo.SaveBidsToDB(biding);
        //                await userRepo.SecondbestFinish(ADDID, ADDOID);
        //                return new JsonResult("");
        //            }
        //            else if (CB.Count() >= 2)
        //            {
        //                await userRepo.SecondbestFinish(ADDID, ADDOID);
        //                return new JsonResult("");
        //            }
        //        }
        //    }
        //    else if (AddData.bidtype == "Private")
        //    {
        //        var myId = HttpContext.Session.GetString("ID".ToString());
        //        CB = await userRepo.GetMycurrentbids(ADDID, myId);
        //        if (CB != null && CB.Count() > 0)
        //        {
        //            var CAMT = CB.FirstOrDefault().currentAmt;
        //            biding.currentAmt = CAMT + AMOUNT;
        //        }
        //        else
        //        {
        //            biding.currentAmt = AddData.startingbid + AMOUNT;
        //        }
        //    }
        //    else
        //    {
        //        if (CB != null && CB.Count() > 0)
        //        {
        //            var CAMT = CB.FirstOrDefault().currentAmt;
        //            biding.currentAmt = CAMT + AMOUNT;
        //        }
        //        else
        //        {
        //            biding.currentAmt = AddData.startingbid + AMOUNT;
        //        }
        //    }
        //    biding.startingbid = AddData.startingbid;
        //    biding.userid = ADDOID;
        //    biding.PlaceDate = DateTime.Now.ToLocalTime().ToString();
        //    biding.Status = "Show";
        //    await userRepo.SaveBidsToDB(biding);
        //    return new JsonResult("");

        //}


    }
}
