using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Admin
{
    public class BlockedAuctionerModel : PageModel
    {
        UserRepo userRepo = new UserRepo();
        public IEnumerable<BidingBlocked> bidingBlockeds { get; set; }
        public async Task<IActionResult> OnGetAsync()
        {
            bidingBlockeds = await userRepo.AllBlockedAuctioners();
            return Page();
        }

        public async Task<IActionResult> OnGetUnBlock(int UID , int ID)
        {
            await userRepo.UnblockBlockedAuctioners(UID, ID);
            return new JsonResult("");
        }

    }
}
