using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Admin
{
    public class HomeModel : PageModel
    {
        UserRepo userRepo = new UserRepo();

        public int NewAccount { get; set; }
        public int VerifyAccount { get; set; }
        public int DeleteUpdate { get; set; }
        public int ViewAllAccounts { get; set; }
        public int Auctions { get; set; }
        public int PostAdds { get; set; }
        public int PaidRequests { get; set; }
        public int BlockedAuctioner { get; set; }
        public int Quries { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                var UT = HttpContext.Session.GetString("UserType");
                if (UT != "1" || string.IsNullOrEmpty(UT))
                {
                    return RedirectToPage("/Common/Login");
                }
                else
                {
                    NewAccount = await userRepo.CountOfAllusers();
                    VerifyAccount = await userRepo.CountOfAllUnVerified();
                    DeleteUpdate = await userRepo.CountOfAllusers();
                    ViewAllAccounts = await userRepo.CountOfAllusers();
                    Auctions = await userRepo.CountOfAllAuctions();
                    PaidRequests = await userRepo.CountOfAllPaidReq();
                    PostAdds = await userRepo.CountOfAllAdds();
                    BlockedAuctioner = await userRepo.CountOfBlockedAuctioner();
                    Quries = await userRepo.CountOfQuries();
                }
            }
            catch(Exception e)
            {

            }
            return default;
        }
    }
}
