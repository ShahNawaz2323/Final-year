using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Admin
{
    public class AllUsersModel : PageModel
    {
        UserRepo userRepo = new UserRepo();

        public string value { get; set; }

        public IEnumerable<User> users { get; set; }

        public async Task<IActionResult> OnGetAsync(string Value)
        {
            try
            {
                var UT = HttpContext.Session.GetString("UserType");
                if(UT != null && UT == "1")
                {
                    if (Value == "Verify" || Value == "Edit" || Value == "View")
                    {
                        if (Value == "Verify")
                        {
                            value = Value;
                            users = await userRepo.AllUnveriedUsers();
                        }
                        if (Value == "Edit" || Value == "View")
                        {
                            value = Value;
                            users = await userRepo.ShowAllUsers();
                        }
                    }
                }
                else
                {
                    return RedirectToPage("/Admin/Home");
                }
            }
            catch (Exception e)
            {

            }
            return default;
        }
    }
}
