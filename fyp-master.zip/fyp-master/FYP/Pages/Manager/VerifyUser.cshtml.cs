using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Manager
{
    public class VerifyUserModel : PageModel
    {
        UserRepo userRepo = new UserRepo();

        public User user { get; set; }

        public async Task<IActionResult> OnGetAsync(int ID)
        {
            try
            {
                var UT = HttpContext.Session.GetString("UserType");
                if (UT != "2" || string.IsNullOrEmpty(UT))
                {
                    return RedirectToPage("/Common/Login");
                }
                else
                {
                    user = await userRepo.GetByIdAsync(ID);
                }
               
            }
            catch(Exception e)
            {

            }
            return default;
           
        }
        public async Task<IActionResult> OnGetVerify(string UID)
        {
           var Done =  await userRepo.MarkUserVerified(UID);
            if (Done)
            {
                return new JsonResult("true");
            }
            else
            {
                return new JsonResult("false");
            }
            
        }
    }
}
