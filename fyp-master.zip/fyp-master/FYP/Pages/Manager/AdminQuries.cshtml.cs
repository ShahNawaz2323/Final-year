using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Manager
{
    public class AdminQuriesModel : PageModel
    {
        UserRepo userRepo = new UserRepo();
        public IEnumerable<MessForAdmin> quries { get; set; } 

        public async Task<IActionResult> OnGetAsync()
        {
            var UT = HttpContext.Session.GetString("UserType");
            if(UT != "2")
            {
                return RedirectToPage("/Manager/Home");
            }
            else
            {
                quries = await userRepo.AllQuriesForAdmin();
            }
            return Page();
        }
    }
}
