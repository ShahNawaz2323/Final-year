using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Manager
{
    public class NewAccountModel : PageModel
    {
        UserRepo UserRepository = new UserRepo();

        [BindProperty]
        public User user { get; set; } = new User();

        [BindProperty]
        public string Paid { get; set; } 

        [BindProperty]
        public string Verified { get; set; }

        [BindProperty]
        public string Rights { get; set; }

        [BindProperty]
        public IFormFile Front { get; set; }

        [BindProperty]
        public IFormFile Back { get; set; }

        public readonly IWebHostEnvironment _webHostEnvironment;

        public NewAccountModel(IWebHostEnvironment webHostEnvironment)
        {
            _webHostEnvironment = webHostEnvironment;
        }


        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                var UT = HttpContext.Session.GetString("UserType");
                if (UT != "2" || string.IsNullOrEmpty(UT))
                {
                    return RedirectToPage("/Common/Login");
                }
                user.CNIC = null;
                user.Age = null;
                user.Password = null;
            }
            catch (Exception e)
            {

            }
            return default;
        }


        public async Task<IActionResult> OnPostAsync()
        {
            try
            {
                if (user.Password.Length < 8)
                {
                    ModelState.AddModelError("min password", "Password Must Be minimum 8 words");
                    return Page();
                }

                if (user.CNIC.ToString().Contains('-'))
                {
                    ModelState.AddModelError("cnic", "Special Charactor not allowed in CNIC");
                    return Page();
                }
                if (user.CNIC.ToString().Length != 13)
                {
                    ModelState.AddModelError("min cnic", "CNIC must be 13 digit number");
                    return Page();
                }

                var Imgnamefront = "";
                var Imgnameback = "";

                if (Front != null)
                {
                    Imgnamefront = user.CNIC + "@" + Front.FileName.ToString();
                    user.Picfront = Imgnamefront;

                }
                if (Back != null)
                {
                    Imgnameback = user.CNIC + "@" + Back.FileName.ToString();
                    user.Picback = Imgnameback;

                }
                
                user.userType = 0;
                user.UserName = user.UserName.ToUpper();
                user.Paid = Paid;
                user.Blocked = "false";
                user.AdminVerified = Verified;

                if (string.IsNullOrEmpty(user.Picback) || string.IsNullOrEmpty(user.Picfront))
                {
                    ModelState.AddModelError("picfail", "Please Add Both Images of CNIC");
                    return Page();
                }
                var User = await UserRepository.AddAsync(user);
                if (User)
                {
                    var fileupload = Path.Combine(_webHostEnvironment.WebRootPath, "CNIC", Imgnamefront);
                    using (var FS = new FileStream(fileupload, FileMode.Create))
                    {
                        await Front.CopyToAsync(FS);
                    }
                    var fileupload2 = Path.Combine(_webHostEnvironment.WebRootPath, "CNIC", Imgnameback);
                    using (var FS = new FileStream(fileupload2, FileMode.Create))
                    {
                        await Back.CopyToAsync(FS);
                    }
                    
                }
                else
                {
                    ModelState.AddModelError("NewFail", "User Already Exist With same EMAIL or CNIC!");
                    return Page();
                }
            }
            catch(Exception e)
            {

            }

            return RedirectToPage("/Manager/Home");
        }
    }
}
