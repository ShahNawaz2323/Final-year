using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Manager
{
    public class AllAuctionsModel : PageModel
    {
        UserRepo userRepo = new UserRepo();

        public IEnumerable<Postadd> Adds { get; set; }

        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                var UT = HttpContext.Session.GetString("UserType");
                if (UT != "2" || string.IsNullOrEmpty(UT))
                {
                    return RedirectToPage("/Manager/Home");
                }
                else
                {
                    Adds = await userRepo.AllAddsForAdmin();
                }
                
            }
            catch(Exception e)
            {

            }
            return default;
        }
    }
}
