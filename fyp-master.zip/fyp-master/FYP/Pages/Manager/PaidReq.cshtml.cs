using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Manager
{
    public class PaidReqModel : PageModel
    {
        public IEnumerable<GetPaid> getPaids { get; set; }
        UserRepo userRepo = new UserRepo();

        public async Task OnGetAsync()
        {
            try
            {
                getPaids = await userRepo.AllUnPaidReq();
                // await userRepo.AllUnPaidReqstatuschange();
            }
            catch (Exception e)
            {

            }
            
          
        }
    }
}
