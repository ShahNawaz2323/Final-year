using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Manager
{
    public class UpdateUserAddModel : PageModel
    {
        UserRepo userRepo = new UserRepo();

        [BindProperty]
        public Postadd postAdd { get; set; }
        public async Task<IActionResult> OnGetAsync(int Number)
        {
            try
            {
                var UT = HttpContext.Session.GetString("UserType");
                if (UT != "2" || string.IsNullOrEmpty(UT))
                {
                    return RedirectToPage("/Manager/Home");
                }
                else
                {
                    postAdd = await userRepo.AddById(Number);
                }
            }
            catch(Exception e)
            {

            }

            return default;
        }

        public async Task<IActionResult> OnPostAsync(string value)
        {
            try
            {
                if (value == "Update")
                {
                    var saved = await userRepo.AdminEditAdd(postAdd);
                    if (saved)
                    {
                        Response.Redirect("/Manager/UpdateUserAdd?Number=" + postAdd.id);
                    }
                }
                else if (value == "Delete")
                {
                    var deleted =  await userRepo.DELETEADD(postAdd.userid.ToString(), postAdd.id);
                    if (deleted)
                    {
                        return RedirectToPage("/Manager/AllAuctions");
                    }
                }

            }
            catch (Exception e)
            {

            }
            return default;
        }
    }
}
