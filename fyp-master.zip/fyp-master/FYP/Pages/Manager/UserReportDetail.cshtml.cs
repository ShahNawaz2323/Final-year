using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Manager
{
    public class UserReportDetailModel : PageModel
    {
        UserRepo userRepo = new UserRepo();
        public UsersReport Data = new UsersReport();
        public async Task<IActionResult> OnGetAsync(string ID)
        {
            try
            {
                var UT = HttpContext.Session.GetString("UserType");
                if (UT != "2" || string.IsNullOrEmpty(UT))
                {
                    return RedirectToPage("/Common/Login");
                }
                else
                {
                    var user = await userRepo.GetByIdAsync(Convert.ToInt32(ID));
                    UsersReport usersReport = new UsersReport();
                    var auctions = await userRepo.GetAllAddsCount(user.ID);
                    var bids = await userRepo.GetAllBidsCount(user.ID);
                    var wons = await userRepo.GetAllWonsCount(user.ID);

                    usersReport.UID = user.ID;
                    usersReport.Name = user.UserName;
                    usersReport.Auctions = auctions;
                    usersReport.Bids = bids;
                    usersReport.Won = wons;
                    Data = usersReport;
                }
            }
            catch(Exception e)
            {

            }

            return default;
        }
    }
}
