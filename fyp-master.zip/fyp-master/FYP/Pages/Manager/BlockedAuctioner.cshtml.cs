using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Manager
{
    public class BlockedAuctionerModel : PageModel
    {
        UserRepo userRepo = new UserRepo();
        public IEnumerable<BidingBlocked> bidingBlockeds { get; set; }
        public async Task<IActionResult> OnGetAsync()
        {
            var UT = HttpContext.Session.GetString("UserType");
            if(UT != "2")
            {
                return RedirectToPage("/Manager/Home");
            }
            bidingBlockeds = await userRepo.AllBlockedAuctioners();
            return Page();
        }

        public async Task<IActionResult> OnGetUnBlock(int UID , int ID)
        {
            await userRepo.UnblockBlockedAuctioners(UID, ID);
            return new JsonResult("");
        }

    }
}
