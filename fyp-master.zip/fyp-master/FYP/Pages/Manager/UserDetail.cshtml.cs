using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FYP.classes;
using FYP.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FYP.Pages.Manager
{
    public class UserDetailModel : PageModel
    {
        UserRepo userRepo = new UserRepo();

        public string value { get; set; }

        [BindProperty]
        public User user { get; set; }

        [BindProperty]
        public bool Paid { get; set; }

        [BindProperty]
        public bool Blocked { get; set; }
        public async Task<IActionResult> OnGetAsync(int ID , string Value)
        {
            try
            {
                var UT = HttpContext.Session.GetString("UserType");
                if (UT != "2" || string.IsNullOrEmpty(UT))
                {
                    return RedirectToPage("/Common/Login");
                }
                else
                {
                    value = Value;
                    user = await userRepo.GetByIdAsync(ID);
                    if (user.Paid == "true")
                    {
                        Paid = true;
                    }
                    else
                    {
                        Paid = false;
                    }

                    if (user.Blocked == "false")
                    {
                        Blocked = false;
                    }
                    else
                    {
                        Blocked = true;
                    }
                    
                }
            }
            catch(Exception e)
            {

            }

            return default;
        }

        public async Task<IActionResult> OnPostAsync(string value)
        {
            try
            {
                if (value == "update")
                {
                    if (Paid)
                    {
                        user.Paid = "true";
                    }
                    else
                    {
                        user.Paid = "false";
                    }

                    if (Blocked)
                    {
                        user.Blocked = "true";
                    }
                    else
                    {
                        user.Blocked = "false";
                    }
                    await userRepo.UpdateUserDataAdmin(user);
                    Response.Redirect("/Manager/UserDetail?ID=" + user.ID + "&Value=10");
                }
                if (value == "delete")
                {
                    await userRepo.DeleteUserByAdmin(user);
                    Response.Redirect("/Manager/AllUsers?Value=Edit");
                }
            }
            catch(Exception e)
            {

            }
            return default;
        }
    }
}
