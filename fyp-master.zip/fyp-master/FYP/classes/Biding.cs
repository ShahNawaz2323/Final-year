﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class Biding
    {
        public int id { get; set; }
        public int Addid { get; set; }
        public int userid { get; set; }
        public int startingbid { get; set; }
        public int currentAmt { get; set; }
        public string biderName { get; set; }
        public int biderid { get; set; }
        public string PlaceDate { get; set; }
        public string Status { get; set; }
    }
}
