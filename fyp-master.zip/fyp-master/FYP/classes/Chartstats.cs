﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class Chartstats
    {
       
            public int placedAuctions { get; set; }

            public int MarketsCount { get; set; }

            public DateTime PlacedDate { get; set; }


        
    }
}
