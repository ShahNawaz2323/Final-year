﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class BidingAmounts
    {
        public string ADDID { get; set; }
        public string CUID { get; set; }
        public string ADDOID { get; set; }
        public string BidType { get; set; }
        public bool shownegative { get; set; }
        public bool samebid { get; set; }
    }
}
