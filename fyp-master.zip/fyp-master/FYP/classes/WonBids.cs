﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class WonBids
    {
        public int Id { get; set; }
        public int Addid { get; set; }
        public int AddOwnerId { get; set; }
        public string AddOwnerName { get; set; }
        public int BiderId { get; set; }
        public string BiderName { get; set; }
        public int BiderWonAmount { get; set; }
        public int DefaultAmount { get; set; }
        public string MessSeen { get; set; }
        public string OfferAccepted { get; set; }
        public string Title { get; set; }
    }
        public class OwnerDetail
        { 
            public string ownername { get; set; }
            public string Email { get; set; }

            public string Number { get; set; }
            public string sellerid { get; set; }
            public int addid { get; set; }
        public bool alreadyrated { get; set; }
        public string trackingcode { get; set; }


        }
 }
