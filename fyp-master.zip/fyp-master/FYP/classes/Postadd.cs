﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class Postadd
    {
        public int id { get; set; }
        public int userid { get; set; }
        public string username { get; set; }
        public string? Title { get; set; }
        public string? location { get; set; }
        public string? Description { get; set; }
        public int startingbid { get; set; }
        public string? bidtype { get; set; }
        public string? catagory { get; set; }
        public string? Imagestring {get;set;}
        public List<string>? ImgNameInFolder { get; set; }
        public string Bidstart { get; set; }
        public string status { get; set; }
        public string visible { get; set; }
        public string PlaceDate { get; set; }
        public string AutoStart { get; set; }
        public string Deleted { get; set; }
        public int Grace { get; set; }
        public string AutoStop { get; set; }
    }
}
