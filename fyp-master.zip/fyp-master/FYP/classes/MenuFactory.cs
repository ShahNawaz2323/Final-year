﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class MenuFactory
    {
        public static MenuItem PostAdd
        {
            get
            {
                return new MenuItem("Start Auction", "/Common/PostAdd", "fa fa-tasks");
            }
        }

        public static MenuItem WinningBids
        {
            get
            {
                return new MenuItem("Winning Auctions", "/Common/MyWon", "fa fa-tasks");
            }
        }

        public static MenuItem Deleted
        {
            get
            {
                return new MenuItem("Deleted Adds", "/Admin/CustomerDashboard?deleted=true", "icon-speedometer");
            }
        }
        public static MenuItem DeletedManagerAdds
        {
            get
            {
                return new MenuItem("Deleted Adds", "/Manager/CustomerDashboard?deleted=true", "icon-speedometer");
            }
        }


        public static MenuItem CustomerHome
        {
            get
            {
                return new MenuItem("Dashboard", "/Common/Dashboard");
            }
        }

        public static MenuItem AdminHome
        {
            get
            {
                return new MenuItem("Dashboard", "/Admin/Home");
            }
        }

        public static MenuItem ManagerHome
        {
            get
            {
                return new MenuItem("Dashboard", "/Manager/Home");
            }
        }
    }

    public class Menu
    {
        public List<MenuItem> items { get; set; } = new List<MenuItem>();
        public void Add(MenuItem item)
        {
            items.Add(item);
        }
    }
}
