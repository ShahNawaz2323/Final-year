﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    [Table("Users")]
    public class User
    {
        [Key]
        public string UserName { get; set; }
        public string ID { get; set; }
        public long? CNIC { get; set; }
        public int? Age { get; set; }
        public string Password { get; set; }
        public string Picfront { get; set; }
        public string Picback { get; set; }
        public int userType { get; set; }
        public string Email { get; set; }
        public string Fathername { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public string Mobile { get; set; }
        public string Paid { get; set; }
        public string Blocked { get; set; }
        public string profilepic { get; set; }

        public string AdminVerified { get; set; }


        public UserType GetUserType()
        {
            return (UserType)userType;
        }

        public MenuItem getHomePageMenuItem()
        {
            MenuItem menuItem;

            switch (GetUserType())
            {
                case UserType.Customer:
                    menuItem = MenuFactory.CustomerHome;
                    break;

                case UserType.Admin:
                    menuItem = MenuFactory.AdminHome;
                    break;

                case UserType.Manager:
                    menuItem = MenuFactory.ManagerHome;
                    break;



                default:
                    menuItem = MenuFactory.CustomerHome;
                    break;
            }
            return menuItem;
        }






    }

    

   
}
