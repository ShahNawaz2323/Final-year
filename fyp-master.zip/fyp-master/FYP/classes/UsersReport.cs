﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class UsersReport
    {
        public string UID { get; set; }
        public string Name { get; set; }
        public string Auctions { get; set; }
        public string Bids { get; set; }
        public string Won { get; set; }
    }

    public class OrgReport
    {
        public string Auctions { get; set; }
        public string Bids { get; set; }
        public string UnSuccess { get; set; }
        public string Success { get; set; }
        public string PaidUsers { get; set; }
        public string UnpaidUsers { get; set; }
        public string blocked { get; set; }
    }
}
