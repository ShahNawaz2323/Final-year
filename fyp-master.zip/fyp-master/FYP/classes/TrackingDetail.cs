﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class TrackingDetail
    {
        public int ID { get; set; }
        public string Buyer { get; set; }
        public int Addid { get; set; }
        public string Tracking { get; set; }
    }
}
