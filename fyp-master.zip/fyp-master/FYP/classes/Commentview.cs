﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class Commentview
    {
        public string commentername { get; set; }
        public string comment { get; set; }
    }

}
