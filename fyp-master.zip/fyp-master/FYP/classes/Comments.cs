﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class Comments
    {
        public int ID { get; set; }
        public string UserId { get; set; }
        public int AddId { get; set; }
        public string Comment { get; set; }
        public string CommenterId { get; set; }
    }
}
