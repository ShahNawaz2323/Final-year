﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.classes
{
    public class MenuItem
    {
        public string Id { get; set; }

        public string Title { get; set; }

        public string Uri { get; set; }

        public string Classes { get; set; }

        public string Icon { get; set; }

        public MenuItem() { }

        public MenuItem(string title, string uri, string icon = "", string id = "")
        {
            Title = title;
            Uri = uri;
            Icon = icon;
            Id = id;
        }
    }
    public enum MenuType
    {
        BackendTop,
        BackendSide,
        BackendSideManager,
        BackendTopRight,
        FrontendTop,
        FrontendSide,
        FrontendTopRight
    }

    public enum UserType
    {
        Admin = 1,
        Manager = 2,
        Customer = 0
    }
}
